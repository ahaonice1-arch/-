-- Migration: social_features_realtime
-- Created at: 1763782158

-- 启用实时订阅
ALTER PUBLICATION supabase_realtime ADD TABLE friendships;
ALTER PUBLICATION supabase_realtime ADD TABLE posts;
ALTER PUBLICATION supabase_realtime ADD TABLE post_likes;
ALTER PUBLICATION supabase_realtime ADD TABLE comments;
ALTER PUBLICATION supabase_realtime ADD TABLE notifications;
ALTER PUBLICATION supabase_realtime ADD TABLE message_status;

-- 迁移完成提示
DO $$
BEGIN
  RAISE NOTICE '社交功能数据库扩展完成！';
  RAISE NOTICE '已创建/扩展以下表：';
  RAISE NOTICE '- profiles (扩展用户资料)';
  RAISE NOTICE '- friendships (好友关系)';
  RAISE NOTICE '- posts (朋友圈动态)';
  RAISE NOTICE '- post_likes (动态点赞)';
  RAISE NOTICE '- comments (评论)';
  RAISE NOTICE '- comment_likes (评论点赞)';
  RAISE NOTICE '- notifications (通知)';
  RAISE NOTICE '- user_groups (用户群组)';
  RAISE NOTICE '- chat_settings (聊天设置)';
  RAISE NOTICE '- message_status (消息状态)';
  RAISE NOTICE '';
  RAISE NOTICE '已启用功能：';
  RAISE NOTICE '- 完整社交功能支持';
  RAISE NOTICE '- 朋友圈系统';
  RAISE NOTICE '- 好友管理';
  RAISE NOTICE '- 通知系统';
  RAISE NOTICE '- 实时订阅';
  RAISE NOTICE '- 行级安全策略';
END $$;;