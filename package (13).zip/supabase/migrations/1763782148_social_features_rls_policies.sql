-- Migration: social_features_rls_policies
-- Created at: 1763782148

-- 启用行级安全策略
ALTER TABLE friendships ENABLE ROW LEVEL SECURITY;
ALTER TABLE posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE post_likes ENABLE ROW LEVEL SECURITY;
ALTER TABLE comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE comment_likes ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_groups ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE message_status ENABLE ROW LEVEL SECURITY;

-- 创建行级安全策略

-- friendships 表策略
CREATE POLICY "用户可以查看自己的好友关系" ON friendships
  FOR SELECT USING (auth.uid() = requester_id OR auth.uid() = addressee_id);

CREATE POLICY "用户可以发送好友请求" ON friendships
  FOR INSERT WITH CHECK (auth.uid() = requester_id);

CREATE POLICY "用户可以更新好友关系状态" ON friendships
  FOR UPDATE USING (auth.uid() = requester_id OR auth.uid() = addressee_id);

CREATE POLICY "用户可以删除好友关系" ON friendships
  FOR DELETE USING (auth.uid() = requester_id OR auth.uid() = addressee_id);

-- posts 表策略
CREATE POLICY "用户可以查看公开动态" ON posts
  FOR SELECT USING (visibility = 'public' OR 
    (visibility = 'friends' AND auth.uid() IN (
      SELECT requester_id FROM friendships WHERE addressee_id = auth.uid() AND status = 'accepted'
      UNION
      SELECT addressee_id FROM friendships WHERE requester_id = auth.uid() AND status = 'accepted'
    )) OR
    auth.uid() = author_id);

CREATE POLICY "用户可以创建动态" ON posts
  FOR INSERT WITH CHECK (auth.uid() = author_id);

CREATE POLICY "用户可以更新自己的动态" ON posts
  FOR UPDATE USING (auth.uid() = author_id);

CREATE POLICY "用户可以删除自己的动态" ON posts
  FOR DELETE USING (auth.uid() = author_id);

-- post_likes 表策略
CREATE POLICY "用户可以查看点赞信息" ON post_likes
  FOR SELECT USING (true);

CREATE POLICY "用户可以点赞动态" ON post_likes
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "用户可以取消点赞" ON post_likes
  FOR DELETE USING (auth.uid() = user_id);

-- comments 表策略
CREATE POLICY "用户可以查看评论" ON comments
  FOR SELECT USING (true);

CREATE POLICY "用户可以创建评论" ON comments
  FOR INSERT WITH CHECK (auth.uid() = author_id);

CREATE POLICY "用户可以更新自己的评论" ON comments
  FOR UPDATE USING (auth.uid() = author_id);

CREATE POLICY "用户可以删除自己的评论" ON comments
  FOR DELETE USING (auth.uid() = author_id);

-- comment_likes 表策略
CREATE POLICY "用户可以查看评论点赞" ON comment_likes
  FOR SELECT USING (true);

CREATE POLICY "用户可以点赞评论" ON comment_likes
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "用户可以取消评论点赞" ON comment_likes
  FOR DELETE USING (auth.uid() = user_id);

-- notifications 表策略 (使用现有列名)
CREATE POLICY "用户只能查看自己的通知" ON notifications
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "系统可以创建通知" ON notifications
  FOR INSERT WITH CHECK (true);

CREATE POLICY "用户可以更新通知状态" ON notifications
  FOR UPDATE USING (auth.uid() = user_id);

-- user_groups 表策略
CREATE POLICY "用户可以查看自己的群组" ON user_groups
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "用户可以加入群组" ON user_groups
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "用户可以离开群组" ON user_groups
  FOR DELETE USING (auth.uid() = user_id);

-- chat_settings 表策略
CREATE POLICY "聊天成员可以查看聊天设置" ON chat_settings
  FOR SELECT USING (
    chat_id IN (
      SELECT chat_id FROM chat_members WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "聊天创建者可以更新设置" ON chat_settings
  FOR UPDATE USING (
    chat_id IN (
      SELECT id FROM chats WHERE created_by = auth.uid()
    )
  );

-- message_status 表策略
CREATE POLICY "用户可以查看消息状态" ON message_status
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "系统可以更新消息状态" ON message_status
  FOR INSERT WITH CHECK (true);;