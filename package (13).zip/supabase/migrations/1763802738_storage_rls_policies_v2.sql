-- Migration: storage_rls_policies_v2
-- Created at: 1763802738

-- Drop existing policies if any
DROP POLICY IF EXISTS "Public read access for posts" ON storage.objects;
DROP POLICY IF EXISTS "Allow upload to posts" ON storage.objects;
DROP POLICY IF EXISTS "Allow update in posts" ON storage.objects;
DROP POLICY IF EXISTS "Allow delete from posts" ON storage.objects;
DROP POLICY IF EXISTS "Public read access for avatars" ON storage.objects;
DROP POLICY IF EXISTS "Allow upload to avatars" ON storage.objects;
DROP POLICY IF EXISTS "Allow update in avatars" ON storage.objects;
DROP POLICY IF EXISTS "Allow delete from avatars" ON storage.objects;

-- RLS policies for posts bucket
CREATE POLICY "Public read access for posts" ON storage.objects
  FOR SELECT USING (bucket_id = 'posts');

CREATE POLICY "Allow upload to posts" ON storage.objects
  FOR INSERT
  WITH CHECK (
    bucket_id = 'posts'
    AND (auth.role() = 'anon' OR auth.role() = 'authenticated' OR auth.role() = 'service_role')
  );

CREATE POLICY "Allow update in posts" ON storage.objects
  FOR UPDATE
  USING (bucket_id = 'posts' AND (auth.role() = 'anon' OR auth.role() = 'authenticated' OR auth.role() = 'service_role'));

CREATE POLICY "Allow delete from posts" ON storage.objects
  FOR DELETE
  USING (bucket_id = 'posts' AND (auth.role() = 'anon' OR auth.role() = 'authenticated' OR auth.role() = 'service_role'));

-- RLS policies for avatars bucket
CREATE POLICY "Public read access for avatars" ON storage.objects
  FOR SELECT USING (bucket_id = 'avatars');

CREATE POLICY "Allow upload to avatars" ON storage.objects
  FOR INSERT
  WITH CHECK (
    bucket_id = 'avatars'
    AND (auth.role() = 'anon' OR auth.role() = 'authenticated' OR auth.role() = 'service_role')
  );

CREATE POLICY "Allow update in avatars" ON storage.objects
  FOR UPDATE
  USING (bucket_id = 'avatars' AND (auth.role() = 'anon' OR auth.role() = 'authenticated' OR auth.role() = 'service_role'));

CREATE POLICY "Allow delete from avatars" ON storage.objects
  FOR DELETE
  USING (bucket_id = 'avatars' AND (auth.role() = 'anon' OR auth.role() = 'authenticated' OR auth.role() = 'service_role'));;