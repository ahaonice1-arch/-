-- Migration: fix_schema_mismatches
-- Created at: 1763799880

-- Fix schema mismatches between frontend and backend

-- 1. Fix friendships table - add user_id and friend_id columns (keeping old ones for compatibility)
ALTER TABLE friendships 
ADD COLUMN IF NOT EXISTS user_id uuid,
ADD COLUMN IF NOT EXISTS friend_id uuid;

-- Update user_id and friend_id based on requester_id and addressee_id
UPDATE friendships 
SET user_id = requester_id, 
    friend_id = addressee_id 
WHERE user_id IS NULL OR friend_id IS NULL;

-- 2. Fix notifications table - add read column (keeping is_read for compatibility)  
ALTER TABLE notifications 
ADD COLUMN IF NOT EXISTS "read" boolean DEFAULT false;

-- Update read column based on is_read
UPDATE notifications 
SET "read" = COALESCE(is_read, false) 
WHERE "read" IS NULL;

-- 3. Create likes table as alias for post_likes (for backward compatibility)
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'likes' AND table_schema = 'public') THEN
        -- Create a view that maps likes to post_likes
        EXECUTE 'CREATE VIEW likes AS SELECT post_id as id, user_id, created_at FROM post_likes';
    END IF;
END
$$;

-- Grant necessary permissions
GRANT ALL ON ALL TABLES IN SCHEMA public TO authenticated, anon;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO authenticated, anon;;