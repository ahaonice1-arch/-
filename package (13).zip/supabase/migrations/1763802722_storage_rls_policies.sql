-- Migration: storage_rls_policies
-- Created at: 1763802722

-- RLS policies for posts bucket
CREATE POLICY IF NOT EXISTS "Public read access for posts" ON storage.objects
  FOR SELECT USING (bucket_id = 'posts');

CREATE POLICY IF NOT EXISTS "Allow upload to posts" ON storage.objects
  FOR INSERT
  WITH CHECK (
    bucket_id = 'posts'
    AND (auth.role() = 'anon' OR auth.role() = 'authenticated' OR auth.role() = 'service_role')
  );

CREATE POLICY IF NOT EXISTS "Allow update in posts" ON storage.objects
  FOR UPDATE
  USING (bucket_id = 'posts' AND (auth.role() = 'anon' OR auth.role() = 'authenticated' OR auth.role() = 'service_role'));

CREATE POLICY IF NOT EXISTS "Allow delete from posts" ON storage.objects
  FOR DELETE
  USING (bucket_id = 'posts' AND (auth.role() = 'anon' OR auth.role() = 'authenticated' OR auth.role() = 'service_role'));

-- RLS policies for avatars bucket
CREATE POLICY IF NOT EXISTS "Public read access for avatars" ON storage.objects
  FOR SELECT USING (bucket_id = 'avatars');

CREATE POLICY IF NOT EXISTS "Allow upload to avatars" ON storage.objects
  FOR INSERT
  WITH CHECK (
    bucket_id = 'avatars'
    AND (auth.role() = 'anon' OR auth.role() = 'authenticated' OR auth.role() = 'service_role')
  );

CREATE POLICY IF NOT EXISTS "Allow update in avatars" ON storage.objects
  FOR UPDATE
  USING (bucket_id = 'avatars' AND (auth.role() = 'anon' OR auth.role() = 'authenticated' OR auth.role() = 'service_role'));

CREATE POLICY IF NOT EXISTS "Allow delete from avatars" ON storage.objects
  FOR DELETE
  USING (bucket_id = 'avatars' AND (auth.role() = 'anon' OR auth.role() = 'authenticated' OR auth.role() = 'service_role'));;