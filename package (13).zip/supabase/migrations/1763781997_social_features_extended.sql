-- Migration: social_features_extended
-- Created at: 1763781997

-- =====================================================
-- 社交功能数据库扩展迁移脚本
-- 版本: 2.0.0
-- 创建时间: 2025-11-22
-- 目的: 扩展数据库架构以支持完整社交功能
-- =====================================================

-- 1. 扩展用户资料表
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS username TEXT UNIQUE;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS bio TEXT;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS phone TEXT;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS is_online BOOLEAN DEFAULT FALSE;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS last_seen TIMESTAMP WITH TIME ZONE DEFAULT NOW();

-- 2. 创建好友关系表
CREATE TABLE IF NOT EXISTS friendships (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  requester_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  addressee_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'blocked')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  
  -- 确保不能自己添加自己为好友
  CONSTRAINT friendships_self_check CHECK (requester_id != addressee_id),
  -- 确保同一对好友关系只存在一条记录
  CONSTRAINT friendships_unique CHECK (
    requester_id < addressee_id OR (
      requester_id > addressee_id AND
      NOT EXISTS (
        SELECT 1 FROM friendships f2 
        WHERE (f2.requester_id = addressee_id AND f2.addressee_id = requester_id)
      )
    )
  )
);

-- 3. 创建动态/朋友圈表
CREATE TABLE IF NOT EXISTS posts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  author_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  content TEXT NOT NULL,
  image_urls TEXT[], -- 图片URL数组
  visibility TEXT DEFAULT 'public' CHECK (visibility IN ('public', 'friends', 'private')),
  like_count INTEGER DEFAULT 0,
  comment_count INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 4. 创建点赞表
CREATE TABLE IF NOT EXISTS post_likes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id UUID REFERENCES posts(id) ON DELETE CASCADE NOT NULL,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  
  -- 确保同一用户不能重复点赞同一动态
  UNIQUE(post_id, user_id)
);

-- 5. 创建评论表
CREATE TABLE IF NOT EXISTS comments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id UUID REFERENCES posts(id) ON DELETE CASCADE NOT NULL,
  author_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  content TEXT NOT NULL,
  parent_id UUID REFERENCES comments(id) ON DELETE CASCADE, -- 支持回复评论
  like_count INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 6. 创建评论点赞表
CREATE TABLE IF NOT EXISTS comment_likes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  comment_id UUID REFERENCES comments(id) ON DELETE CASCADE NOT NULL,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  
  -- 确保同一用户不能重复点赞同一评论
  UNIQUE(comment_id, user_id)
);

-- 7. 创建通知表
CREATE TABLE IF NOT EXISTS notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  recipient_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  sender_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  type TEXT NOT NULL CHECK (type IN ('like', 'comment', 'friend_request', 'message', 'mention')),
  content TEXT NOT NULL,
  related_id UUID, -- 相关对象ID（如动态ID、评论ID等）
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 8. 创建用户群组关系表（支持用户加入多个群）
CREATE TABLE IF NOT EXISTS user_groups (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  group_name TEXT NOT NULL,
  role TEXT DEFAULT 'member' CHECK (role IN ('admin', 'member')),
  joined_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  
  -- 确保一个用户不能重复加入同一群组
  UNIQUE(user_id, group_name)
);

-- 9. 创建聊天群配置表（扩展现有chats表）
CREATE TABLE IF NOT EXISTS chat_settings (
  chat_id UUID PRIMARY KEY REFERENCES chats(id) ON DELETE CASCADE NOT NULL,
  description TEXT, -- 群描述
  avatar_url TEXT, -- 群头像
  is_public BOOLEAN DEFAULT FALSE,
  allow_invite BOOLEAN DEFAULT TRUE,
  max_members INTEGER DEFAULT 500,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 10. 创建消息状态表
CREATE TABLE IF NOT EXISTS message_status (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  message_id UUID REFERENCES messages(id) ON DELETE CASCADE NOT NULL,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  status TEXT DEFAULT 'sent' CHECK (status IN ('sent', 'delivered', 'read')),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  
  -- 确保同一用户不能重复设置同一消息状态
  UNIQUE(message_id, user_id)
);

-- 11. 创建索引以提高查询性能
CREATE INDEX IF NOT EXISTS idx_friendships_requester ON friendships(requester_id);
CREATE INDEX IF NOT EXISTS idx_friendships_addressee ON friendships(addressee_id);
CREATE INDEX IF NOT EXISTS idx_friendships_status ON friendships(status);
CREATE INDEX IF NOT EXISTS idx_posts_author ON posts(author_id);
CREATE INDEX IF NOT EXISTS idx_posts_created_at ON posts(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_post_likes_post ON post_likes(post_id);
CREATE INDEX IF NOT EXISTS idx_post_likes_user ON post_likes(user_id);
CREATE INDEX IF NOT EXISTS idx_comments_post ON comments(post_id);
CREATE INDEX IF NOT EXISTS idx_comments_author ON comments(author_id);
CREATE INDEX IF NOT EXISTS idx_comment_likes_comment ON comment_likes(comment_id);
CREATE INDEX IF NOT EXISTS idx_notifications_recipient ON notifications(recipient_id);
CREATE INDEX IF NOT EXISTS idx_notifications_unread ON notifications(recipient_id, is_read);
CREATE INDEX IF NOT EXISTS idx_user_groups_user ON user_groups(user_id);
CREATE INDEX IF NOT EXISTS idx_message_status_message ON message_status(message_id);
CREATE INDEX IF NOT EXISTS idx_message_status_user ON message_status(user_id);

-- 12. 创建更新时间戳触发器
CREATE TRIGGER update_friendships_updated_at 
  BEFORE UPDATE ON friendships 
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_posts_updated_at 
  BEFORE UPDATE ON posts 
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_comments_updated_at 
  BEFORE UPDATE ON comments 
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_notifications_updated_at 
  BEFORE UPDATE ON notifications 
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_chat_settings_updated_at 
  BEFORE UPDATE ON chat_settings 
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- 13. 启用行级安全策略
ALTER TABLE friendships ENABLE ROW LEVEL SECURITY;
ALTER TABLE posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE post_likes ENABLE ROW LEVEL SECURITY;
ALTER TABLE comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE comment_likes ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_groups ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE message_status ENABLE ROW LEVEL SECURITY;

-- 14. 创建行级安全策略

-- friendships 表策略
CREATE POLICY "用户可以查看自己的好友关系" ON friendships
  FOR SELECT USING (auth.uid() = requester_id OR auth.uid() = addressee_id);

CREATE POLICY "用户可以发送好友请求" ON friendships
  FOR INSERT WITH CHECK (auth.uid() = requester_id);

CREATE POLICY "用户可以更新好友关系状态" ON friendships
  FOR UPDATE USING (auth.uid() = requester_id OR auth.uid() = addressee_id);

CREATE POLICY "用户可以删除好友关系" ON friendships
  FOR DELETE USING (auth.uid() = requester_id OR auth.uid() = addressee_id);

-- posts 表策略
CREATE POLICY "用户可以查看公开动态" ON posts
  FOR SELECT USING (visibility = 'public' OR 
    (visibility = 'friends' AND auth.uid() IN (
      SELECT requester_id FROM friendships WHERE addressee_id = auth.uid() AND status = 'accepted'
      UNION
      SELECT addressee_id FROM friendships WHERE requester_id = auth.uid() AND status = 'accepted'
    )) OR
    auth.uid() = author_id);

CREATE POLICY "用户可以创建动态" ON posts
  FOR INSERT WITH CHECK (auth.uid() = author_id);

CREATE POLICY "用户可以更新自己的动态" ON posts
  FOR UPDATE USING (auth.uid() = author_id);

CREATE POLICY "用户可以删除自己的动态" ON posts
  FOR DELETE USING (auth.uid() = author_id);

-- post_likes 表策略
CREATE POLICY "用户可以查看点赞信息" ON post_likes
  FOR SELECT USING (true);

CREATE POLICY "用户可以点赞动态" ON post_likes
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "用户可以取消点赞" ON post_likes
  FOR DELETE USING (auth.uid() = user_id);

-- comments 表策略
CREATE POLICY "用户可以查看评论" ON comments
  FOR SELECT USING (true);

CREATE POLICY "用户可以创建评论" ON comments
  FOR INSERT WITH CHECK (auth.uid() = author_id);

CREATE POLICY "用户可以更新自己的评论" ON comments
  FOR UPDATE USING (auth.uid() = author_id);

CREATE POLICY "用户可以删除自己的评论" ON comments
  FOR DELETE USING (auth.uid() = author_id);

-- comment_likes 表策略
CREATE POLICY "用户可以查看评论点赞" ON comment_likes
  FOR SELECT USING (true);

CREATE POLICY "用户可以点赞评论" ON comment_likes
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "用户可以取消评论点赞" ON comment_likes
  FOR DELETE USING (auth.uid() = user_id);

-- notifications 表策略
CREATE POLICY "用户只能查看自己的通知" ON notifications
  FOR SELECT USING (auth.uid() = recipient_id);

CREATE POLICY "系统可以创建通知" ON notifications
  FOR INSERT WITH CHECK (true);

CREATE POLICY "用户可以更新通知状态" ON notifications
  FOR UPDATE USING (auth.uid() = recipient_id);

-- user_groups 表策略
CREATE POLICY "用户可以查看自己的群组" ON user_groups
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "用户可以加入群组" ON user_groups
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "用户可以离开群组" ON user_groups
  FOR DELETE USING (auth.uid() = user_id);

-- chat_settings 表策略
CREATE POLICY "聊天成员可以查看聊天设置" ON chat_settings
  FOR SELECT USING (
    chat_id IN (
      SELECT chat_id FROM chat_members WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "聊天创建者可以更新设置" ON chat_settings
  FOR UPDATE USING (
    chat_id IN (
      SELECT id FROM chats WHERE created_by = auth.uid()
    )
  );

-- message_status 表策略
CREATE POLICY "用户可以查看消息状态" ON message_status
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "系统可以更新消息状态" ON message_status
  FOR INSERT WITH CHECK (true);

-- 15. 启用实时订阅
ALTER PUBLICATION supabase_realtime ADD TABLE friendships;
ALTER PUBLICATION supabase_realtime ADD TABLE posts;
ALTER PUBLICATION supabase_realtime ADD TABLE post_likes;
ALTER PUBLICATION supabase_realtime ADD TABLE comments;
ALTER PUBLICATION supabase_realtime ADD TABLE notifications;
ALTER PUBLICATION supabase_realtime ADD TABLE message_status;;