-- Migration: add_created_by_to_chats
-- Created at: 1763803434

-- Add created_by column to chats table if not exists
ALTER TABLE chats ADD COLUMN IF NOT EXISTS created_by UUID REFERENCES profiles(id);;