-- Migration: fix_messages_table_clean
-- Created at: 1763797901

-- Drop and recreate messages table with clean schema
DROP TABLE IF EXISTS messages CASCADE;

-- Create clean messages table
CREATE TABLE messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    chat_id UUID NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    content TEXT NOT NULL,
    message_type TEXT DEFAULT 'text',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    payload JSONB DEFAULT '{}'::jsonb,
    private BOOLEAN DEFAULT false
);

-- Enable RLS
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

-- Create indexes for performance
CREATE INDEX idx_messages_chat_id_created_at ON messages (chat_id, created_at);
CREATE INDEX idx_messages_user_id ON messages (user_id);

-- Add RLS policies
CREATE POLICY "Users can send messages" ON messages
    FOR INSERT WITH CHECK (
        auth.uid() = user_id AND 
        chat_id IN (
            SELECT chat_id FROM chat_members WHERE user_id = auth.uid()
        )
    );

CREATE POLICY "Users can view messages in their chats" ON messages
    FOR SELECT USING (
        chat_id IN (
            SELECT chat_id FROM chat_members WHERE user_id = auth.uid()
        )
    );

CREATE POLICY "Users can update their own messages" ON messages
    FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own messages" ON messages
    FOR DELETE USING (auth.uid() = user_id);;