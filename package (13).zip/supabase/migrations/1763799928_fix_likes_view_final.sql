-- Migration: fix_likes_view_final
-- Created at: 1763799928

-- Drop and recreate the likes view correctly
DROP VIEW IF EXISTS likes CASCADE;

CREATE VIEW likes AS 
SELECT 
    id,
    post_id,
    user_id,
    created_at
FROM post_likes;;