-- Migration: fix_likes_view
-- Created at: 1763799903

-- Drop and recreate the likes view with correct column names
DROP VIEW IF EXISTS likes CASCADE;

CREATE VIEW likes AS 
SELECT 
    post_id as id,
    user_id,
    created_at
FROM post_likes;;