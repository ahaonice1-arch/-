-- Migration: fix_messages_table_schema
-- Created at: 1763797836

-- Fix messages table schema by removing duplicate columns
ALTER TABLE messages DROP COLUMN IF EXISTS updated_at;
ALTER TABLE messages DROP COLUMN IF EXISTS id;

-- Add back the proper updated_at column
ALTER TABLE messages ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW();

-- Ensure proper schema structure
-- Check if payload column exists, if not add it
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                   WHERE table_name = 'messages' AND column_name = 'payload') THEN
        ALTER TABLE messages ADD COLUMN payload JSONB;
    END IF;
END $$;

-- Create index for better performance
CREATE INDEX IF NOT EXISTS idx_messages_chat_id_created_at ON messages (chat_id, created_at);;