-- Migration: add_language_preference
-- Created at: 1763802887

-- Add language preference column to profiles
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS language VARCHAR(10) DEFAULT 'zh';

-- Add notification data column if not exists
ALTER TABLE notifications ADD COLUMN IF NOT EXISTS data JSONB DEFAULT '{}'::jsonb;

-- Create function to create notification on friend request
CREATE OR REPLACE FUNCTION create_friend_request_notification()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO notifications (user_id, type, content, data)
  VALUES (
    NEW.to_user_id,
    'friend_request',
    'You have a new friend request',
    jsonb_build_object('from_user_id', NEW.from_user_id, 'request_id', NEW.id)
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for friend requests
DROP TRIGGER IF EXISTS friend_request_notification_trigger ON friend_requests;
CREATE TRIGGER friend_request_notification_trigger
AFTER INSERT ON friend_requests
FOR EACH ROW
EXECUTE FUNCTION create_friend_request_notification();;