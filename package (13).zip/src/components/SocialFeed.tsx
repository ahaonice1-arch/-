// =====================================================
// 朋友圈组件 - SocialFeed.tsx
// 显示动态、点赞、评论功能
// =====================================================

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  TextInput,
  TouchableOpacity,
  Image,
  Alert,
  RefreshControl,
} from 'react-native';
import { SocialService, Post, Comment, UserProfile, PostLike } from '../services/supabaseSocial';
import { useAuthStore } from '../stores/authStore';

interface SocialFeedProps {
  userId?: string; // 如果不传则显示所有可见动态
}

export const SocialFeed: React.FC<SocialFeedProps> = ({ userId }) => {
  const { user } = useAuthStore();
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [newPostContent, setNewPostContent] = useState('');
  const [submitting, setSubmitting] = useState(false);

  // 加载动态
  const loadPosts = async () => {
    try {
      const result = userId 
        ? await SocialService.getUserPosts(userId)
        : await SocialService.getPosts();
      
      if (result.error) {
        Alert.alert('错误', '加载动态失败：' + result.error.message);
      } else {
        setPosts(result.data);
      }
    } catch (error) {
      console.error('加载动态错误:', error);
      Alert.alert('错误', '加载动态时出现异常');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  // 刷新动态
  const onRefresh = () => {
    setRefreshing(true);
    loadPosts();
  };

  // 发布新动态
  const submitPost = async () => {
    if (!newPostContent.trim()) {
      Alert.alert('提示', '请输入动态内容');
      return;
    }

    setSubmitting(true);
    try {
      const result = await SocialService.createPost(newPostContent.trim());
      if (result.error) {
        Alert.alert('错误', '发布失败：' + result.error.message);
      } else {
        setNewPostContent('');
        await loadPosts(); // 重新加载动态
        Alert.alert('成功', '动态发布成功！');
      }
    } catch (error) {
      console.error('发布动态错误:', error);
      Alert.alert('错误', '发布动态时出现异常');
    } finally {
      setSubmitting(false);
    }
  };

  // 点赞/取消点赞
  const toggleLike = async (post: Post) => {
    if (!user) return;

    try {
      // 检查是否已点赞
      const isLiked = post.likes?.some(like => like.user_id === user.id);
      
      if (isLiked) {
        await SocialService.unlikePost(post.id);
      } else {
        await SocialService.likePost(post.id);
      }
      
      // 重新加载该动态
      const updatedPosts = posts.map(p => {
        if (p.id === post.id) {
          return {
            ...p,
            like_count: isLiked ? p.like_count - 1 : p.like_count + 1,
            likes: isLiked 
              ? (p.likes || []).filter(like => like.user_id !== user.id)
              : [...(p.likes || []), {
                  id: 'temp',
                  post_id: post.id,
                  user_id: user.id,
                  user: {
                    id: user.id,
                    user_id: user.id,
                    full_name: user.user_metadata?.full_name || '',
                    is_online: true,
                    last_seen: new Date().toISOString(),
                    created_at: new Date().toISOString(),
                    updated_at: new Date().toISOString()
                  } as UserProfile
                }]
          };
        }
        return p;
      });
      setPosts(updatedPosts);
    } catch (error) {
      console.error('点赞错误:', error);
      Alert.alert('错误', '操作失败');
    }
  };

  // 格式化时间
  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    
    if (days === 0) {
      return '今天';
    } else if (days === 1) {
      return '昨天';
    } else if (days < 7) {
      return `${days}天前`;
    } else {
      return date.toLocaleDateString('zh-CN');
    }
  };

  useEffect(() => {
    loadPosts();
  }, [userId]);

  // 实时订阅
  useEffect(() => {
    const subscription = SocialService.subscribeToPosts((newPost) => {
      setPosts(prev => [newPost, ...prev]);
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  if (loading) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <Text>加载中...</Text>
      </View>
    );
  }

  return (
    <View style={{ flex: 1 }}>
      <ScrollView
        style={{ flex: 1 }}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        {/* 发布新动态区域 */}
        {!userId && user && (
          <View style={{ 
            backgroundColor: '#fff', 
            margin: 16, 
            padding: 16, 
            borderRadius: 12,
            shadowColor: '#000',
            shadowOffset: { width: 0, height: 1 },
            shadowOpacity: 0.1,
            shadowRadius: 2,
            elevation: 2,
          }}>
            <Text style={{ fontSize: 16, fontWeight: '600', marginBottom: 12 }}>
              分享生活...
            </Text>
            <TextInput
              style={{
                backgroundColor: '#f5f5f5',
                borderRadius: 8,
                padding: 12,
                minHeight: 80,
                textAlignVertical: 'top',
              }}
              placeholder="今天有什么想分享的吗？"
              value={newPostContent}
              onChangeText={setNewPostContent}
              multiline
              maxLength={500}
            />
            <View style={{ 
              flexDirection: 'row', 
              justifyContent: 'space-between', 
              alignItems: 'center',
              marginTop: 12 
            }}>
              <Text style={{ color: '#999', fontSize: 12 }}>
                {newPostContent.length}/500
              </Text>
              <TouchableOpacity
                style={{
                  backgroundColor: submitting ? '#ccc' : '#07C160',
                  paddingHorizontal: 24,
                  paddingVertical: 8,
                  borderRadius: 20,
                }}
                onPress={submitPost}
                disabled={submitting || !newPostContent.trim()}
              >
                <Text style={{ color: '#fff', fontWeight: '600' }}>
                  {submitting ? '发布中...' : '发布'}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        )}

        {/* 动态列表 */}
        {posts.length === 0 ? (
          <View style={{ alignItems: 'center', padding: 40 }}>
            <Text style={{ color: '#999', fontSize: 16 }}>暂无动态</Text>
          </View>
        ) : (
          posts.map((post) => (
            <PostItem
              key={post.id}
              post={post}
              currentUser={user}
              onLike={() => toggleLike(post)}
              onRefresh={loadPosts}
            />
          ))
        )}
      </ScrollView>
    </View>
  );
};

// 动态项组件
interface PostItemProps {
  post: Post;
  currentUser: any;
  onLike: () => void;
  onRefresh: () => void;
}

const PostItem: React.FC<PostItemProps> = ({ post, currentUser, onLike }) => {
  const [showComments, setShowComments] = useState(false);
  const [newComment, setNewComment] = useState('');
  const [comments, setComments] = useState<Comment[]>([]);
  const [loadingComments, setLoadingComments] = useState(false);

  // 加载评论
  const loadComments = async () => {
    setLoadingComments(true);
    try {
      const result = await SocialService.getPostComments(post.id);
      if (result.error) {
        console.error('加载评论失败:', result.error);
      } else {
        setComments(result.data);
      }
    } catch (error) {
      console.error('加载评论错误:', error);
    } finally {
      setLoadingComments(false);
    }
  };

  // 切换评论显示
  const toggleComments = () => {
    if (!showComments) {
      loadComments();
    }
    setShowComments(!showComments);
  };

  // 发布评论
  const submitComment = async () => {
    if (!newComment.trim() || !currentUser) return;

    try {
      const result = await SocialService.addComment(post.id, newComment.trim());
      if (result.error) {
        Alert.alert('错误', '评论失败：' + result.error.message);
      } else {
        setNewComment('');
        await loadComments();
        onRefresh(); // 更新动态的评论数
      }
    } catch (error) {
      console.error('评论错误:', error);
      Alert.alert('错误', '评论时出现异常');
    }
  };

  // 检查是否已点赞
  const isLiked = post.likes?.some(like => like.user_id === currentUser?.id);

  return (
    <View style={{
      backgroundColor: '#fff',
      marginHorizontal: 16,
      marginBottom: 12,
      padding: 16,
      borderRadius: 12,
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 1 },
      shadowOpacity: 0.1,
      shadowRadius: 2,
      elevation: 2,
    }}>
      {/* 用户信息 */}
      <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 12 }}>
        <Image
          source={{ uri: post.author?.avatar_url || 'https://via.placeholder.com/40' }}
          style={{ width: 40, height: 40, borderRadius: 20, marginRight: 12 }}
        />
        <View style={{ flex: 1 }}>
          <Text style={{ fontSize: 16, fontWeight: '600' }}>
            {post.author?.full_name || '匿名用户'}
          </Text>
          <Text style={{ fontSize: 12, color: '#999' }}>
            {formatTime(post.created_at)}
          </Text>
        </View>
      </View>

      {/* 动态内容 */}
      <Text style={{ fontSize: 16, lineHeight: 24, marginBottom: 12 }}>
        {post.content}
      </Text>

      {/* 图片 */}
      {post.image_urls && post.image_urls.length > 0 && (
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginBottom: 12 }}>
          {post.image_urls.map((url, index) => (
            <Image
              key={index}
              source={{ uri: url }}
              style={{
                width: '48%',
                height: 120,
                borderRadius: 8,
                marginRight: '4%',
                marginBottom: 8,
              }}
            />
          ))}
        </View>
      )}

      {/* 互动按钮 */}
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
        <View style={{ flexDirection: 'row' }}>
          <TouchableOpacity
            style={{ flexDirection: 'row', alignItems: 'center', marginRight: 20 }}
            onPress={onLike}
          >
            <Text style={{ fontSize: 16, marginRight: 4 }}>
              {isLiked ? '👍' : '👍'}
            </Text>
            <Text style={{ color: isLiked ? '#07C160' : '#666' }}>
              {post.like_count}
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={{ flexDirection: 'row', alignItems: 'center' }}
            onPress={toggleComments}
          >
            <Text style={{ fontSize: 16, marginRight: 4 }}>💬</Text>
            <Text style={{ color: '#666' }}>
              {post.comment_count}
            </Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* 评论区域 */}
      {showComments && (
        <View style={{ marginTop: 16, paddingTop: 16, borderTopWidth: 1, borderTopColor: '#f0f0f0' }}>
          {/* 评论输入框 */}
          {currentUser && (
            <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 12 }}>
              <TextInput
                style={{
                  flex: 1,
                  backgroundColor: '#f5f5f5',
                  borderRadius: 20,
                  paddingHorizontal: 16,
                  paddingVertical: 8,
                  marginRight: 8,
                }}
                placeholder="写下你的评论..."
                value={newComment}
                onChangeText={setNewComment}
                maxLength={200}
              />
              <TouchableOpacity
                style={{
                  backgroundColor: '#07C160',
                  paddingHorizontal: 16,
                  paddingVertical: 8,
                  borderRadius: 20,
                }}
                onPress={submitComment}
                disabled={!newComment.trim()}
              >
                <Text style={{ color: '#fff', fontSize: 14 }}>发送</Text>
              </TouchableOpacity>
            </View>
          )}

          {/* 评论列表 */}
          {loadingComments ? (
            <Text style={{ textAlign: 'center', color: '#999' }}>加载评论中...</Text>
          ) : comments.length === 0 ? (
            <Text style={{ textAlign: 'center', color: '#999' }}>暂无评论</Text>
          ) : (
            comments.map((comment) => (
              <View key={comment.id} style={{ marginBottom: 12 }}>
                <View style={{ flexDirection: 'row', alignItems: 'flex-start' }}>
                  <Image
                    source={{ uri: comment.author?.avatar_url || 'https://via.placeholder.com/32' }}
                    style={{ width: 32, height: 32, borderRadius: 16, marginRight: 8 }}
                  />
                  <View style={{ flex: 1 }}>
                    <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 4 }}>
                      <Text style={{ fontSize: 14, fontWeight: '600', marginRight: 8 }}>
                        {comment.author?.full_name || '匿名用户'}
                      </Text>
                      <Text style={{ fontSize: 12, color: '#999' }}>
                        {formatTime(comment.created_at)}
                      </Text>
                    </View>
                    <Text style={{ fontSize: 14, lineHeight: 20 }}>
                      {comment.content}
                    </Text>
                  </View>
                </View>
              </View>
            ))
          )}
        </View>
      )}
    </View>
  );
};

// 格式化时间函数
const formatTime = (timestamp: string) => {
  const date = new Date(timestamp);
  const now = new Date();
  const diff = now.getTime() - date.getTime();
  const minutes = Math.floor(diff / (1000 * 60));
  const hours = Math.floor(diff / (1000 * 60 * 60));
  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  
  if (minutes < 1) {
    return '刚刚';
  } else if (minutes < 60) {
    return `${minutes}分钟前`;
  } else if (hours < 24) {
    return `${hours}小时前`;
  } else if (days < 7) {
    return `${days}天前`;
  } else {
    return date.toLocaleDateString('zh-CN');
  }
};