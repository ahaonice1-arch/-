// =====================================================
// 好友管理组件 - FriendsScreen.tsx
// 好友列表、好友请求、搜索添加好友
// =====================================================

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  TextInput,
  TouchableOpacity,
  Image,
  Alert,
  RefreshControl,
} from 'react-native';
import { SocialService, UserProfile, Friendship } from '../services/supabaseSocial';
import { useAuthStore } from '../stores/authStore';

interface FriendsScreenProps {
  navigation: any;
}

export const FriendsScreen: React.FC<FriendsScreenProps> = ({ navigation }) => {
  const { user } = useAuthStore();
  const [activeTab, setActiveTab] = useState<'friends' | 'requests' | 'search'>('friends');
  const [friends, setFriends] = useState<UserProfile[]>([]);
  const [friendRequests, setFriendRequests] = useState<Friendship[]>([]);
  const [searchResults, setSearchResults] = useState<UserProfile[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searching, setSearching] = useState(false);

  // 加载好友列表
  const loadFriends = async () => {
    try {
      const result = await SocialService.getFriends();
      if (result.error) {
        Alert.alert('错误', '加载好友列表失败：' + result.error.message);
      } else {
        setFriends(result.data);
      }
    } catch (error) {
      console.error('加载好友列表错误:', error);
      Alert.alert('错误', '加载好友列表时出现异常');
    }
  };

  // 加载好友请求
  const loadFriendRequests = async () => {
    try {
      const result = await SocialService.getFriendRequests();
      if (result.error) {
        Alert.alert('错误', '加载好友请求失败：' + result.error.message);
      } else {
        setFriendRequests(result.data);
      }
    } catch (error) {
      console.error('加载好友请求错误:', error);
      Alert.alert('错误', '加载好友请求时出现异常');
    }
  };

  // 刷新数据
  const onRefresh = () => {
    setRefreshing(true);
    loadFriends();
    loadFriendRequests();
    setRefreshing(false);
  };

  // 搜索用户
  const searchUsers = async () => {
    if (!searchQuery.trim()) {
      setSearchResults([]);
      return;
    }

    setSearching(true);
    try {
      const result = await SocialService.searchUsers(searchQuery.trim());
      if (result.error) {
        Alert.alert('错误', '搜索失败：' + result.error.message);
      } else {
        // 过滤掉自己
        const filteredResults = result.data.filter(u => u.id !== user?.id);
        setSearchResults(filteredResults);
      }
    } catch (error) {
      console.error('搜索用户错误:', error);
      Alert.alert('错误', '搜索时出现异常');
    } finally {
      setSearching(false);
    }
  };

  // 发送好友请求
  const sendFriendRequest = async (userId: string) => {
    try {
      const result = await SocialService.sendFriendRequest(userId);
      if (result.error) {
        Alert.alert('错误', '发送好友请求失败：' + result.error.message);
      } else {
        Alert.alert('成功', '好友请求已发送！');
        setSearchResults(prev => 
          prev.map(u => u.id === userId ? { ...u, requested: true } : u)
        );
      }
    } catch (error) {
      console.error('发送好友请求错误:', error);
      Alert.alert('错误', '发送好友请求时出现异常');
    }
  };

  // 接受好友请求
  const acceptFriendRequest = async (requestId: string) => {
    try {
      const result = await SocialService.acceptFriendRequest(requestId);
      if (result.error) {
        Alert.alert('错误', '接受好友请求失败：' + result.error.message);
      } else {
        Alert.alert('成功', '好友请求已接受！');
        await loadFriends();
        await loadFriendRequests();
      }
    } catch (error) {
      console.error('接受好友请求错误:', error);
      Alert.alert('错误', '接受好友请求时出现异常');
    }
  };

  // 拒绝好友请求
  const rejectFriendRequest = async (requestId: string) => {
    Alert.alert(
      '确认拒绝',
      '确定要拒绝这个好友请求吗？',
      [
        { text: '取消', style: 'cancel' },
        {
          text: '拒绝',
          style: 'destructive',
          onPress: async () => {
            try {
              const { error } = await SocialService.acceptFriendRequest(requestId); // 这里应该使用拒绝接口
              if (error) {
                Alert.alert('错误', '拒绝好友请求失败：' + error.message);
              } else {
                await loadFriendRequests();
              }
            } catch (error) {
              console.error('拒绝好友请求错误:', error);
              Alert.alert('错误', '拒绝好友请求时出现异常');
            }
          }
        }
      ]
    );
  };

  // 格式化时间
  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleDateString('zh-CN');
  };

  useEffect(() => {
    if (activeTab === 'friends') {
      loadFriends();
    } else if (activeTab === 'requests') {
      loadFriendRequests();
    }
  }, [activeTab]);

  // 初始化加载
  useEffect(() => {
    loadFriends();
    setLoading(false);
  }, []);

  if (loading) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <Text>加载中...</Text>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: '#f5f5f5' }}>
      {/* 标题栏 */}
      <View style={{ 
        backgroundColor: '#fff',
        paddingHorizontal: 16,
        paddingVertical: 12,
        borderBottomWidth: 1,
        borderBottomColor: '#f0f0f0',
      }}>
        <Text style={{ fontSize: 18, fontWeight: '600', textAlign: 'center' }}>
          好友
        </Text>
      </View>

      {/* Tab切换 */}
      <View style={{ 
        flexDirection: 'row',
        backgroundColor: '#fff',
        borderBottomWidth: 1,
        borderBottomColor: '#f0f0f0',
      }}>
        {[
          { key: 'friends', label: '好友列表' },
          { key: 'requests', label: '好友请求' },
          { key: 'search', label: '添加好友' },
        ].map(tab => (
          <TouchableOpacity
            key={tab.key}
            style={{
              flex: 1,
              paddingVertical: 12,
              alignItems: 'center',
              borderBottomWidth: activeTab === tab.key ? 2 : 0,
              borderBottomColor: activeTab === tab.key ? '#07C160' : 'transparent',
            }}
            onPress={() => setActiveTab(tab.key as any)}
          >
            <Text style={{
              fontSize: 14,
              color: activeTab === tab.key ? '#07C160' : '#666',
              fontWeight: activeTab === tab.key ? '600' : 'normal',
            }}>
              {tab.label}
              {tab.key === 'requests' && friendRequests.length > 0 && (
                <Text style={{ color: '#FA5151', marginLeft: 4 }}>
                  ({friendRequests.length})
                </Text>
              )}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* 内容区域 */}
      <ScrollView
        style={{ flex: 1 }}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        {/* 好友列表 */}
        {activeTab === 'friends' && (
          <View style={{ padding: 16 }}>
            {friends.length === 0 ? (
              <View style={{ alignItems: 'center', padding: 40 }}>
                <Text style={{ color: '#999', fontSize: 16 }}>暂无好友</Text>
                <TouchableOpacity
                  style={{
                    marginTop: 16,
                    backgroundColor: '#07C160',
                    paddingHorizontal: 24,
                    paddingVertical: 12,
                    borderRadius: 24,
                  }}
                  onPress={() => setActiveTab('search')}
                >
                  <Text style={{ color: '#fff', fontWeight: '600' }}>
                    去找朋友
                  </Text>
                </TouchableOpacity>
              </View>
            ) : (
              friends.map(friend => (
                <FriendItem
                  key={friend.id}
                  friend={friend}
                  onChat={() => navigation.navigate('Chat', { user: friend })}
                />
              ))
            )}
          </View>
        )}

        {/* 好友请求 */}
        {activeTab === 'requests' && (
          <View style={{ padding: 16 }}>
            {friendRequests.length === 0 ? (
              <View style={{ alignItems: 'center', padding: 40 }}>
                <Text style={{ color: '#999', fontSize: 16 }}>暂无好友请求</Text>
              </View>
            ) : (
              friendRequests.map(request => (
                <FriendRequestItem
                  key={request.id}
                  request={request}
                  onAccept={() => acceptFriendRequest(request.id)}
                  onReject={() => rejectFriendRequest(request.id)}
                />
              ))
            )}
          </View>
        )}

        {/* 搜索用户 */}
        {activeTab === 'search' && (
          <View style={{ padding: 16 }}>
            {/* 搜索框 */}
            <View style={{
              flexDirection: 'row',
              backgroundColor: '#fff',
              borderRadius: 8,
              paddingHorizontal: 12,
              paddingVertical: 8,
              marginBottom: 16,
              shadowColor: '#000',
              shadowOffset: { width: 0, height: 1 },
              shadowOpacity: 0.1,
              shadowRadius: 2,
              elevation: 2,
            }}>
              <TextInput
                style={{ flex: 1, fontSize: 16 }}
                placeholder="搜索用户名或姓名..."
                value={searchQuery}
                onChangeText={setSearchQuery}
                onSubmitEditing={searchUsers}
              />
              <TouchableOpacity
                style={{
                  backgroundColor: '#07C160',
                  paddingHorizontal: 16,
                  paddingVertical: 8,
                  borderRadius: 6,
                }}
                onPress={searchUsers}
                disabled={searching}
              >
                <Text style={{ color: '#fff', fontWeight: '600' }}>
                  {searching ? '搜索中...' : '搜索'}
                </Text>
              </TouchableOpacity>
            </View>

            {/* 搜索结果 */}
            {searchResults.length === 0 && searchQuery ? (
              <View style={{ alignItems: 'center', padding: 40 }}>
                <Text style={{ color: '#999', fontSize: 16 }}>未找到相关用户</Text>
              </View>
            ) : (
              searchResults.map(user => (
                <SearchUserItem
                  key={user.id}
                  user={user}
                  onAdd={() => sendFriendRequest(user.id)}
                />
              ))
            )}
          </View>
        )}
      </ScrollView>
    </View>
  );
};

// 好友项组件
interface FriendItemProps {
  friend: UserProfile;
  onChat: () => void;
}

const FriendItem: React.FC<FriendItemProps> = ({ friend, onChat }) => {
  return (
    <View style={{
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: '#fff',
      borderRadius: 12,
      padding: 16,
      marginBottom: 8,
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 1 },
      shadowOpacity: 0.1,
      shadowRadius: 2,
      elevation: 2,
    }}>
      <View style={{ position: 'relative' }}>
        <Image
          source={{ uri: friend.avatar_url || 'https://via.placeholder.com/48' }}
          style={{ width: 48, height: 48, borderRadius: 24 }}
        />
        {friend.is_online && (
          <View style={{
            position: 'absolute',
            bottom: 0,
            right: 0,
            width: 12,
            height: 12,
            backgroundColor: '#07C160',
            borderRadius: 6,
            borderWidth: 2,
            borderColor: '#fff',
          }} />
        )}
      </View>
      
      <View style={{ flex: 1, marginLeft: 12 }}>
        <Text style={{ fontSize: 16, fontWeight: '600', marginBottom: 4 }}>
          {friend.full_name}
        </Text>
        <Text style={{ fontSize: 12, color: '#999' }}>
          {friend.bio || '这个人很懒，什么都没有留下...'}
        </Text>
        {!friend.is_online && friend.last_seen && (
          <Text style={{ fontSize: 12, color: '#999', marginTop: 2 }}>
            最后在线: {new Date(friend.last_seen).toLocaleDateString('zh-CN')}
          </Text>
        )}
      </View>

      <TouchableOpacity
        style={{
          backgroundColor: '#07C160',
          paddingHorizontal: 16,
          paddingVertical: 8,
          borderRadius: 20,
        }}
        onPress={onChat}
      >
        <Text style={{ color: '#fff', fontSize: 14, fontWeight: '600' }}>
          聊天
        </Text>
      </TouchableOpacity>
    </View>
  );
};

// 好友请求项组件
interface FriendRequestItemProps {
  request: Friendship;
  onAccept: () => void;
  onReject: () => void;
}

const FriendRequestItem: React.FC<FriendRequestItemProps> = ({ 
  request, 
  onAccept, 
  onReject 
}) => {
  return (
    <View style={{
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: '#fff',
      borderRadius: 12,
      padding: 16,
      marginBottom: 8,
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 1 },
      shadowOpacity: 0.1,
      shadowRadius: 2,
      elevation: 2,
    }}>
      <Image
        source={{ uri: request.requester?.avatar_url || 'https://via.placeholder.com/48' }}
        style={{ width: 48, height: 48, borderRadius: 24 }}
      />
      
      <View style={{ flex: 1, marginLeft: 12 }}>
        <Text style={{ fontSize: 16, fontWeight: '600', marginBottom: 4 }}>
          {request.requester?.full_name || '匿名用户'}
        </Text>
        <Text style={{ fontSize: 12, color: '#999' }}>
          请求时间: {new Date(request.created_at).toLocaleDateString('zh-CN')}
        </Text>
      </View>

      <View style={{ flexDirection: 'row' }}>
        <TouchableOpacity
          style={{
            backgroundColor: '#07C160',
            paddingHorizontal: 16,
            paddingVertical: 8,
            borderRadius: 20,
            marginRight: 8,
          }}
          onPress={onAccept}
        >
          <Text style={{ color: '#fff', fontSize: 14, fontWeight: '600' }}>
            接受
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={{
            backgroundColor: '#f5f5f5',
            paddingHorizontal: 16,
            paddingVertical: 8,
            borderRadius: 20,
          }}
          onPress={onReject}
        >
          <Text style={{ color: '#666', fontSize: 14, fontWeight: '600' }}>
            拒绝
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

// 搜索用户项组件
interface SearchUserItemProps {
  user: UserProfile;
  onAdd: () => void;
}

const SearchUserItem: React.FC<SearchUserItemProps> = ({ user, onAdd }) => {
  return (
    <View style={{
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: '#fff',
      borderRadius: 12,
      padding: 16,
      marginBottom: 8,
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 1 },
      shadowOpacity: 0.1,
      shadowRadius: 2,
      elevation: 2,
    }}>
      <Image
        source={{ uri: user.avatar_url || 'https://via.placeholder.com/48' }}
        style={{ width: 48, height: 48, borderRadius: 24 }}
      />
      
      <View style={{ flex: 1, marginLeft: 12 }}>
        <Text style={{ fontSize: 16, fontWeight: '600', marginBottom: 4 }}>
          {user.full_name}
        </Text>
        <Text style={{ fontSize: 12, color: '#999' }}>
          @{user.username || '未设置用户名'}
        </Text>
        {user.bio && (
          <Text style={{ fontSize: 12, color: '#666', marginTop: 2 }}>
            {user.bio}
          </Text>
        )}
      </View>

      <TouchableOpacity
        style={{
          backgroundColor: '#07C160',
          paddingHorizontal: 16,
          paddingVertical: 8,
          borderRadius: 20,
        }}
        onPress={onAdd}
      >
        <Text style={{ color: '#fff', fontSize: 14, fontWeight: '600' }}>
          添加
        </Text>
      </TouchableOpacity>
    </View>
  );
};