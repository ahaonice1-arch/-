// =====================================================
// 社交发现和推荐系统 - socialDiscovery.ts
// 用户推荐、内容发现、兴趣匹配
// =====================================================

import { supabase } from './supabase';
import { SocialService, UserProfile } from './supabaseSocial';

export interface UserRecommendation {
  user: UserProfile;
  score: number;
  reasons: string[];
  mutualFriends?: UserProfile[];
  commonInterests?: string[];
  activityScore: number;
  reputationScore: number;
}

export interface DiscoveryContent {
  id: string;
  type: 'user' | 'post' | 'group' | 'event';
  title: string;
  description: string;
  preview: any;
  relevance_score: number;
  category: string;
  tags: string[];
  created_at: string;
}

export interface UserInterests {
  user_id: string;
  interests: {
    category: string;
    tags: string[];
    weight: number;
  }[];
  activity_preferences: {
    time_slots: number[]; // 0-23小时
    interaction_types: string[];
  };
  social_preferences: {
    age_range: [number, number];
    location_radius: number;
    languages: string[];
  };
}

export interface GroupRecommendation {
  group: {
    id: string;
    name: string;
    description: string;
    member_count: number;
    category: string;
    is_public: boolean;
  };
  relevance_score: number;
  reasons: string[];
  member_similarity: number;
}

export interface ActivityRecommendation {
  activity: {
    id: string;
    type: string;
    title: string;
    description: string;
    location?: string;
    start_time: string;
    end_time?: string;
    participant_count: number;
    max_participants?: number;
  };
  relevance_score: number;
  reasons: string[];
  compatibility_score: number;
}

// 社交发现服务类
export class SocialDiscoveryService {
  // 1. 用户推荐算法
  static async getUserRecommendations(
    limit: number = 20, 
    excludeIds: string[] = []
  ): Promise<{ data: UserRecommendation[]; error: any }> {
    const userId = (await supabase.auth.getUser()).data.user?.id;
    if (!userId) return { data: [], error: { message: 'User not authenticated' } };

    try {
      // 获取基础用户数据
      const currentUser = await SocialService.getUserProfile(userId);
      if (currentUser.error) {
        return { data: [], error: currentUser.error };
      }

      // 获取好友列表
      const friendsResult = await SocialService.getFriends();
      const friendIds = friendsResult.data?.map(f => f.id) || [];
      
      // 获取潜在推荐用户
      const { data: candidates, error } = await supabase
        .from('profiles')
        .select('*')
        .neq('id', userId)
        .not('id', 'in', `(${friendIds.concat(excludeIds).join(',')})`)
        .limit(limit * 3); // 获取更多候选者用于筛选

      if (error) {
        return { data: [], error };
      }

      // 计算推荐分数
      const recommendations: UserRecommendation[] = [];
      
      for (const candidate of candidates || []) {
        const score = await this.calculateUserRecommendationScore(
          currentUser.data!,
          candidate,
          friendIds
        );
        
        if (score.score > 0.3) { // 最低分数阈值
          recommendations.push(score);
        }
      }

      // 按分数排序并返回前N个
      recommendations.sort((a, b) => b.score - a.score);
      
      return { 
        data: recommendations.slice(0, limit), 
        error: null 
      };

    } catch (error) {
      console.error('获取用户推荐错误:', error);
      return { data: [], error };
    }
  }

  // 计算用户推荐分数
  private static async calculateUserRecommendationScore(
    currentUser: UserProfile,
    candidate: UserProfile,
    friendIds: string[]
  ): Promise<UserRecommendation> {
    let score = 0;
    const reasons: string[] = [];
    let activityScore = 0;
    let reputationScore = 0;

    // 1. 共同好友加分 (40%)
    const mutualFriends = await this.getMutualFriends(currentUser.id, candidate.id, friendIds);
    const mutualFriendCount = mutualFriends.length;
    
    if (mutualFriendCount > 0) {
      const friendScore = Math.min(mutualFriendCount * 0.2, 0.4);
      score += friendScore;
      reasons.push(`有${mutualFriendCount}个共同好友`);
      activityScore += mutualFriendCount * 0.1;
    }

    // 2. 活跃度评分 (25%)
    const candidateActivity = await this.calculateUserActivity(candidate.id);
    activityScore = candidateActivity.score;
    
    if (candidateActivity.score > 0.7) {
      score += 0.25;
      reasons.push('活跃度高');
    } else if (candidateActivity.score > 0.4) {
      score += 0.15;
      reasons.push('活跃度中等');
    }

    // 3. 兴趣相似度 (20%)
    const interestSimilarity = await this.calculateInterestSimilarity(currentUser.id, candidate.id);
    if (interestSimilarity > 0.5) {
      score += 0.2;
      reasons.push('兴趣相似');
    }

    // 4. 地理位置加分 (10%)
    if (currentUser.bio && candidate.bio) {
      const locationMatch = this.extractLocationMatch(currentUser.bio, candidate.bio);
      if (locationMatch) {
        score += 0.1;
        reasons.push('地理位置相近');
      }
    }

    // 5. 声誉评分 (5%)
    const reputation = await this.calculateUserReputation(candidate.id);
    reputationScore = reputation.score;
    
    if (reputation.score > 0.8) {
      score += 0.05;
      reasons.push('用户评价好');
    }

    return {
      user: candidate,
      score: Math.min(score, 1.0),
      reasons,
      mutualFriends: mutualFriends.slice(0, 3), // 返回最多3个共同好友
      activityScore,
      reputationScore
    };
  }

  // 获取共同好友
  private static async getMutualFriends(
    userId1: string, 
    userId2: string, 
    friendIds: string[]
  ): Promise<UserProfile[]> {
    // 获取用户1的好友
    const user1Friends = await this.getUserFriends(userId1);
    
    // 找出共同好友
    const mutualFriends = user1Friends.filter(friend => 
      friendIds.includes(friend.id)
    );

    return mutualFriends.slice(0, 5); // 返回最多5个
  }

  // 计算用户活跃度
  private static async calculateUserActivity(userId: string): Promise<{ score: number; details: any }> {
    const now = new Date();
    const lastWeek = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    const lastMonth = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

    // 获取最近的活动数据
    const { data: recentPosts } = await supabase
      .from('posts')
      .select('id, created_at')
      .eq('author_id', userId)
      .gte('created_at', lastWeek.toISOString());

    const { data: recentComments } = await supabase
      .from('comments')
      .select('id, created_at')
      .eq('author_id', userId)
      .gte('created_at', lastWeek.toISOString());

    const { data: recentMessages } = await supabase
      .from('messages')
      .select('id, created_at')
      .eq('user_id', userId)
      .gte('created_at', lastWeek.toISOString());

    // 计算活跃度分数
    const postScore = (recentPosts?.length || 0) * 0.4;
    const commentScore = (recentComments?.length || 0) * 0.3;
    const messageScore = (recentMessages?.length || 0) * 0.3;

    const totalScore = Math.min((postScore + commentScore + messageScore) / 10, 1.0);

    return {
      score: totalScore,
      details: {
        posts: recentPosts?.length || 0,
        comments: recentComments?.length || 0,
        messages: recentMessages?.length || 0
      }
    };
  }

  // 计算兴趣相似度
  private static async calculateInterestSimilarity(userId1: string, userId2: string): Promise<number> {
    // 这里简化处理，实际应用中需要更复杂的兴趣分析
    // 可以基于用户资料、发帖内容、互动行为等
    
    const { data: user1Data } = await supabase
      .from('profiles')
      .select('bio, full_name')
      .eq('id', userId1)
      .single();

    const { data: user2Data } = await supabase
      .from('profiles')
      .select('bio, full_name')
      .eq('id', userId2)
      .single();

    if (!user1Data?.bio || !user2Data?.bio) {
      return 0;
    }

    // 简单的关键词匹配
    const keywords1 = this.extractKeywords(user1Data.bio);
    const keywords2 = this.extractKeywords(user2Data.bio);
    
    const intersection = keywords1.filter(kw => keywords2.includes(kw));
    const union = [...new Set([...keywords1, ...keywords2])];
    
    return intersection.length / union.length;
  }

  // 提取位置信息匹配
  private static extractLocationMatch(bio1: string, bio2: string): boolean {
    const locations = ['北京', '上海', '广州', '深圳', '杭州', '南京', '成都', '武汉'];
    
    const location1 = locations.find(loc => bio1.includes(loc));
    const location2 = locations.find(loc => bio2.includes(loc));
    
    return location1 && location2 && location1 === location2;
  }

  // 计算用户声誉
  private static async calculateUserReputation(userId: string): Promise<{ score: number; details: any }> {
    // 获取用户的点赞和评论数据
    const { data: receivedLikes } = await supabase
      .from('post_likes')
      .select('id', { count: 'exact' })
      .eq('user_id', userId);

    const { data: receivedComments } = await supabase
      .from('comments')
      .select('id', { count: 'exact' })
      .eq('author_id', userId);

    const { data: sentRequests } = await supabase
      .from('friendships')
      .select('id', { count: 'exact' })
      .eq('requester_id', userId)
      .eq('status', 'accepted');

    // 计算声誉分数
    const likeScore = Math.min((receivedLikes?.length || 0) / 100, 0.4);
    const commentScore = Math.min((receivedComments?.length || 0) / 50, 0.3);
    const socialScore = Math.min((sentRequests?.length || 0) / 20, 0.3);

    const totalScore = likeScore + commentScore + socialScore;

    return {
      score: Math.min(totalScore, 1.0),
      details: {
        likes: receivedLikes?.length || 0,
        comments: receivedComments?.length || 0,
        socialConnections: sentRequests?.length || 0
      }
    };
  }

  // 2. 内容发现
  static async getDiscoveryContent(
    categories: string[] = [],
    limit: number = 50
  ): Promise<{ data: DiscoveryContent[]; error: any }> {
    try {
      const content: DiscoveryContent[] = [];

      // 发现热门用户
      const { data: trendingUsers } = await this.getTrendingUsers(10);
      content.push(...trendingUsers);

      // 发现优质动态
      const { data: trendingPosts } = await this.getTrendingPosts(20);
      content.push(...trendingPosts);

      // 发现活跃群组
      const { data: activeGroups } = await this.getActiveGroups(10);
      content.push(...activeGroups);

      // 按类别筛选
      let filteredContent = content;
      if (categories.length > 0) {
        filteredContent = content.filter(item => 
          categories.includes(item.category)
        );
      }

      // 按相关性排序
      filteredContent.sort((a, b) => b.relevance_score - a.relevance_score);

      return {
        data: filteredContent.slice(0, limit),
        error: null
      };

    } catch (error) {
      console.error('获取发现内容错误:', error);
      return { data: [], error };
    }
  }

  // 获取热门用户
  private static async getTrendingUsers(limit: number): Promise<DiscoveryContent[]> {
    const { data: users } = await supabase
      .from('profiles')
      .select(`
        *,
        posts:posts(count),
        received_likes:post_likes(count)
      `)
      .limit(limit * 2);

    if (!users) return [];

    // 计算热度分数
    const trendingUsers = users
      .map(user => {
        const activityScore = (user.posts?.length || 0) * 0.6;
        const popularityScore = (user.received_likes?.length || 0) * 0.4;
        const totalScore = activityScore + popularityScore;

        return {
          id: user.id,
          type: 'user' as const,
          title: user.full_name,
          description: user.bio || '这个人很懒，什么都没有留下...',
          preview: {
            avatar_url: user.avatar_url,
            activity_count: user.posts?.length || 0,
            popularity_score: totalScore
          },
          relevance_score: Math.min(totalScore / 100, 1.0),
          category: 'user',
          tags: ['热门用户', '活跃用户'],
          created_at: user.created_at
        };
      })
      .sort((a, b) => b.relevance_score - a.relevance_score)
      .slice(0, limit);

    return trendingUsers;
  }

  // 获取热门动态
  private static async getTrendingPosts(limit: number): Promise<DiscoveryContent[]> {
    const { data: posts } = await supabase
      .from('posts')
      .select(`
        *,
        author:profiles!posts_author_id_fkey(id, full_name, avatar_url),
        likes:post_likes(count),
        comments(count)
      `)
      .eq('visibility', 'public')
      .order('created_at', { ascending: false })
      .limit(limit * 2);

    if (!posts) return [];

    const trendingPosts = posts
      .map(post => {
        const engagementScore = (post.likes?.[0]?.count || 0) + (post.comments?.[0]?.count || 0);
        const recencyScore = this.calculateRecencyScore(post.created_at);

        return {
          id: post.id,
          type: 'post' as const,
          title: post.content.substring(0, 50) + '...',
          description: post.content,
          preview: {
            author: post.author,
            like_count: post.likes?.[0]?.count || 0,
            comment_count: post.comments?.[0]?.count || 0,
            image_urls: post.image_urls
          },
          relevance_score: (engagementScore * 0.7 + recencyScore * 0.3),
          category: 'content',
          tags: ['热门动态', '优质内容'],
          created_at: post.created_at
        };
      })
      .sort((a, b) => b.relevance_score - a.relevance_score)
      .slice(0, limit);

    return trendingPosts;
  }

  // 获取活跃群组
  private static async getActiveGroups(limit: number): Promise<DiscoveryContent[]> {
    const { data: groups } = await supabase
      .from('chats')
      .select(`
        *,
        settings:chat_settings(*),
        members:chat_members(count),
        recent_messages:messages(created_at)
      `)
      .eq('is_group', true)
      .eq('settings.is_public', true)
      .limit(limit * 2);

    if (!groups) return [];

    const activeGroups = groups
      .map(group => {
        const memberCount = group.members?.[0]?.count || 0;
        const activityScore = this.calculateGroupActivity(group.recent_messages || []);

        return {
          id: group.id,
          type: 'group' as const,
          title: group.name,
          description: group.settings?.[0]?.description || '活跃的群组',
          preview: {
            member_count: memberCount,
            activity_score: activityScore,
            avatar_url: group.settings?.[0]?.avatar_url
          },
          relevance_score: Math.min((memberCount * 0.3 + activityScore * 0.7) / 50, 1.0),
          category: 'group',
          tags: ['活跃群组', '热门群组'],
          created_at: group.created_at
        };
      })
      .sort((a, b) => b.relevance_score - a.relevance_score)
      .slice(0, limit);

    return activeGroups;
  }

  // 3. 群组推荐
  static async getGroupRecommendations(limit: number = 10): Promise<{ data: GroupRecommendation[]; error: any }> {
    const userId = (await supabase.auth.getUser()).data.user?.id;
    if (!userId) return { data: [], error: { message: 'User not authenticated' } };

    try {
      // 获取公开群组
      const { data: publicGroups } = await supabase
        .from('chats')
        .select(`
          *,
          settings:chat_settings(*),
          members:chat_members(count)
        `)
        .eq('is_group', true)
        .eq('settings.is_public', true);

      // 获取用户已加入的群组
      const { data: userGroups } = await supabase
        .from('chat_members')
        .select('chat_id')
        .eq('user_id', userId);

      const userGroupIds = userGroups?.map(ug => ug.chat_id) || [];

      // 过滤掉已加入的群组
      const availableGroups = (publicGroups || []).filter(group => 
        !userGroupIds.includes(group.id)
      );

      // 计算推荐分数
      const recommendations: GroupRecommendation[] = [];
      
      for (const group of availableGroups) {
        const score = await this.calculateGroupRecommendationScore(userId, group);
        if (score.score > 0.2) {
          recommendations.push(score);
        }
      }

      recommendations.sort((a, b) => b.score - a.score);

      return {
        data: recommendations.slice(0, limit),
        error: null
      };

    } catch (error) {
      console.error('获取群组推荐错误:', error);
      return { data: [], error };
    }
  }

  // 4. 活动推荐
  static async getActivityRecommendations(limit: number = 10): Promise<{ data: ActivityRecommendation[]; error: any }> {
    // 这里简化处理，实际应用中需要创建events表
    const sampleActivities = [
      {
        id: '1',
        type: '技术分享',
        title: '前端技术分享会',
        description: 'React和Vue的最新特性讨论',
        location: '北京',
        start_time: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
        participant_count: 15,
        max_participants: 50
      },
      {
        id: '2',
        type: '社交活动',
        title: '周末户外徒步',
        description: '一起去爬山，认识新朋友',
        location: '北京',
        start_time: new Date(Date.now() + 48 * 60 * 60 * 1000).toISOString(),
        participant_count: 8,
        max_participants: 20
      }
    ];

    const recommendations: ActivityRecommendation[] = sampleActivities.map(activity => ({
      activity,
      relevance_score: Math.random() * 0.5 + 0.5, // 模拟分数
      reasons: ['符合你的兴趣', '时间合适'],
      compatibility_score: Math.random() * 0.4 + 0.6
    }));

    return {
      data: recommendations.slice(0, limit),
      error: null
    };
  }

  // 辅助方法
  private static async getUserFriends(userId: string): Promise<UserProfile[]> {
    // 这里简化处理，实际应用中需要从friendships表获取
    return [];
  }

  private static extractKeywords(text: string): string[] {
    // 简单的关键词提取
    const keywords = [];
    const techKeywords = ['编程', '技术', '开发', 'AI', '机器学习', '区块链'];
    const interestKeywords = ['旅游', '美食', '运动', '电影', '音乐', '读书'];
    
    techKeywords.forEach(keyword => {
      if (text.includes(keyword)) keywords.push(keyword);
    });
    
    interestKeywords.forEach(keyword => {
      if (text.includes(keyword)) keywords.push(keyword);
    });
    
    return keywords;
  }

  private static calculateRecencyScore(timestamp: string): number {
    const now = new Date();
    const date = new Date(timestamp);
    const hoursDiff = (now.getTime() - date.getTime()) / (1000 * 60 * 60);
    
    if (hoursDiff < 24) return 1.0;
    if (hoursDiff < 72) return 0.8;
    if (hoursDiff < 168) return 0.6;
    return 0.4;
  }

  private static calculateGroupActivity(messages: any[]): number {
    if (!messages || messages.length === 0) return 0;
    
    const now = new Date();
    const recentMessages = messages.filter(msg => {
      const msgDate = new Date(msg.created_at);
      const hoursDiff = (now.getTime() - msgDate.getTime()) / (1000 * 60 * 60);
      return hoursDiff < 24; // 最近24小时的消息
    });
    
    return Math.min(recentMessages.length / 10, 1.0);
  }

  private static async calculateGroupRecommendationScore(
    userId: string, 
    group: any
  ): Promise<GroupRecommendation> {
    let score = 0;
    const reasons: string[] = [];

    // 群组大小匹配
    const memberCount = group.members?.[0]?.count || 0;
    if (memberCount > 10 && memberCount < 100) {
      score += 0.3;
      reasons.push('群组规模适中');
    }

    // 活跃度
    const activityScore = this.calculateGroupActivity(group.recent_messages || []);
    if (activityScore > 0.5) {
      score += 0.4;
      reasons.push('群组很活跃');
    }

    // 公开程度
    if (group.settings?.[0]?.is_public) {
      score += 0.3;
      reasons.push('公开群组');
    }

    return {
      group: {
        id: group.id,
        name: group.name,
        description: group.settings?.[0]?.description || '',
        member_count: memberCount,
        category: '技术',
        is_public: group.settings?.[0]?.is_public || false
      },
      score: Math.min(score, 1.0),
      reasons,
      member_similarity: Math.random() * 0.5 + 0.5
    };
  }

  // 5. 实时推荐更新
  static subscribeToRecommendationUpdates(callback: (updates: any) => void) {
    return supabase
      .channel('recommendations')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'profiles'
        },
        callback
      )
      .subscribe();
  }
}