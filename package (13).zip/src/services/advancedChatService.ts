// =====================================================
// 高级聊天服务 - advancedChatService.ts
// 群聊管理、文件传输、消息状态等功能
// =====================================================

import { supabase } from './supabase';

export interface ChatSettings {
  chat_id: string;
  description?: string;
  avatar_url?: string;
  is_public: boolean;
  allow_invite: boolean;
  max_members: number;
  created_at: string;
  updated_at: string;
}

export interface MessageStatus {
  id: string;
  message_id: string;
  user_id: string;
  status: 'sent' | 'delivered' | 'read';
  updated_at: string;
}

export interface GroupInfo {
  id: string;
  name: string;
  is_group: boolean;
  member_count: number;
  last_message?: string;
  last_message_time?: string;
  is_online?: boolean;
  avatar_url?: string;
  settings?: ChatSettings;
}

export interface FileMessage {
  id: string;
  file_url: string;
  file_name: string;
  file_size: number;
  file_type: string;
  thumbnail_url?: string;
}

export interface EmojiReaction {
  emoji: string;
  user_ids: string[];
  count: number;
}

// 高级聊天服务类
export class AdvancedChatService {
  // 1. 群聊管理功能
  static async createGroupChat(name: string, memberIds: string[], description?: string): Promise<{ data: any; error: any }> {
    const userId = (await supabase.auth.getUser()).data.user?.id;
    if (!userId) return { data: null, error: { message: 'User not authenticated' } };

    // 创建群聊
    const { data: chat, error: chatError } = await supabase
      .from('chats')
      .insert({
        name,
        is_group: true,
        created_by: userId
      })
      .select()
      .single();

    if (chatError) {
      return { data: null, error: chatError };
    }

    // 添加创建者为成员
    const members = [{ chat_id: chat.id, user_id: userId }];
    
    // 添加其他成员
    memberIds.forEach(memberId => {
      members.push({ chat_id: chat.id, user_id: memberId });
    });

    const { error: memberError } = await supabase
      .from('chat_members')
      .insert(members);

    if (memberError) {
      // 如果添加成员失败，删除已创建的群聊
      await supabase.from('chats').delete().eq('id', chat.id);
      return { data: null, error: memberError };
    }

    // 创建群聊设置
    await this.updateChatSettings(chat.id, {
      description: description || '',
      is_public: false,
      allow_invite: true,
      max_members: 500
    });

    return { data: chat, error: null };
  }

  static async updateChatSettings(chatId: string, settings: Partial<ChatSettings>): Promise<{ error: any }> {
    const { error } = await supabase
      .from('chat_settings')
      .upsert({
        chat_id: chatId,
        ...settings
      });
    
    return { error };
  }

  static async getChatSettings(chatId: string): Promise<{ data: ChatSettings | null; error: any }> {
    const { data, error } = await supabase
      .from('chat_settings')
      .select('*')
      .eq('chat_id', chatId)
      .single();
    
    return { data, error };
  }

  static async addMemberToGroup(chatId: string, userId: string): Promise<{ error: any }> {
    const { error } = await supabase
      .from('chat_members')
      .insert({
        chat_id: chatId,
        user_id: userId
      });
    
    return { error };
  }

  static async removeMemberFromGroup(chatId: string, userId: string): Promise<{ error: any }> {
    const { error } = await supabase
      .from('chat_members')
      .delete()
      .eq('chat_id', chatId)
      .eq('user_id', userId);
    
    return { error };
  }

  static async leaveGroup(chatId: string): Promise<{ error: any }> {
    const userId = (await supabase.auth.getUser()).data.user?.id;
    if (!userId) return { error: { message: 'User not authenticated' } };

    const { error } = await supabase
      .from('chat_members')
      .delete()
      .eq('chat_id', chatId)
      .eq('user_id', userId);
    
    return { error };
  }

  static async transferGroupOwnership(chatId: string, newOwnerId: string): Promise<{ error: any }> {
    const userId = (await supabase.auth.getUser()).data.user?.id;
    if (!userId) return { error: { message: 'User not authenticated' } };

    // 更新群聊创建者
    const { error: chatError } = await supabase
      .from('chats')
      .update({ created_by: newOwnerId })
      .eq('id', chatId)
      .eq('created_by', userId);

    if (chatError) {
      return { error: chatError };
    }

    // 更新群成员角色
    await supabase
      .from('user_groups')
      .upsert([
        { user_id: userId, group_name: chatId, role: 'member' },
        { user_id: newOwnerId, group_name: chatId, role: 'admin' }
      ]);

    return { error: null };
  }

  // 2. 文件上传功能
  static async uploadFile(file: File, bucket: string = 'chat-files'): Promise<{ data: any; error: any }> {
    const userId = (await supabase.auth.getUser()).data.user?.id;
    if (!userId) return { data: null, error: { message: 'User not authenticated' } };

    const fileName = `${userId}/${Date.now()}-${file.name}`;
    
    const { data, error } = await supabase.storage
      .from(bucket)
      .upload(fileName, file);

    if (error) {
      return { data: null, error };
    }

    // 获取公开URL
    const { data: urlData } = supabase.storage
      .from(bucket)
      .getPublicUrl(fileName);

    return { 
      data: {
        ...data,
        public_url: urlData.publicUrl
      }, 
      error: null 
    };
  }

  static async sendFileMessage(
    chatId: string, 
    file: File, 
    messageType: 'image' | 'video' | 'audio' | 'document' = 'document'
  ): Promise<{ data: any; error: any }> {
    const userId = (await supabase.auth.getUser()).data.user?.id;
    if (!userId) return { data: null, error: { message: 'User not authenticated' } };

    // 上传文件
    const uploadResult = await this.uploadFile(file);
    if (uploadResult.error) {
      return { data: null, error: uploadResult.error };
    }

    // 发送消息
    const { data, error } = await supabase
      .from('messages')
      .insert({
        chat_id: chatId,
        user_id: userId,
        content: JSON.stringify({
          file_url: uploadResult.data.public_url,
          file_name: file.name,
          file_size: file.size,
          file_type: file.type
        }),
        message_type: messageType
      })
      .select(`
        *,
        user:profiles!messages_user_id_fkey(id, full_name, username, avatar_url)
      `)
      .single();

    return { data, error };
  }

  // 3. 消息状态管理
  static async markMessageAsRead(messageId: string): Promise<{ error: any }> {
    const userId = (await supabase.auth.getUser()).data.user?.id;
    if (!userId) return { error: { message: 'User not authenticated' } };

    const { error } = await supabase
      .from('message_status')
      .upsert({
        message_id: messageId,
        user_id: userId,
        status: 'read'
      });
    
    return { error };
  }

  static async getMessageStatus(messageId: string): Promise<{ data: MessageStatus[]; error: any }> {
    const { data, error } = await supabase
      .from('message_status')
      .select('*')
      .eq('message_id', messageId);
    
    return { data: data || [], error };
  }

  static async getChatMessageStatus(chatId: string): Promise<{ data: { [messageId: string]: MessageStatus[] }; error: any }> {
    // 获取聊天中所有消息的状态
    const { data, error } = await supabase
      .from('message_status')
      .select(`
        *,
        messages!inner(chat_id)
      `)
      .eq('messages.chat_id', chatId);

    if (error) {
      return { data: {}, error };
    }

    // 按消息ID分组
    const statusByMessage: { [messageId: string]: MessageStatus[] } = {};
    data?.forEach(status => {
      if (!statusByMessage[status.message_id]) {
        statusByMessage[status.message_id] = [];
      }
      statusByMessage[status.message_id].push(status);
    });

    return { data: statusByMessage, error: null };
  }

  // 4. 消息表情反应
  static async addEmojiReaction(messageId: string, emoji: string): Promise<{ error: any }> {
    const userId = (await supabase.auth.getUser()).data.user?.id;
    if (!userId) return { error: { message: 'User not authenticated' } };

    // 这里需要创建反应表，暂时简化处理
    // 在实际实现中，需要创建 message_reactions 表
    console.log('Adding emoji reaction:', messageId, emoji, userId);
    
    return { error: null };
  }

  static async removeEmojiReaction(messageId: string, emoji: string): Promise<{ error: any }> {
    const userId = (await supabase.auth.getUser()).data.user?.id;
    if (!userId) return { error: { message: 'User not authenticated' } };

    console.log('Removing emoji reaction:', messageId, emoji, userId);
    
    return { error: null };
  }

  // 5. 消息搜索
  static async searchMessages(chatId: string, query: string, limit: number = 50): Promise<{ data: any[]; error: any }> {
    const { data, error } = await supabase
      .from('messages')
      .select(`
        *,
        user:profiles!messages_user_id_fkey(id, full_name, username, avatar_url)
      `)
      .eq('chat_id', chatId)
      .ilike('content', `%${query}%`)
      .order('created_at', { ascending: false })
      .limit(limit);
    
    return { data: data || [], error };
  }

  // 6. 消息置顶
  static async pinMessage(messageId: string): Promise<{ error: any }> {
    const userId = (await supabase.auth.getUser()).data.user?.id;
    if (!userId) return { error: { message: 'User not authenticated' } };

    // 在实际实现中，需要创建 pinned_messages 表
    console.log('Pinning message:', messageId, userId);
    
    return { error: null };
  }

  static async unpinMessage(messageId: string): Promise<{ error: any }> {
    const userId = (await supabase.auth.getUser()).data.user?.id;
    if (!userId) return { error: { message: 'User not authenticated' } };

    console.log('Unpinning message:', messageId, userId);
    
    return { error: null };
  }

  // 7. 聊天记录导出
  static async exportChatHistory(chatId: string, startDate?: string, endDate?: string): Promise<{ data: any; error: any }> {
    let query = supabase
      .from('messages')
      .select(`
        *,
        user:profiles!messages_user_id_fkey(id, full_name, username)
      `)
      .eq('chat_id', chatId)
      .order('created_at', { ascending: true });

    if (startDate) {
      query = query.gte('created_at', startDate);
    }

    if (endDate) {
      query = query.lte('created_at', endDate);
    }

    const { data, error } = await query;
    
    return { data, error };
  }

  // 8. 群聊信息获取
  static async getGroupInfo(chatId: string): Promise<{ data: GroupInfo | null; error: any }> {
    const { data, error } = await supabase
      .from('chats')
      .select(`
        *,
        settings:chat_settings(*),
        members:chat_members(count),
        last_message:messages(content, created_at)
      `)
      .eq('id', chatId)
      .eq('is_group', true)
      .single();

    if (error) {
      return { data: null, error };
    }

    return {
      data: {
        ...data,
        member_count: data.members?.[0]?.count || 0,
        last_message: data.last_message?.[0]?.content,
        last_message_time: data.last_message?.[0]?.created_at
      },
      error: null
    };
  }

  // 9. 群成员管理
  static async getGroupMembers(chatId: string): Promise<{ data: any[]; error: any }> {
    const { data, error } = await supabase
      .from('chat_members')
      .select(`
        *,
        user:profiles!chat_members_user_id_fkey(id, full_name, username, avatar_url, is_online)
      `)
      .eq('chat_id', chatId);
    
    return { data: data || [], error };
  }

  // 10. 禁言管理（管理员功能）
  static async muteUser(chatId: string, userId: string, duration?: number): Promise<{ error: any }> {
    // 在实际实现中，需要创建 chat_mutes 表
    console.log('Muting user:', chatId, userId, duration);
    
    return { error: null };
  }

  static async unmuteUser(chatId: string, userId: string): Promise<{ error: any }> {
    console.log('Unmuting user:', chatId, userId);
    
    return { error: null };
  }

  // 11. 实时订阅功能
  static subscribeToChatMessages(chatId: string, callback: (message: any) => void) {
    return supabase
      .channel(`chat-${chatId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'messages',
          filter: `chat_id=eq.${chatId}`
        },
        (payload) => {
          callback(payload.new);
        }
      )
      .subscribe();
  }

  static subscribeToMessageStatus(callback: (status: MessageStatus) => void) {
    return supabase
      .channel('message-status')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'message_status'
        },
        (payload) => {
          callback(payload.new as MessageStatus);
        }
      )
      .subscribe();
  }

  static subscribeToGroupChanges(chatId: string, callback: (change: any) => void) {
    return supabase
      .channel(`group-${chatId}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'chat_members',
          filter: `chat_id=eq.${chatId}`
        },
        callback
      )
      .subscribe();
  }

  // 12. 性能优化功能
  static async getChatStats(chatId: string) {
    const { data: messageCount } = await supabase
      .from('messages')
      .select('id', { count: 'exact' })
      .eq('chat_id', chatId);

    const { data: memberCount } = await supabase
      .from('chat_members')
      .select('id', { count: 'exact' })
      .eq('chat_id', chatId);

    const { data: recentMessages } = await supabase
      .from('messages')
      .select('created_at')
      .eq('chat_id', chatId)
      .order('created_at', { ascending: false })
      .limit(10);

    return {
      messageCount: messageCount?.length || 0,
      memberCount: memberCount?.length || 0,
      lastActivity: recentMessages?.[0]?.created_at,
      recentActivityCount: recentMessages?.length || 0
    };
  }

  // 13. 消息归档
  static async archiveChat(chatId: string): Promise<{ error: any }> {
    const userId = (await supabase.auth.getUser()).data.user?.id;
    if (!userId) return { error: { message: 'User not authenticated' } };

    // 在实际实现中，需要创建用户聊天设置表
    console.log('Archiving chat:', chatId, userId);
    
    return { error: null };
  }

  static async unarchiveChat(chatId: string): Promise<{ error: any }> {
    const userId = (await supabase.auth.getUser()).data.user?.id;
    if (!userId) return { error: { message: 'User not authenticated' } };

    console.log('Unarchiving chat:', chatId, userId);
    
    return { error: null };
  }
}