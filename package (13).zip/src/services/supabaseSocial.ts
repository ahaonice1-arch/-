// =====================================================
// 社交功能服务层 - supabaseSocial.ts
// 社交系统核心业务逻辑
// =====================================================

import { supabase } from './supabase';

export interface UserProfile {
  id: string;
  user_id: string;
  full_name: string;
  username?: string;
  avatar_url?: string;
  bio?: string;
  phone?: string;
  is_online: boolean;
  last_seen: string;
  created_at: string;
  updated_at: string;
}

export interface Friendship {
  id: string;
  requester_id: string;
  addressee_id: string;
  status: 'pending' | 'accepted' | 'blocked';
  created_at: string;
  updated_at: string;
}

export interface Post {
  id: string;
  author_id: string;
  content: string;
  image_urls?: string[];
  visibility: 'public' | 'friends' | 'private';
  like_count: number;
  comment_count: number;
  created_at: string;
  updated_at: string;
  // 关联数据
  author?: UserProfile;
  likes?: PostLike[];
  comments?: Comment[];
}

export interface PostLike {
  id: string;
  post_id: string;
  user_id: string;
  created_at: string;
  user?: UserProfile;
}

export interface Comment {
  id: string;
  post_id: string;
  author_id: string;
  content: string;
  parent_id?: string;
  like_count: number;
  created_at: string;
  updated_at: string;
  author?: UserProfile;
  likes?: CommentLike[];
}

export interface CommentLike {
  id: string;
  comment_id: string;
  user_id: string;
  created_at: string;
  user?: UserProfile;
}

export interface Notification {
  id: string;
  recipient_id: string;
  sender_id?: string;
  type: 'like' | 'comment' | 'friend_request' | 'message' | 'mention';
  content: string;
  related_id?: string;
  is_read: boolean;
  created_at: string;
  sender?: UserProfile;
}

export interface UserGroup {
  id: string;
  user_id: string;
  group_name: string;
  role: 'admin' | 'member';
  joined_at: string;
}

// 社交功能服务类
export class SocialService {
  // 1. 用户资料管理
  static async updateProfile(profile: Partial<UserProfile>): Promise<{ data: UserProfile | null; error: any }> {
    const { data, error } = await supabase
      .from('profiles')
      .update(profile)
      .eq('id', profile.id)
      .select()
      .single();
    
    return { data, error };
  }

  static async getUserProfile(userId: string): Promise<{ data: UserProfile | null; error: any }> {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .single();
    
    return { data, error };
  }

  static async searchUsers(query: string): Promise<{ data: UserProfile[]; error: any }> {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .or(`full_name.ilike.%${query}%,username.ilike.%${query}%`)
      .limit(10);
    
    return { data: data || [], error };
  }

  // 2. 好友关系管理
  static async sendFriendRequest(addresseeId: string): Promise<{ data: Friendship | null; error: any }> {
    const { data, error } = await supabase
      .from('friendships')
      .insert({
        requester_id: (await supabase.auth.getUser()).data.user?.id,
        addressee_id: addresseeId,
        status: 'pending'
      })
      .select()
      .single();
    
    return { data, error };
  }

  static async acceptFriendRequest(requestId: string): Promise<{ data: Friendship | null; error: any }> {
    const { data, error } = await supabase
      .from('friendships')
      .update({ status: 'accepted' })
      .eq('id', requestId)
      .select()
      .single();
    
    return { data, error };
  }

  static async getFriends(): Promise<{ data: UserProfile[]; error: any }> {
    const userId = (await supabase.auth.getUser()).data.user?.id;
    if (!userId) return { data: [], error: { message: 'User not authenticated' } };

    const { data, error } = await supabase
      .from('friendships')
      .select(`
        *,
        requester:profiles!friendships_requester_id_fkey(id, full_name, username, avatar_url),
        addressee:profiles!friendships_addressee_id_fkey(id, full_name, username, avatar_url)
      `)
      .or(`requester_id.eq.${userId},addressee_id.eq.${userId}`)
      .eq('status', 'accepted');

    // 处理数据结构
    const friends = data?.map(friendship => {
      return friendship.requester_id === userId ? friendship.addressee : friendship.requester;
    }) || [];

    return { data: friends, error };
  }

  static async getFriendRequests(): Promise<{ data: Friendship[]; error: any }> {
    const userId = (await supabase.auth.getUser()).data.user?.id;
    if (!userId) return { data: [], error: { message: 'User not authenticated' } };

    const { data, error } = await supabase
      .from('friendships')
      .select(`
        *,
        requester:profiles!friendships_requester_id_fkey(id, full_name, username, avatar_url)
      `)
      .eq('addressee_id', userId)
      .eq('status', 'pending');
    
    return { data: data || [], error };
  }

  // 3. 朋友圈动态管理
  static async createPost(content: string, imageUrls: string[] = [], visibility: 'public' | 'friends' | 'private' = 'public'): Promise<{ data: Post | null; error: any }> {
    const userId = (await supabase.auth.getUser()).data.user?.id;
    if (!userId) return { data: null, error: { message: 'User not authenticated' } };

    const { data, error } = await supabase
      .from('posts')
      .insert({
        author_id: userId,
        content,
        image_urls: imageUrls,
        visibility
      })
      .select(`
        *,
        author:profiles!posts_author_id_fkey(id, full_name, username, avatar_url)
      `)
      .single();
    
    return { data, error };
  }

  static async getPosts(limit: number = 20, offset: number = 0): Promise<{ data: Post[]; error: any }> {
    const userId = (await supabase.auth.getUser()).data.user?.id;
    if (!userId) return { data: [], error: { message: 'User not authenticated' } };

    // 获取好友ID列表
    const { data: friends } = await this.getFriends();
    const friendIds = friends?.map(f => f.id) || [];
    const visibleUserIds = [userId, ...friendIds];

    const { data, error } = await supabase
      .from('posts')
      .select(`
        *,
        author:profiles!posts_author_id_fkey(id, full_name, username, avatar_url)
      `)
      .in('author_id', visibleUserIds)
      .in('visibility', ['public', 'friends'])
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);
    
    return { data: data || [], error };
  }

  static async getUserPosts(userId: string, limit: number = 20): Promise<{ data: Post[]; error: any }> {
    const { data, error } = await supabase
      .from('posts')
      .select(`
        *,
        author:profiles!posts_author_id_fkey(id, full_name, username, avatar_url)
      `)
      .eq('author_id', userId)
      .order('created_at', { ascending: false })
      .limit(limit);
    
    return { data: data || [], error };
  }

  static async deletePost(postId: string): Promise<{ error: any }> {
    const { error } = await supabase
      .from('posts')
      .delete()
      .eq('id', postId);
    
    return { error };
  }

  // 4. 点赞功能
  static async likePost(postId: string): Promise<{ data: PostLike | null; error: any }> {
    const userId = (await supabase.auth.getUser()).data.user?.id;
    if (!userId) return { data: null, error: { message: 'User not authenticated' } };

    const { data, error } = await supabase
      .from('post_likes')
      .insert({
        post_id: postId,
        user_id: userId
      })
      .select(`
        *,
        user:profiles!post_likes_user_id_fkey(id, full_name, username, avatar_url)
      `)
      .single();

    // 更新动态点赞数
    if (!error) {
      await supabase.rpc('increment_post_likes', { post_id: postId });
    }
    
    return { data, error };
  }

  static async unlikePost(postId: string): Promise<{ error: any }> {
    const userId = (await supabase.auth.getUser()).data.user?.id;
    if (!userId) return { error: { message: 'User not authenticated' } };

    const { error } = await supabase
      .from('post_likes')
      .delete()
      .eq('post_id', postId)
      .eq('user_id', userId);
    
    // 更新动态点赞数
    if (!error) {
      await supabase.rpc('decrement_post_likes', { post_id: postId });
    }
    
    return { error };
  }

  // 5. 评论功能
  static async addComment(postId: string, content: string, parentId?: string): Promise<{ data: Comment | null; error: any }> {
    const userId = (await supabase.auth.getUser()).data.user?.id;
    if (!userId) return { data: null, error: { message: 'User not authenticated' } };

    const { data, error } = await supabase
      .from('comments')
      .insert({
        post_id: postId,
        author_id: userId,
        content,
        parent_id: parentId
      })
      .select(`
        *,
        author:profiles!comments_author_id_fkey(id, full_name, username, avatar_url)
      `)
      .single();
    
    // 更新动态评论数
    if (!error) {
      await supabase.rpc('increment_post_comments', { post_id: postId });
    }
    
    return { data, error };
  }

  static async getPostComments(postId: string): Promise<{ data: Comment[]; error: any }> {
    const { data, error } = await supabase
      .from('comments')
      .select(`
        *,
        author:profiles!comments_author_id_fkey(id, full_name, username, avatar_url)
      `)
      .eq('post_id', postId)
      .order('created_at', { ascending: true });
    
    return { data: data || [], error };
  }

  static async deleteComment(commentId: string): Promise<{ error: any }> {
    // 先获取评论信息以更新计数
    const { data: comment } = await supabase
      .from('comments')
      .select('post_id')
      .eq('id', commentId)
      .single();

    const { error } = await supabase
      .from('comments')
      .delete()
      .eq('id', commentId);
    
    // 更新动态评论数
    if (!error && comment) {
      await supabase.rpc('decrement_post_comments', { post_id: comment.post_id });
    }
    
    return { error };
  }

  // 6. 通知管理
  static async getNotifications(limit: number = 50): Promise<{ data: Notification[]; error: any }> {
    const userId = (await supabase.auth.getUser()).data.user?.id;
    if (!userId) return { data: [], error: { message: 'User not authenticated' } };

    const { data, error } = await supabase
      .from('notifications')
      .select(`
        *,
        sender:profiles!notifications_sender_id_fkey(id, full_name, username, avatar_url)
      `)
      .eq('recipient_id', userId)
      .order('created_at', { ascending: false })
      .limit(limit);
    
    return { data: data || [], error };
  }

  static async markNotificationAsRead(notificationId: string): Promise<{ error: any }> {
    const { error } = await supabase
      .from('notifications')
      .update({ is_read: true })
      .eq('id', notificationId);
    
    return { error };
  }

  static async markAllNotificationsAsRead(): Promise<{ error: any }> {
    const userId = (await supabase.auth.getUser()).data.user?.id;
    if (!userId) return { error: { message: 'User not authenticated' } };

    const { error } = await supabase
      .from('notifications')
      .update({ is_read: true })
      .eq('recipient_id', userId)
      .eq('is_read', false);
    
    return { error };
  }

  static async createNotification(
    recipientId: string,
    type: Notification['type'],
    content: string,
    relatedId?: string
  ): Promise<{ data: Notification | null; error: any }> {
    const userId = (await supabase.auth.getUser()).data.user?.id;
    if (!userId) return { data: null, error: { message: 'User not authenticated' } };

    const { data, error } = await supabase
      .from('notifications')
      .insert({
        recipient_id: recipientId,
        sender_id: userId,
        type,
        content,
        related_id: relatedId
      })
      .select()
      .single();
    
    return { data, error };
  }

  // 7. 实时订阅
  static subscribeToNotifications(callback: (notification: Notification) => void) {
    return supabase
      .channel('notifications')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'notifications'
        },
        (payload) => {
          callback(payload.new as Notification);
        }
      )
      .subscribe();
  }

  static subscribeToPosts(callback: (post: Post) => void) {
    return supabase
      .channel('posts')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'posts'
        },
        (payload) => {
          callback(payload.new as Post);
        }
      )
      .subscribe();
  }

  static subscribeToComments(callback: (comment: Comment) => void) {
    return supabase
      .channel('comments')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'comments'
        },
        (payload) => {
          callback(payload.new as Comment);
        }
      )
      .subscribe();
  }

  // 8. 统计信息
  static async getUserStats(userId: string) {
    const { data: postsCount } = await supabase
      .from('posts')
      .select('id', { count: 'exact' })
      .eq('author_id', userId);

    const { data: friendsCount } = await supabase
      .from('friendships')
      .select('id', { count: 'exact' })
      .or(`requester_id.eq.${userId},addressee_id.eq.${userId}`)
      .eq('status', 'accepted');

    const { data: unreadNotifications } = await supabase
      .from('notifications')
      .select('id', { count: 'exact' })
      .eq('recipient_id', userId)
      .eq('is_read', false);

    return {
      postsCount: postsCount?.length || 0,
      friendsCount: friendsCount?.length || 0,
      unreadNotifications: unreadNotifications?.length || 0
    };
  }
}