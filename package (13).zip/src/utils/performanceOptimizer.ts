// =====================================================
// 性能优化和用户体验增强 - performanceOptimizer.ts
// 虚拟化列表、懒加载、缓存优化、离线支持
// =====================================================

import { SocialService } from './supabaseSocial';

// 缓存管理类
class CacheManager {
  private cache = new Map<string, { data: any; timestamp: number; ttl: number }>();
  private readonly DEFAULT_TTL = 5 * 60 * 1000; // 5分钟

  set(key: string, data: any, ttl: number = this.DEFAULT_TTL): void {
    this.cache.set(key, {
      data,
      timestamp: Date.now(),
      ttl
    });
  }

  get(key: string): any | null {
    const item = this.cache.get(key);
    if (!item) return null;

    if (Date.now() - item.timestamp > item.ttl) {
      this.cache.delete(key);
      return null;
    }

    return item.data;
  }

  clear(pattern?: string): void {
    if (pattern) {
      const regex = new RegExp(pattern);
      for (const key of this.cache.keys()) {
        if (regex.test(key)) {
          this.cache.delete(key);
        }
      }
    } else {
      this.cache.clear();
    }
  }

  getStats(): { size: number; keys: string[] } {
    return {
      size: this.cache.size,
      keys: Array.from(this.cache.keys())
    };
  }
}

// 网络优化类
class NetworkOptimizer {
  private static readonly TIMEOUT = 15000; // 15秒超时（星链网络优化）
  private static readonly MAX_RETRIES = 3;
  private static readonly BASE_DELAY = 1000;

  static async request<T>(
    operation: () => Promise<T>,
    retries: number = this.MAX_RETRIES,
    delay: number = this.BASE_DELAY
  ): Promise<T> {
    try {
      // 设置超时控制
      const timeoutPromise = new Promise<never>((_, reject) => {
        setTimeout(() => reject(new Error('请求超时')), this.TIMEOUT);
      });

      const result = await Promise.race([operation(), timeoutPromise]);
      return result;

    } catch (error) {
      if (retries > 0) {
        console.log(`请求失败，${delay}ms后重试... (剩余${retries - 1}次)`);
        await new Promise(resolve => setTimeout(resolve, delay));
        return this.request(operation, retries - 1, delay * 2); // 指数退避
      }
      throw error;
    }
  }

  static async batchRequest<T>(
    operations: (() => Promise<T>)[]
  ): Promise<T[]> {
    const results: T[] = [];
    
    // 分批执行，避免并发过多
    const BATCH_SIZE = 5;
    for (let i = 0; i < operations.length; i += BATCH_SIZE) {
      const batch = operations.slice(i, i + BATCH_SIZE);
      const batchResults = await Promise.allSettled(
        batch.map(op => this.request(op))
      );
      
      batchResults.forEach(result => {
        if (result.status === 'fulfilled') {
          results.push(result.value);
        }
      });
    }
    
    return results;
  }
}

// 性能监控类
class PerformanceMonitor {
  private metrics = new Map<string, { startTime: number; endTime?: number }>();

  start(label: string): void {
    this.metrics.set(label, { startTime: performance.now() });
  }

  end(label: string): number | null {
    const metric = this.metrics.get(label);
    if (!metric) return null;

    metric.endTime = performance.now();
    const duration = metric.endTime - metric.startTime;
    
    // 记录性能指标
    console.log(`性能指标 [${label}]: ${duration.toFixed(2)}ms`);
    
    this.metrics.delete(label);
    return duration;
  }

  measureAsync<T>(label: string, operation: () => Promise<T>): Promise<T> {
    this.start(label);
    return operation().finally(() => {
      this.end(label);
    });
  }
}

// 虚拟化列表组件
interface VirtualizedListProps<T> {
  data: T[];
  renderItem: (item: T, index: number) => React.ReactNode;
  itemHeight: number;
  containerHeight: number;
  overscan?: number;
  onEndReached?: () => void;
  onEndReachedThreshold?: number;
}

export class VirtualizedList<T> extends React.Component<VirtualizedListProps<T>> {
  private scrollElement: HTMLDivElement | null = null;
  private state = {
    scrollTop: 0,
    visibleRange: { start: 0, end: 0 }
  };

  componentDidMount() {
    this.updateVisibleRange();
  }

  componentDidUpdate(prevProps: VirtualizedListProps<T>) {
    if (prevProps.data !== this.props.data || 
        prevProps.containerHeight !== this.props.containerHeight ||
        prevProps.itemHeight !== this.props.itemHeight) {
      this.updateVisibleRange();
    }
  }

  private updateVisibleRange = () => {
    const { containerHeight, itemHeight, overscan = 5 } = this.props;
    const { scrollTop } = this.state;

    const startIndex = Math.max(0, Math.floor(scrollTop / itemHeight) - overscan);
    const endIndex = Math.min(
      this.props.data.length - 1,
      Math.floor((scrollTop + containerHeight) / itemHeight) + overscan
    );

    this.setState({
      visibleRange: { start: startIndex, end: endIndex }
    });
  };

  private handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const scrollTop = e.currentTarget.scrollTop;
    this.setState({ scrollTop }, () => {
      this.updateVisibleRange();
    });

    // 检查是否接近底部
    const { onEndReached, onEndReachedThreshold = 0.8 } = this.props;
    if (onEndReached) {
      const scrollHeight = this.props.data.length * this.props.itemHeight;
      const scrollBottom = scrollTop + this.props.containerHeight;
      const threshold = scrollHeight * (1 - onEndReachedThreshold);

      if (scrollBottom >= threshold) {
        onEndReached();
      }
    }
  };

  render() {
    const { data, renderItem, itemHeight, containerHeight } = this.props;
    const { visibleRange } = this.state;

    const visibleData = data.slice(visibleRange.start, visibleRange.end + 1);
    const offsetY = visibleRange.start * itemHeight;

    return (
      <div
        ref={(el) => this.scrollElement = el}
        style={{
          height: containerHeight,
          overflow: 'auto',
          position: 'relative'
        }}
        onScroll={this.handleScroll}
      >
        <div style={{ height: data.length * itemHeight, position: 'relative' }}>
          <div
            style={{
              transform: `translateY(${offsetY}px)`,
              position: 'absolute',
              top: 0,
              left: 0,
              right: 0
            }}
          >
            {visibleData.map((item, index) => 
              renderItem(item, visibleRange.start + index)
            )}
          </div>
        </div>
      </div>
    );
  }
}

// 懒加载组件
interface LazyLoadProps {
  children: React.ReactNode;
  placeholder?: React.ReactNode;
  threshold?: number;
  onVisible?: () => void;
}

export class LazyLoad extends React.Component<LazyLoadProps> {
  private observer: IntersectionObserver | null = null;
  private element: HTMLElement | null = null;
  private state = { isVisible: false };

  componentDidMount() {
    this.setupIntersectionObserver();
  }

  componentWillUnmount() {
    if (this.observer) {
      this.observer.disconnect();
    }
  }

  private setupIntersectionObserver = () => {
    const { threshold = 0.1, onVisible } = this.props;

    this.observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            this.setState({ isVisible: true });
            onVisible?.();
            if (this.observer) {
              this.observer.disconnect();
            }
          }
        });
      },
      { threshold }
    );

    if (this.element) {
      this.observer.observe(this.element);
    }
  };

  render() {
    const { children, placeholder } = this.props;
    const { isVisible } = this.state;

    return (
      <div ref={(el) => this.element = el}>
        {isVisible ? children : (placeholder || <div style={{ height: '200px' }} />)}
      </div>
    );
  }
}

// 性能优化钩子
export function usePerformanceOptimization() {
  const cache = React.useMemo(() => new CacheManager(), []);
  const monitor = React.useMemo(() => new PerformanceMonitor(), []);

  const optimizedRequest = React.useCallback(
    async <T>(key: string, operation: () => Promise<T>, ttl?: number): Promise<T> => {
      monitor.start(`cache_${key}`);
      
      // 先检查缓存
      const cached = cache.get(key);
      if (cached) {
        monitor.end(`cache_${key}`);
        return cached;
      }

      // 执行网络请求
      const result = await NetworkOptimizer.request(operation);
      
      // 缓存结果
      cache.set(key, result, ttl);
      
      monitor.end(`cache_${key}`);
      return result;
    },
    [cache, monitor]
  );

  const clearCache = React.useCallback((pattern?: string) => {
    cache.clear(pattern);
  }, [cache]);

  const getCacheStats = React.useCallback(() => {
    return cache.getStats();
  }, [cache]);

  return {
    optimizedRequest,
    clearCache,
    getCacheStats,
    monitor
  };
}

// 图片懒加载组件
interface LazyImageProps {
  src: string;
  alt: string;
  placeholder?: string;
  className?: string;
  style?: React.CSSProperties;
}

export const LazyImage: React.FC<LazyImageProps> = ({
  src,
  alt,
  placeholder = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZjVmNWY1Ii8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxNCIgZmlsbD0iIzk5OTk5OSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPuWbvueJh+WKoOi9veWksei0pTwvdGV4dD48L3N2Zz4=',
  className,
  style
}) => {
  const [isLoaded, setIsLoaded] = React.useState(false);
  const [isError, setIsError] = React.useState(false);
  const [imageSrc, setImageSrc] = React.useState(placeholder);
  const imgRef = React.useRef<HTMLImageElement>(null);

  React.useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && !isLoaded && !isError) {
            setImageSrc(src);
            observer.disconnect();
          }
        });
      },
      { threshold: 0.1 }
    );

    if (imgRef.current) {
      observer.observe(imgRef.current);
    }

    return () => observer.disconnect();
  }, [src, isLoaded, isError]);

  const handleLoad = () => {
    setIsLoaded(true);
  };

  const handleError = () => {
    setIsError(true);
    setImageSrc(placeholder);
  };

  return (
    <img
      ref={imgRef}
      src={imageSrc}
      alt={alt}
      className={className}
      style={{
        ...style,
        opacity: isLoaded ? 1 : 0,
        transition: 'opacity 0.3s ease'
      }}
      onLoad={handleLoad}
      onError={handleError}
    />
  );
};

// 离线消息队列
class OfflineMessageQueue {
  private queue: Array<{
    id: string;
    type: 'message' | 'like' | 'comment' | 'friend_request';
    data: any;
    timestamp: number;
    retries: number;
  }> = [];

  constructor() {
    this.loadFromStorage();
    this.setupOnlineListener();
  }

  private loadFromStorage() {
    try {
      const stored = localStorage.getItem('offline_message_queue');
      if (stored) {
        this.queue = JSON.parse(stored);
      }
    } catch (error) {
      console.error('加载离线队列失败:', error);
    }
  }

  private saveToStorage() {
    try {
      localStorage.setItem('offline_message_queue', JSON.stringify(this.queue));
    } catch (error) {
      console.error('保存离线队列失败:', error);
    }
  }

  private setupOnlineListener() {
    window.addEventListener('online', () => {
      this.processQueue();
    });
  }

  add(type: 'message' | 'like' | 'comment' | 'friend_request', data: any): string {
    const id = `${type}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    this.queue.push({
      id,
      type,
      data,
      timestamp: Date.now(),
      retries: 0
    });

    this.saveToStorage();
    return id;
  }

  async processQueue() {
    if (!navigator.onLine || this.queue.length === 0) return;

    const itemsToProcess = [...this.queue];
    
    for (const item of itemsToProcess) {
      try {
        await this.processItem(item);
        this.removeItem(item.id);
      } catch (error) {
        item.retries++;
        if (item.retries >= 3) {
          console.error('消息处理失败，已达到最大重试次数:', item);
          this.removeItem(item.id);
        }
      }
    }

    this.saveToStorage();
  }

  private async processItem(item: any) {
    switch (item.type) {
      case 'message':
        await SocialService.createPost?.(item.data.content, item.data.images);
        break;
      case 'like':
        await SocialService.likePost?.(item.data.postId);
        break;
      case 'comment':
        await SocialService.addComment?.(item.data.postId, item.data.content);
        break;
      case 'friend_request':
        await SocialService.sendFriendRequest?.(item.data.userId);
        break;
    }
  }

  private removeItem(id: string) {
    this.queue = this.queue.filter(item => item.id !== id);
  }

  getQueueSize(): number {
    return this.queue.length;
  }

  clear() {
    this.queue = [];
    this.saveToStorage();
  }
}

// React Hook for 离线支持
export function useOfflineSupport() {
  const [isOnline, setIsOnline] = React.useState(navigator.onLine);
  const [queueSize, setQueueSize] = React.useState(0);
  const queue = React.useMemo(() => new OfflineMessageQueue(), []);

  React.useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      queue.processQueue();
      setQueueSize(queue.getQueueSize());
    };

    const handleOffline = () => {
      setIsOnline(false);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    setQueueSize(queue.getQueueSize());

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [queue]);

  const addToQueue = React.useCallback((
    type: 'message' | 'like' | 'comment' | 'friend_request',
    data: any
  ) => {
    const id = queue.add(type, data);
    setQueueSize(queue.getQueueSize());
    return id;
  }, [queue]);

  return {
    isOnline,
    queueSize,
    addToQueue,
    queue
  };
}

// 性能优化的聊天列表组件
interface OptimizedChatListProps {
  chats: any[];
  onChatPress: (chat: any) => void;
  renderChatItem: (chat: any, index: number) => React.ReactNode;
}

export const OptimizedChatList: React.FC<OptimizedChatListProps> = ({
  chats,
  onChatPress,
  renderChatItem
}) => {
  const ITEM_HEIGHT = 80;
  const CONTAINER_HEIGHT = 400;
  const { optimizedRequest, monitor } = usePerformanceOptimization();

  const [displayChats, setDisplayChats] = React.useState(chats);

  React.useEffect(() => {
    // 使用性能优化后的数据加载
    const updateChats = async () => {
      const processedChats = await optimizedRequest(
        'chat_list',
        Promise.resolve(chats),
        2 * 60 * 1000 // 2分钟缓存
      );
      setDisplayChats(processedChats);
    };

    updateChats();
  }, [chats, optimizedRequest]);

  return (
    <VirtualizedList
      data={displayChats}
      renderItem={(chat, index) => (
        <div onClick={() => onChatPress(chat)}>
          {renderChatItem(chat, index)}
        </div>
      )}
      itemHeight={ITEM_HEIGHT}
      containerHeight={CONTAINER_HEIGHT}
      overscan={5}
      onEndReached={() => {
        console.log('聊天列表滚动到底部');
      }}
    />
  );
};

// 用户体验优化组件
export class UXEnhancer extends React.Component {
  private performanceMonitor = new PerformanceMonitor();

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error('用户体验错误:', error, errorInfo);
    // 这里可以发送错误报告到监控服务
  }

  render() {
    if ((this.state as any).hasError) {
      return (
        <div style={{ 
          padding: '20px', 
          textAlign: 'center',
          backgroundColor: '#fff',
          borderRadius: '8px',
          margin: '16px'
        }}>
          <h3>页面出现问题</h3>
          <p>我们正在修复这个问题，请稍后再试。</p>
          <button 
            onClick={() => window.location.reload()}
            style={{
              backgroundColor: '#07C160',
              color: '#fff',
              border: 'none',
              padding: '8px 16px',
              borderRadius: '4px',
              cursor: 'pointer'
            }}
          >
            重新加载
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}

// 导出单例实例
export const cacheManager = new CacheManager();
export const networkOptimizer = NetworkOptimizer;
export const performanceMonitor = new PerformanceMonitor();
export const offlineQueue = new OfflineMessageQueue();