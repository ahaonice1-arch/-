// Supabase Configuration for Frontend
// Add this configuration to your frontend application

const supabaseConfig = {
  url: 'https://saiozczbjnxqeynnrlkp.supabase.co',
  anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNhaW96Y3piam54cWV5bm5ybGtwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjM2MjA2MjMsImV4cCI6MjA3OTE5NjYyM30.M1d-1YhqOASqm8z9F46_bItyi5BANH8Q2kMbrXfH9As'
};

export default supabaseConfig;

// For React/Next.js applications, install the Supabase client:
// npm install @supabase/supabase-js

// Then use it in your code:
// import { createClient } from '@supabase/supabase-js';
// const supabase = createClient(supabaseConfig.url, supabaseConfig.anonKey);