# 社交聊天应用 - 部署指南

## 📋 部署前检查清单

### 1. 数据库准备
- [ ] 登录 Supabase 控制台：https://supabase.com/dashboard
- [ ] 选择项目：saiozczbjnxqeynnrlkp
- [ ] 执行 SQL 迁移脚本

### 2. 环境配置
- [ ] 复制 `.env.example` 为 `.env`
- [ ] 填入正确的 Supabase 配置
- [ ] 验证所有环境变量

### 3. 依赖安装
- [ ] 运行 `npm install`
- [ ] 检查是否有错误

## 🚀 分步部署指南

### 步骤 1: 数据库迁移

1. **登录 Supabase 控制台**
   ```
   https://supabase.com/dashboard
   ```

2. **选择项目**
   - 项目 ID: saiozczbjnxqeynnrlkp

3. **执行 SQL 迁移**
   - 点击左侧菜单 "SQL Editor"
   - 复制 `social_features_migration.sql` 的全部内容
   - 粘贴到 SQL 编辑器并执行
   - 验证所有表创建成功

4. **检查表结构**
   确保以下表已创建：
   - [ ] posts (朋友圈动态)
   - [ ] post_likes (动态点赞)
   - [ ] comments (评论)
   - [ ] user_profiles (用户资料扩展)
   - [ ] friend_requests (好友请求)
   - [ ] activities (活动记录)
   - [ ] notifications (通知)
   - [ ] chat_files (聊天文件)
   - [ ] user_settings (用户设置)

### 步骤 2: 环境配置

1. **创建环境文件**
   ```bash
   cp .env.example .env
   ```

2. **配置 Supabase 连接**
   ```env
   EXPO_PUBLIC_SUPABASE_URL=https://saiozczbjnxqeynnrlkp.supabase.co
   EXPO_PUBLIC_SUPABASE_ANON_KEY=your_actual_anon_key
   ```

   **获取 Anon Key:**
   - 在 Supabase 控制台中
   - 进入 Settings > API
   - 复制 "anon" public key

3. **验证配置**
   ```bash
   npm run type-check
   ```

### 步骤 3: 依赖安装和构建

1. **安装依赖**
   ```bash
   npm install
   ```

2. **类型检查**
   ```bash
   npm run type-check
   ```

3. **启动开发服务器**
   ```bash
   npm start
   ```

### 步骤 4: 功能测试

#### 4.1 基础功能测试

**用户注册/登录**
- [ ] 注册新用户账号
- [ ] 登录功能正常
- [ ] 用户资料显示正确

**社交功能**
- [ ] 发布朋友圈动态
- [ ] 查看好友动态
- [ ] 点赞和评论功能
- [ ] 好友搜索和添加

**聊天功能**
- [ ] 发送文本消息
- [ ] 文件分享功能
- [ ] 消息搜索
- [ ] 已读回执

#### 4.2 高级功能测试

**推荐系统**
- [ ] 好友推荐显示
- [ ] 内容推荐正常
- [ ] 兴趣标签匹配

**性能优化**
- [ ] 图片懒加载
- [ ] 虚拟滚动
- [ ] 离线缓存

**Starlink 网络优化**
- [ ] 网络状态检测
- [ ] 重试机制
- [ ] 离线消息队列

### 步骤 5: 生产部署

#### 5.1 Web 部署

1. **构建 Web 版本**
   ```bash
   npx expo export --platform web
   ```

2. **部署到平台**
   - 使用提供的部署工具
   - 或手动部署到静态托管服务

#### 5.2 移动应用部署

1. **Android 部署**
   ```bash
   eas build --platform android
   eas submit --platform android
   ```

2. **iOS 部署**
   ```bash
   eas build --platform ios
   eas submit --platform ios
   ```

## 🛠 故障排除

### 常见问题及解决方案

#### 问题 1: 数据库连接失败
**症状:** 应用启动时显示连接错误
**解决:**
1. 检查 `.env` 文件中的 Supabase URL 和 Key
2. 验证网络连接
3. 检查 Supabase 项目状态

#### 问题 2: 朋友圈功能不工作
**症状:** 无法发布或查看动态
**解决:**
1. 确认 SQL 迁移已执行
2. 检查 RLS 策略是否正确
3. 验证用户权限

#### 问题 3: 文件上传失败
**症状:** 无法上传图片或文件
**解决:**
1. 检查 Supabase Storage 配置
2. 验证文件大小限制
3. 检查网络连接

#### 问题 4: 性能问题
**症状:** 应用运行缓慢
**解决:**
1. 启用性能优化器
2. 检查网络设置
3. 清理缓存数据

### 调试模式

启用调试模式：
```env
EXPO_PUBLIC_DEBUG_MODE=true
EXPO_PUBLIC_LOG_LEVEL=debug
```

查看调试信息：
```bash
npm start -- --dev-client
```

## 📊 性能监控

### 关键指标
- 应用启动时间 < 3秒
- 页面切换 < 500ms
- 图片加载 < 2秒
- API 响应时间 < 1秒

### 监控工具
- React Native Flipper
- Supabase Dashboard
- Expo Application Services

## 🔧 维护和更新

### 定期维护
1. **每周检查**
   - 数据库性能
   - 错误日志
   - 用户反馈

2. **每月更新**
   - 依赖包更新
   - 安全补丁
   - 性能优化

### 备份策略
1. **数据库备份**
   - 自动每日备份
   - 手动重要数据备份

2. **代码备份**
   - Git 版本控制
   - 多环境部署

## 📞 技术支持

如遇到问题，请检查：
1. 本部署指南
2. 项目文档
3. 错误日志
4. Supabase 文档

---

**部署完成后，请运行测试确保所有功能正常工作！**