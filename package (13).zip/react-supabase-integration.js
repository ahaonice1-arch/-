// React App Configuration Example
// src/lib/supabase.js

import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'https://saiozczbjnxqeynnrlkp.supabase.co'
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNhaW96Y3piam54cWV5bm5ybGtwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjM2MjA2MjMsImV4cCI6MjA3OTE5NjYyM30.M1d-1YhqOASqm8z9F46_bItyi5BANH8Q2kMbrXfH9As'

export const supabase = createClient(supabaseUrl, supabaseKey)

// Auth helpers
export const signUp = (email, password) => {
  return supabase.auth.signUp({
    email,
    password,
  })
}

export const signIn = (email, password) => {
  return supabase.auth.signInWithPassword({
    email,
    password,
  })
}

export const signOut = () => {
  return supabase.auth.signOut()
}

export const getUser = () => {
  return supabase.auth.getUser()
}

// Database helpers
export const getUserProfile = (userId) => {
  return supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .single()
}

export const createPost = (content, userId) => {
  return supabase
    .from('posts')
    .insert({
      content,
      user_id: userId,
      created_at: new Date().toISOString()
    })
}

export const getPosts = () => {
  return supabase
    .from('posts')
    .select(`
      *,
      profiles:user_id (id, username, avatar_url),
      post_likes (*)
    `)
    .order('created_at', { ascending: false })
}

export const likePost = (postId, userId) => {
  return supabase
    .from('post_likes')
    .insert({
      post_id: postId,
      user_id: userId
    })
}

export const unlikePost = (postId, userId) => {
  return supabase
    .from('post_likes')
    .delete()
    .eq('post_id', postId)
    .eq('user_id', userId)
}

// Real-time subscriptions
export const subscribeToPosts = (callback) => {
  return supabase
    .channel('public:posts')
    .on('postgres_changes', 
      { event: '*', schema: 'public', table: 'posts' },
      callback
    )
    .subscribe()
}

// Chat functions
export const createChat = (userId1, userId2) => {
  return supabase
    .from('chats')
    .insert({
      type: 'direct',
      created_at: new Date().toISOString()
    })
    .select()
    .single()
    .then(({ data, error }) => {
      if (error) throw error
      
      // Add members to chat
      return supabase
        .from('chat_members')
        .insert([
          { chat_id: data.id, user_id: userId1 },
          { chat_id: data.id, user_id: userId2 }
        ])
        .then(() => data)
    })
}

export const getMessages = (chatId) => {
  return supabase
    .from('messages')
    .select(`
      *,
      profiles:user_id (id, username, avatar_url)
    `)
    .eq('chat_id', chatId)
    .order('created_at', { ascending: true })
}

export const sendMessage = (chatId, userId, content) => {
  return supabase
    .from('messages')
    .insert({
      chat_id: chatId,
      user_id: userId,
      content,
      created_at: new Date().toISOString()
    })
}

export const subscribeToChat = (chatId, callback) => {
  return supabase
    .channel(`public:messages:chat_${chatId}`)
    .on('postgres_changes', 
      { 
        event: 'INSERT', 
        schema: 'public', 
        table: 'messages',
        filter: `chat_id=eq.${chatId}`
      },
      callback
    )
    .subscribe()
}