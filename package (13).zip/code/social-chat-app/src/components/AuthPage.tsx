import React, { useState } from 'react'
import { useAuth } from '../contexts/AuthContext'
import { useLanguage } from '../contexts/LanguageContext'
import { Mail, Lock, User, Globe, MessageSquare, Users, Shield } from 'lucide-react'

export function AuthPage() {
  const { signIn, signUp } = useAuth()
  const { language, setLanguage, t } = useLanguage()
  const [mode, setMode] = useState<'login' | 'signup'>('login')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [username, setUsername] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [showLanguageMenu, setShowLanguageMenu] = useState(false)

  const languages = [
    { code: 'zh', label: '中文' },
    { code: 'en', label: 'English' },
    { code: 'my', label: 'Myanmar' }
  ]

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    setLoading(true)

    try {
      if (mode === 'signup') {
        const { error } = await signUp(email, password, username)
        if (error) setError(error.message)
      } else {
        const { error } = await signIn(email, password)
        if (error) setError(error.message)
      }
    } catch (err: any) {
      setError(err.message || 'An error occurred')
    }

    setLoading(false)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-600 via-primary-500 to-gold-500 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Language Selector */}
        <div className="flex justify-end mb-4">
          <div className="relative">
            <button
              onClick={() => setShowLanguageMenu(!showLanguageMenu)}
              className="flex items-center gap-2 px-3 py-2 bg-white/20 backdrop-blur rounded-lg text-sm text-white hover:bg-white/30 transition"
            >
              <Globe className="w-4 h-4" />
              {languages.find(l => l.code === language)?.label}
            </button>
            {showLanguageMenu && (
              <div className="absolute right-0 mt-1 w-32 bg-white border border-primary-100 rounded-lg shadow-lg overflow-hidden z-10">
                {languages.map(lang => (
                  <button
                    key={lang.code}
                    onClick={() => {
                      setLanguage(lang.code as 'zh' | 'en' | 'my')
                      setShowLanguageMenu(false)
                    }}
                    className={`w-full px-3 py-2 text-left text-sm hover:bg-primary-50 ${
                      language === lang.code ? 'bg-primary-100 text-primary-700' : ''
                    }`}
                  >
                    {lang.label}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Hero Section */}
        <div className="text-center text-white mb-8">
          <h1 className="text-4xl font-bold mb-2">{t('appName')}</h1>
          <p className="text-primary-100">{t('tagline')}</p>
        </div>

        {/* Features */}
        <div className="grid grid-cols-3 gap-4 mb-8">
          <div className="text-center text-white">
            <div className="w-12 h-12 mx-auto bg-white/20 backdrop-blur rounded-xl flex items-center justify-center mb-2">
              <MessageSquare className="w-6 h-6" />
            </div>
            <p className="text-xs">{t('chat')}</p>
          </div>
          <div className="text-center text-white">
            <div className="w-12 h-12 mx-auto bg-white/20 backdrop-blur rounded-xl flex items-center justify-center mb-2">
              <Users className="w-6 h-6" />
            </div>
            <p className="text-xs">{t('feed')}</p>
          </div>
          <div className="text-center text-white">
            <div className="w-12 h-12 mx-auto bg-white/20 backdrop-blur rounded-xl flex items-center justify-center mb-2">
              <Shield className="w-6 h-6" />
            </div>
            <p className="text-xs">Secure</p>
          </div>
        </div>

        {/* Auth Card */}
        <div className="bg-white rounded-2xl shadow-xl p-6">
          <div className="flex mb-6">
            <button
              onClick={() => {
                setMode('login')
                setError('')
              }}
              className={`flex-1 py-2 text-center font-medium rounded-lg transition ${
                mode === 'login'
                  ? 'bg-gradient-to-r from-primary-600 to-primary-500 text-white shadow-md'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              {t('signIn')}
            </button>
            <button
              onClick={() => {
                setMode('signup')
                setError('')
              }}
              className={`flex-1 py-2 text-center font-medium rounded-lg transition ${
                mode === 'signup'
                  ? 'bg-gradient-to-r from-primary-600 to-primary-500 text-white shadow-md'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              {t('signUp')}
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === 'signup' && (
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder={t('username')}
                  className="w-full pl-10 pr-4 py-3 border border-primary-200 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                  required={mode === 'signup'}
                />
              </div>
            )}

            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder={t('email')}
                className="w-full pl-10 pr-4 py-3 border border-primary-200 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                required
              />
            </div>

            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder={t('password')}
                className="w-full pl-10 pr-4 py-3 border border-primary-200 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                required
              />
            </div>

            {error && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-red-600 text-sm">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-gradient-to-r from-primary-600 to-gold-500 text-white rounded-lg hover:from-primary-700 hover:to-gold-600 disabled:opacity-50 font-medium shadow-lg transition"
            >
              {loading ? t('loading') : mode === 'signup' ? t('signUp') : t('signIn')}
            </button>
          </form>

          <div className="mt-6 text-center text-xs text-gray-400">
            {t('appName')} - {t('tagline')}
          </div>
        </div>
      </div>
    </div>
  )
}
