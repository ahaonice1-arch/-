import React, { useState } from 'react'
import { useAuth } from '../contexts/AuthContext'
import { useLanguage } from '../contexts/LanguageContext'
import { NotificationBadge } from './Notifications/NotificationList'
import { Home, MessageSquare, Users, Bell, User, LogOut, Menu, X, Globe } from 'lucide-react'

type Tab = 'feed' | 'chat' | 'friends' | 'notifications' | 'profile'

interface MainLayoutProps {
  activeTab: Tab
  onTabChange: (tab: Tab) => void
  children: React.ReactNode
}

export function MainLayout({ activeTab, onTabChange, children }: MainLayoutProps) {
  const { profile, signOut } = useAuth()
  const { language, setLanguage, t } = useLanguage()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [showLanguageMenu, setShowLanguageMenu] = useState(false)

  const navItems: { id: Tab; label: string; icon: React.ReactNode }[] = [
    { id: 'feed', label: t('feed'), icon: <Home className="w-5 h-5" /> },
    { id: 'chat', label: t('chat'), icon: <MessageSquare className="w-5 h-5" /> },
    { id: 'friends', label: t('friends'), icon: <Users className="w-5 h-5" /> },
    { id: 'notifications', label: t('notifications'), icon: (
      <div className="relative">
        <Bell className="w-5 h-5" />
        <NotificationBadge />
      </div>
    )},
    { id: 'profile', label: t('profile'), icon: <User className="w-5 h-5" /> },
  ]

  const languages = [
    { code: 'zh', label: '中文' },
    { code: 'en', label: 'English' },
    { code: 'my', label: 'Myanmar' }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-50 via-white to-gold-50">
      {/* Desktop Sidebar */}
      <div className="hidden md:flex md:w-64 md:flex-col md:fixed md:inset-y-0">
        <div className="flex-1 flex flex-col min-h-0 bg-white border-r border-primary-100 shadow-lg">
          <div className="flex-1 flex flex-col pt-5 pb-4 overflow-y-auto">
            {/* Logo and Brand */}
            <div className="flex items-center flex-shrink-0 px-4 mb-6">
              <div className="flex flex-col">
                <h1 className="text-2xl font-bold bg-gradient-to-r from-primary-600 to-gold-500 bg-clip-text text-transparent">
                  {t('appName')}
                </h1>
                <p className="text-xs text-gray-500 mt-1">{t('tagline')}</p>
              </div>
            </div>
            
            {/* Navigation */}
            <nav className="flex-1 px-2 space-y-1">
              {navItems.map(item => (
                <button
                  key={item.id}
                  onClick={() => onTabChange(item.id)}
                  className={`w-full flex items-center gap-3 px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 ${
                    activeTab === item.id
                      ? 'bg-gradient-to-r from-primary-500 to-primary-600 text-white shadow-md'
                      : 'text-gray-700 hover:bg-primary-50 hover:text-primary-700'
                  }`}
                >
                  {item.icon}
                  {item.label}
                </button>
              ))}
            </nav>
            
            {/* Language Selector */}
            <div className="px-4 mb-4">
              <div className="relative">
                <button
                  onClick={() => setShowLanguageMenu(!showLanguageMenu)}
                  className="w-full flex items-center gap-2 px-3 py-2 text-sm text-gray-600 hover:bg-primary-50 rounded-lg transition"
                >
                  <Globe className="w-4 h-4" />
                  <span>{languages.find(l => l.code === language)?.label}</span>
                </button>
                {showLanguageMenu && (
                  <div className="absolute bottom-full left-0 w-full mb-1 bg-white border border-primary-100 rounded-lg shadow-lg overflow-hidden">
                    {languages.map(lang => (
                      <button
                        key={lang.code}
                        onClick={() => {
                          setLanguage(lang.code as 'zh' | 'en' | 'my')
                          setShowLanguageMenu(false)
                        }}
                        className={`w-full px-3 py-2 text-left text-sm hover:bg-primary-50 ${
                          language === lang.code ? 'bg-primary-100 text-primary-700' : ''
                        }`}
                      >
                        {lang.label}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
          
          {/* User Profile Section */}
          <div className="flex-shrink-0 flex border-t border-primary-100 p-4 bg-gradient-to-r from-primary-50 to-gold-50">
            <div className="flex items-center w-full">
              {profile?.avatar_url ? (
                <img
                  src={profile.avatar_url}
                  alt={profile.full_name || ''}
                  className="w-10 h-10 rounded-full ring-2 ring-primary-200"
                />
              ) : (
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary-400 to-gold-400 flex items-center justify-center">
                  <User className="w-5 h-5 text-white" />
                </div>
              )}
              <div className="ml-3 flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900 truncate">
                  {profile?.full_name || 'User'}
                </p>
                <p className="text-xs text-gray-500 truncate">
                  @{profile?.username || 'user'}
                </p>
              </div>
              <button
                onClick={signOut}
                className="p-2 text-gray-400 hover:text-red-600 transition"
                title={t('signOut')}
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Header */}
      <div className="md:hidden fixed top-0 left-0 right-0 bg-white border-b border-primary-100 z-40 shadow-sm">
        <div className="flex items-center justify-between px-4 h-14">
          <h1 className="text-lg font-bold bg-gradient-to-r from-primary-600 to-gold-500 bg-clip-text text-transparent">
            {t('appName')}
          </h1>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowLanguageMenu(!showLanguageMenu)}
              className="p-2 text-gray-600"
            >
              <Globe className="w-5 h-5" />
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-gray-600"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Language Menu */}
        {showLanguageMenu && (
          <div className="absolute top-14 right-0 w-40 bg-white border border-primary-100 rounded-lg shadow-lg mx-4 overflow-hidden">
            {languages.map(lang => (
              <button
                key={lang.code}
                onClick={() => {
                  setLanguage(lang.code as 'zh' | 'en' | 'my')
                  setShowLanguageMenu(false)
                }}
                className={`w-full px-4 py-2 text-left text-sm hover:bg-primary-50 ${
                  language === lang.code ? 'bg-primary-100 text-primary-700' : ''
                }`}
              >
                {lang.label}
              </button>
            ))}
          </div>
        )}

        {/* Mobile Menu Dropdown */}
        {mobileMenuOpen && (
          <div className="absolute top-14 left-0 right-0 bg-white border-b border-primary-100 shadow-lg">
            <nav className="p-2">
              {navItems.map(item => (
                <button
                  key={item.id}
                  onClick={() => {
                    onTabChange(item.id)
                    setMobileMenuOpen(false)
                  }}
                  className={`w-full flex items-center gap-3 px-4 py-3 text-sm font-medium rounded-lg ${
                    activeTab === item.id
                      ? 'bg-gradient-to-r from-primary-500 to-primary-600 text-white'
                      : 'text-gray-700'
                  }`}
                >
                  {item.icon}
                  {item.label}
                </button>
              ))}
              <button
                onClick={signOut}
                className="w-full flex items-center gap-3 px-4 py-3 text-sm font-medium text-red-600 rounded-lg"
              >
                <LogOut className="w-5 h-5" />
                {t('signOut')}
              </button>
            </nav>
          </div>
        )}
      </div>

      {/* Mobile Bottom Navigation */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-primary-100 z-40 shadow-lg">
        <nav className="flex justify-around">
          {navItems.map(item => (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={`flex flex-col items-center py-2 px-4 transition ${
                activeTab === item.id ? 'text-primary-600' : 'text-gray-500'
              }`}
            >
              {item.icon}
              <span className="text-xs mt-1">{item.label}</span>
            </button>
          ))}
        </nav>
      </div>

      {/* Main Content */}
      <div className="md:pl-64">
        <main className="py-4 md:py-6 pt-16 md:pt-6 pb-20 md:pb-6">
          <div className="max-w-4xl mx-auto px-4">
            {children}
          </div>
        </main>
      </div>
    </div>
  )
}
