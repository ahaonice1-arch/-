import React, { useState, useEffect } from 'react'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../contexts/AuthContext'
import { useLanguage } from '../../contexts/LanguageContext'
import type { Profile, FriendRequest } from '../../types/database'
import { User, UserPlus, UserCheck, Search, Check, X, Clock } from 'lucide-react'

export function FriendsList() {
  const { user } = useAuth()
  const { t } = useLanguage()
  const [friends, setFriends] = useState<Profile[]>([])
  const [pendingRequests, setPendingRequests] = useState<{ request: FriendRequest; profile: Profile }[]>([])
  const [loading, setLoading] = useState(true)
  const [tab, setTab] = useState<'friends' | 'requests' | 'find'>('friends')

  useEffect(() => {
    if (user) {
      loadFriends()
      loadPendingRequests()
    }
  }, [user])

  async function loadFriends() {
    if (!user) return
    setLoading(true)

    try {
      // Get all friendships where user is involved
      const { data: friendships, error } = await supabase
        .from('friendships')
        .select('*')
        .or(`user_id.eq.${user.id},friend_id.eq.${user.id}`)
        .eq('status', 'accepted')

      if (error) {
        console.error('Error loading friendships:', error)
        setFriends([])
        setLoading(false)
        return
      }

      if (!friendships || friendships.length === 0) {
        setFriends([])
        setLoading(false)
        return
      }

      // Get friend IDs
      const friendIds = friendships.map(f => 
        f.user_id === user.id ? f.friend_id : f.user_id
      )

      // Get friend profiles
      const { data: profiles } = await supabase
        .from('profiles')
        .select('*')
        .in('id', friendIds)

      setFriends(profiles || [])
    } catch (err) {
      console.error('Error loading friends:', err)
      setFriends([])
    }
    setLoading(false)
  }

  async function loadPendingRequests() {
    if (!user) return

    try {
      const { data: requests } = await supabase
        .from('friend_requests')
        .select('*')
        .eq('to_user_id', user.id)
        .eq('status', 'pending')

      if (!requests || requests.length === 0) {
        setPendingRequests([])
        return
      }

      const fromUserIds = requests.map(r => r.from_user_id)
      const { data: profiles } = await supabase
        .from('profiles')
        .select('*')
        .in('id', fromUserIds)

      const enriched = requests.map(req => ({
        request: req,
        profile: profiles?.find(p => p.id === req.from_user_id)!
      })).filter(r => r.profile)

      setPendingRequests(enriched)
    } catch (err) {
      console.error('Error loading pending requests:', err)
      setPendingRequests([])
    }
  }

  async function acceptRequest(requestId: string, fromUserId: string) {
    if (!user) return

    try {
      // Update request status
      await supabase
        .from('friend_requests')
        .update({ status: 'accepted' })
        .eq('id', requestId)

      // Create friendship
      await supabase.from('friendships').insert({
        user_id: user.id,
        friend_id: fromUserId,
        status: 'accepted'
      })

      // Create notification for the requester
      await supabase.from('notifications').insert({
        user_id: fromUserId,
        type: 'friend_accepted',
        content: 'Your friend request was accepted'
      })

      loadFriends()
      loadPendingRequests()
    } catch (err) {
      console.error('Error accepting request:', err)
    }
  }

  async function rejectRequest(requestId: string) {
    try {
      await supabase
        .from('friend_requests')
        .update({ status: 'rejected' })
        .eq('id', requestId)

      loadPendingRequests()
    } catch (err) {
      console.error('Error rejecting request:', err)
    }
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-primary-100">
      <div className="border-b border-primary-100">
        <div className="flex">
          <button
            onClick={() => setTab('friends')}
            className={`flex-1 py-3 text-sm font-medium transition ${
              tab === 'friends' ? 'text-primary-600 border-b-2 border-primary-600' : 'text-gray-500'
            }`}
          >
            {t('friendsList')} ({friends.length})
          </button>
          <button
            onClick={() => setTab('requests')}
            className={`flex-1 py-3 text-sm font-medium relative transition ${
              tab === 'requests' ? 'text-primary-600 border-b-2 border-primary-600' : 'text-gray-500'
            }`}
          >
            {t('requests')}
            {pendingRequests.length > 0 && (
              <span className="absolute top-2 right-4 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                {pendingRequests.length}
              </span>
            )}
          </button>
          <button
            onClick={() => setTab('find')}
            className={`flex-1 py-3 text-sm font-medium transition ${
              tab === 'find' ? 'text-primary-600 border-b-2 border-primary-600' : 'text-gray-500'
            }`}
          >
            {t('findFriends')}
          </button>
        </div>
      </div>

      <div className="p-4">
        {tab === 'friends' && (
          loading ? (
            <div className="text-center py-8 text-gray-400">{t('loading')}</div>
          ) : friends.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <UserPlus className="w-12 h-12 mx-auto mb-2 text-primary-200" />
              <p>{t('noFriends')}</p>
              <button
                onClick={() => setTab('find')}
                className="mt-2 text-primary-600 text-sm hover:underline"
              >
                {t('findFriends')}
              </button>
            </div>
          ) : (
            <div className="space-y-2">
              {friends.map(friend => (
                <FriendCard key={friend.id} profile={friend} />
              ))}
            </div>
          )
        )}

        {tab === 'requests' && (
          pendingRequests.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <Clock className="w-12 h-12 mx-auto mb-2 text-primary-200" />
              <p>{t('noPendingRequests')}</p>
            </div>
          ) : (
            <div className="space-y-3">
              {pendingRequests.map(({ request, profile }) => (
                <div key={request.id} className="flex items-center gap-3 p-3 bg-primary-50 rounded-lg">
                  {profile.avatar_url ? (
                    <img src={profile.avatar_url} alt={profile.full_name || ''} className="w-12 h-12 rounded-full" />
                  ) : (
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary-300 to-gold-300 flex items-center justify-center">
                      <User className="w-6 h-6 text-white" />
                    </div>
                  )}
                  <div className="flex-1">
                    <p className="font-medium text-gray-900">{profile.full_name || profile.username}</p>
                    <p className="text-sm text-gray-500">{t('wantsToBeFriend')}</p>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => acceptRequest(request.id, request.from_user_id)}
                      className="p-2 bg-green-100 text-green-600 rounded-full hover:bg-green-200 transition"
                    >
                      <Check className="w-5 h-5" />
                    </button>
                    <button
                      onClick={() => rejectRequest(request.id)}
                      className="p-2 bg-red-100 text-red-600 rounded-full hover:bg-red-200 transition"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )
        )}

        {tab === 'find' && <FindFriends onRequestSent={loadPendingRequests} />}
      </div>
    </div>
  )
}

function FriendCard({ profile }: { profile: Profile }) {
  return (
    <div className="flex items-center gap-3 p-3 hover:bg-primary-50 rounded-lg transition">
      {profile.avatar_url ? (
        <img src={profile.avatar_url} alt={profile.full_name || ''} className="w-12 h-12 rounded-full" />
      ) : (
        <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary-300 to-gold-300 flex items-center justify-center">
          <User className="w-6 h-6 text-white" />
        </div>
      )}
      <div className="flex-1">
        <p className="font-medium text-gray-900">{profile.full_name || profile.username}</p>
        <p className="text-sm text-gray-500">@{profile.username}</p>
      </div>
      <UserCheck className="w-5 h-5 text-green-500" />
    </div>
  )
}

function FindFriends({ onRequestSent }: { onRequestSent: () => void }) {
  const { user } = useAuth()
  const { t } = useLanguage()
  const [search, setSearch] = useState('')
  const [users, setUsers] = useState<Profile[]>([])
  const [sentRequests, setSentRequests] = useState<string[]>([])
  const [existingFriends, setExistingFriends] = useState<string[]>([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    loadExistingConnections()
  }, [user])

  useEffect(() => {
    const timer = setTimeout(() => {
      if (search.length >= 1) {
        searchUsers()
      } else {
        setUsers([])
      }
    }, 300)
    return () => clearTimeout(timer)
  }, [search])

  async function loadExistingConnections() {
    if (!user) return

    try {
      // Get sent requests
      const { data: requests } = await supabase
        .from('friend_requests')
        .select('to_user_id')
        .eq('from_user_id', user.id)
        .eq('status', 'pending')

      setSentRequests(requests?.map(r => r.to_user_id) || [])

      // Get existing friends
      const { data: friendships } = await supabase
        .from('friendships')
        .select('*')
        .or(`user_id.eq.${user.id},friend_id.eq.${user.id}`)
        .eq('status', 'accepted')

      const friendIds = friendships?.map(f => 
        f.user_id === user.id ? f.friend_id : f.user_id
      ) || []

      setExistingFriends(friendIds)
    } catch (err) {
      console.error('Error loading connections:', err)
    }
  }

  async function searchUsers() {
    if (!user) return
    setLoading(true)

    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .neq('id', user.id)
        .or(`full_name.ilike.%${search}%,username.ilike.%${search}%,email.ilike.%${search}%`)
        .limit(20)

      if (error) {
        console.error('Error searching users:', error)
        setUsers([])
      } else {
        setUsers(data || [])
      }
    } catch (err) {
      console.error('Error searching users:', err)
      setUsers([])
    }
    setLoading(false)
  }

  async function sendRequest(toUserId: string) {
    if (!user) return

    try {
      await supabase.from('friend_requests').insert({
        from_user_id: user.id,
        to_user_id: toUserId,
        status: 'pending'
      })

      setSentRequests(prev => [...prev, toUserId])
      onRequestSent()
    } catch (err) {
      console.error('Error sending request:', err)
    }
  }

  function getButtonState(userId: string) {
    if (existingFriends.includes(userId)) return 'friend'
    if (sentRequests.includes(userId)) return 'pending'
    return 'add'
  }

  return (
    <div>
      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder={t('searchByName')}
          className="w-full pl-10 pr-4 py-2 border border-primary-200 rounded-lg focus:ring-2 focus:ring-primary-500"
        />
      </div>

      {loading ? (
        <div className="text-center py-8 text-gray-400">{t('searching')}</div>
      ) : users.length === 0 ? (
        search.length >= 1 ? (
          <div className="text-center py-8 text-gray-500">{t('noUsersFound')}</div>
        ) : (
          <div className="text-center py-8 text-gray-500">
            <Search className="w-12 h-12 mx-auto mb-2 text-primary-200" />
            <p>{t('searchUsersToAdd')}</p>
          </div>
        )
      ) : (
        <div className="space-y-2">
          {users.map(u => {
            const state = getButtonState(u.id)
            return (
              <div key={u.id} className="flex items-center gap-3 p-3 hover:bg-primary-50 rounded-lg transition">
                {u.avatar_url ? (
                  <img src={u.avatar_url} alt={u.full_name || ''} className="w-12 h-12 rounded-full" />
                ) : (
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary-300 to-gold-300 flex items-center justify-center">
                    <User className="w-6 h-6 text-white" />
                  </div>
                )}
                <div className="flex-1">
                  <p className="font-medium text-gray-900">{u.full_name || u.username}</p>
                  <p className="text-sm text-gray-500">@{u.username}</p>
                </div>
                {state === 'friend' ? (
                  <span className="text-green-600 text-sm flex items-center gap-1">
                    <UserCheck className="w-4 h-4" /> {t('alreadyFriends')}
                  </span>
                ) : state === 'pending' ? (
                  <span className="text-gray-400 text-sm flex items-center gap-1">
                    <Clock className="w-4 h-4" /> {t('pending')}
                  </span>
                ) : (
                  <button
                    onClick={() => sendRequest(u.id)}
                    className="px-3 py-1 bg-gradient-to-r from-primary-600 to-primary-500 text-white text-sm rounded-lg hover:from-primary-700 hover:to-primary-600 flex items-center gap-1 shadow-sm transition"
                  >
                    <UserPlus className="w-4 h-4" /> {t('add')}
                  </button>
                )}
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
