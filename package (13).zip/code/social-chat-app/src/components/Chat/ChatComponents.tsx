import React, { useState, useEffect, useRef } from 'react'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../contexts/AuthContext'
import { useLanguage } from '../../contexts/LanguageContext'
import type { Profile, ChatWithDetails, MessageWithAuthor } from '../../types/database'
import { Send, Plus, User, Users, Search, ArrowLeft, MoreVertical, UserPlus, LogOut, X } from 'lucide-react'

export function ChatList({ onSelectChat, selectedChatId }: { onSelectChat: (chat: ChatWithDetails) => void, selectedChatId?: string }) {
  const { user } = useAuth()
  const { t } = useLanguage()
  const [chats, setChats] = useState<ChatWithDetails[]>([])
  const [loading, setLoading] = useState(true)
  const [showNewChat, setShowNewChat] = useState(false)

  useEffect(() => {
    if (user) {
      loadChats()
      const unsubscribe = subscribeToChats()
      return () => unsubscribe()
    }
  }, [user])

  async function loadChats() {
    if (!user) return
    setLoading(true)
    
    try {
      // Get chats where user is a member
      const { data: memberData } = await supabase
        .from('chat_members')
        .select('chat_id')
        .eq('user_id', user.id)

      if (!memberData || memberData.length === 0) {
        setChats([])
        setLoading(false)
        return
      }

      const chatIds = memberData.map(m => m.chat_id)
      
      const { data: chatsData } = await supabase
        .from('chats')
        .select('*')
        .in('id', chatIds)
        .order('updated_at', { ascending: false })

      if (!chatsData) {
        setChats([])
        setLoading(false)
        return
      }

      // Enrich with members and last message
      const enrichedChats: ChatWithDetails[] = await Promise.all(
        chatsData.map(async (chat) => {
          // Get members
          const { data: members } = await supabase
            .from('chat_members')
            .select('user_id')
            .eq('chat_id', chat.id)

          const memberIds = members?.map(m => m.user_id) || []
          
          const { data: profiles } = await supabase
            .from('profiles')
            .select('*')
            .in('id', memberIds)

          // Get last message
          const { data: lastMsg } = await supabase
            .from('messages')
            .select('*')
            .eq('chat_id', chat.id)
            .order('created_at', { ascending: false })
            .limit(1)
            .maybeSingle()

          return {
            ...chat,
            members: profiles || [],
            last_message: lastMsg || null,
            unread_count: 0
          }
        })
      )

      setChats(enrichedChats)
    } catch (err) {
      console.error('Error loading chats:', err)
    }
    setLoading(false)
  }

  function subscribeToChats() {
    const channel = supabase
      .channel('chat_updates')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'messages' }, () => {
        loadChats()
      })
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }

  function getChatDisplayName(chat: ChatWithDetails) {
    if (chat.name) return chat.name
    const otherMembers = chat.members.filter(m => m.id !== user?.id)
    if (otherMembers.length > 0) {
      return otherMembers[0].full_name || otherMembers[0].username || 'Unknown'
    }
    return 'New Chat'
  }

  if (loading) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="animate-pulse text-gray-400">{t('loadingChats')}</div>
      </div>
    )
  }

  return (
    <div className="h-full flex flex-col">
      <div className="p-4 border-b border-primary-100">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-xl font-bold text-gray-900">{t('chats')}</h2>
          <button
            onClick={() => setShowNewChat(true)}
            className="p-2 bg-gradient-to-r from-primary-600 to-primary-500 text-white rounded-full hover:from-primary-700 hover:to-primary-600 shadow-md transition"
          >
            <Plus className="w-5 h-5" />
          </button>
        </div>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type="text"
            placeholder={t('searchConversations')}
            className="w-full pl-10 pr-4 py-2 bg-primary-50 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary-500"
          />
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto">
        {chats.length === 0 ? (
          <div className="text-center py-12 text-gray-500">
            {t('noConversations')}
          </div>
        ) : (
          chats.map(chat => (
            <button
              key={chat.id}
              onClick={() => onSelectChat(chat)}
              className={`w-full p-4 flex items-center gap-3 hover:bg-primary-50 border-b border-primary-50 transition ${
                selectedChatId === chat.id ? 'bg-primary-100' : ''
              }`}
            >
              {chat.is_group ? (
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary-400 to-gold-400 flex items-center justify-center">
                  <Users className="w-6 h-6 text-white" />
                </div>
              ) : (
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary-300 to-gold-300 flex items-center justify-center">
                  <User className="w-6 h-6 text-white" />
                </div>
              )}
              <div className="flex-1 text-left min-w-0">
                <p className="font-semibold text-gray-900 truncate">
                  {getChatDisplayName(chat)}
                </p>
                <p className="text-sm text-gray-500 truncate">
                  {chat.last_message?.content || t('noMessagesYet')}
                </p>
              </div>
              {chat.last_message && (
                <span className="text-xs text-gray-400">
                  {new Date(chat.last_message.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              )}
            </button>
          ))
        )}
      </div>

      {showNewChat && (
        <NewChatModal
          onClose={() => setShowNewChat(false)}
          onCreated={(chat) => {
            setShowNewChat(false)
            loadChats()
            onSelectChat(chat)
          }}
        />
      )}
    </div>
  )
}

function NewChatModal({ onClose, onCreated }: { onClose: () => void, onCreated: (chat: ChatWithDetails) => void }) {
  const { user } = useAuth()
  const { t } = useLanguage()
  const [users, setUsers] = useState<Profile[]>([])
  const [search, setSearch] = useState('')
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    searchUsers()
  }, [search])

  async function searchUsers() {
    if (!user) return
    const query = supabase.from('profiles').select('*').neq('id', user.id)
    
    if (search) {
      query.or(`full_name.ilike.%${search}%,username.ilike.%${search}%`)
    }
    
    const { data } = await query.limit(20)
    setUsers(data || [])
  }

  async function startChat(targetUser: Profile) {
    if (!user) return
    setLoading(true)

    try {
      // Create chat
      const { data: chat, error } = await supabase
        .from('chats')
        .insert({ is_group: false, created_by: user.id })
        .select()
        .maybeSingle()

      if (error || !chat) {
        console.error('Error creating chat:', error)
        setLoading(false)
        return
      }

      // Add members
      await supabase.from('chat_members').insert([
        { chat_id: chat.id, user_id: user.id },
        { chat_id: chat.id, user_id: targetUser.id }
      ])

      setLoading(false)
      onCreated({
        ...chat,
        members: [targetUser],
        last_message: null,
        unread_count: 0
      })
    } catch (err) {
      console.error('Error starting chat:', err)
      setLoading(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl shadow-xl w-full max-w-md max-h-[80vh] overflow-hidden">
        <div className="p-4 border-b border-primary-100 flex items-center justify-between">
          <h3 className="text-lg font-semibold">{t('newConversation')}</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X className="w-5 h-5" />
          </button>
        </div>
        
        <div className="p-4 border-b border-primary-50">
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={t('searchUsers')}
            className="w-full px-4 py-2 border border-primary-200 rounded-lg focus:ring-2 focus:ring-primary-500"
          />
        </div>

        <div className="overflow-y-auto max-h-80">
          {users.map(u => (
            <button
              key={u.id}
              onClick={() => startChat(u)}
              disabled={loading}
              className="w-full p-4 flex items-center gap-3 hover:bg-primary-50 border-b border-primary-50 transition"
            >
              {u.avatar_url ? (
                <img src={u.avatar_url} alt={u.full_name || ''} className="w-10 h-10 rounded-full" />
              ) : (
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary-300 to-gold-300 flex items-center justify-center">
                  <User className="w-5 h-5 text-white" />
                </div>
              )}
              <div className="text-left">
                <p className="font-medium text-gray-900">{u.full_name || u.username}</p>
                <p className="text-sm text-gray-500">@{u.username}</p>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}

export function ChatWindow({ chat, onBack }: { chat: ChatWithDetails, onBack?: () => void }) {
  const { user } = useAuth()
  const { t } = useLanguage()
  const [messages, setMessages] = useState<MessageWithAuthor[]>([])
  const [newMessage, setNewMessage] = useState('')
  const [loading, setLoading] = useState(true)
  const [sending, setSending] = useState(false)
  const [showMenu, setShowMenu] = useState(false)
  const [showUserProfile, setShowUserProfile] = useState<Profile | null>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    loadMessages()
    const unsubscribe = subscribeToMessages()
    return () => unsubscribe()
  }, [chat.id])

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  function scrollToBottom() {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  async function loadMessages() {
    setLoading(true)
    try {
      const { data } = await supabase
        .from('messages')
        .select('*')
        .eq('chat_id', chat.id)
        .order('created_at', { ascending: true })
        .limit(100)

      if (!data) {
        setMessages([])
        setLoading(false)
        return
      }

      // Enrich with author info
      const userIds = [...new Set(data.map(m => m.user_id))]
      const { data: profiles } = await supabase
        .from('profiles')
        .select('id, full_name, username, avatar_url')
        .in('id', userIds)

      const enriched: MessageWithAuthor[] = data.map(msg => {
        const author = profiles?.find(p => p.id === msg.user_id)
        return {
          ...msg,
          author_name: author?.full_name || author?.username || 'Unknown',
          author_avatar: author?.avatar_url || null
        }
      })

      setMessages(enriched)
    } catch (err) {
      console.error('Error loading messages:', err)
    }
    setLoading(false)
  }

  function subscribeToMessages() {
    const channel = supabase
      .channel(`chat:${chat.id}`)
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'messages',
        filter: `chat_id=eq.${chat.id}`
      }, async (payload) => {
        // Immediately add the new message
        const newMsg = payload.new as any
        
        // Get author info
        const { data: profile } = await supabase
          .from('profiles')
          .select('id, full_name, username, avatar_url')
          .eq('id', newMsg.user_id)
          .maybeSingle()
        
        const enrichedMsg: MessageWithAuthor = {
          ...newMsg,
          author_name: profile?.full_name || profile?.username || 'Unknown',
          author_avatar: profile?.avatar_url || null
        }
        
        setMessages(prev => {
          // Check if message already exists
          if (prev.some(m => m.id === enrichedMsg.id)) {
            return prev
          }
          return [...prev, enrichedMsg]
        })
      })
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }

  async function handleSend() {
    if (!user || !newMessage.trim() || sending) return
    
    const messageContent = newMessage.trim()
    setNewMessage('')
    setSending(true)
    
    try {
      const { error } = await supabase.from('messages').insert({
        chat_id: chat.id,
        user_id: user.id,
        content: messageContent
      })
      
      if (error) {
        console.error('Error sending message:', error)
        setNewMessage(messageContent) // Restore message on error
      }
    } catch (err) {
      console.error('Error sending message:', err)
      setNewMessage(messageContent)
    }
    setSending(false)
  }

  function getChatTitle() {
    if (chat.name) return chat.name
    const otherMembers = chat.members.filter(m => m.id !== user?.id)
    return otherMembers[0]?.full_name || otherMembers[0]?.username || 'Chat'
  }

  function handleAvatarClick(userId: string) {
    const profile = chat.members.find(m => m.id === userId)
    if (profile) {
      setShowUserProfile(profile)
    }
  }

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-primary-100 flex items-center gap-3 bg-white">
        <button onClick={onBack} className="text-gray-600 hover:text-primary-600 transition">
          <ArrowLeft className="w-6 h-6" />
        </button>
        {chat.is_group ? (
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary-400 to-gold-400 flex items-center justify-center">
            <Users className="w-5 h-5 text-white" />
          </div>
        ) : (
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary-300 to-gold-300 flex items-center justify-center">
            <User className="w-5 h-5 text-white" />
          </div>
        )}
        <div className="flex-1">
          <h3 className="font-semibold text-gray-900">{getChatTitle()}</h3>
          <p className="text-xs text-gray-500">{chat.members.length} {t('members')}</p>
        </div>
        <div className="relative">
          <button 
            onClick={() => setShowMenu(!showMenu)}
            className="p-2 text-gray-400 hover:text-gray-600 transition"
          >
            <MoreVertical className="w-5 h-5" />
          </button>
          
          {/* Dropdown Menu */}
          {showMenu && (
            <div className="absolute right-0 top-full mt-1 w-48 bg-white border border-primary-100 rounded-lg shadow-lg overflow-hidden z-50">
              {chat.is_group && (
                <>
                  <button className="w-full px-4 py-3 text-left text-sm hover:bg-primary-50 flex items-center gap-2">
                    <UserPlus className="w-4 h-4" />
                    {t('addMembers')}
                  </button>
                  <button className="w-full px-4 py-3 text-left text-sm hover:bg-primary-50 flex items-center gap-2 text-red-600">
                    <LogOut className="w-4 h-4" />
                    {t('leaveGroup')}
                  </button>
                </>
              )}
              {!chat.is_group && chat.members.filter(m => m.id !== user?.id)[0] && (
                <button 
                  onClick={() => {
                    const otherUser = chat.members.find(m => m.id !== user?.id)
                    if (otherUser) setShowUserProfile(otherUser)
                    setShowMenu(false)
                  }}
                  className="w-full px-4 py-3 text-left text-sm hover:bg-primary-50 flex items-center gap-2"
                >
                  <User className="w-4 h-4" />
                  {t('viewProfile')}
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gradient-to-b from-primary-50/30 to-gold-50/30">
        {loading ? (
          <div className="text-center text-gray-400">{t('loadingMessages')}</div>
        ) : messages.length === 0 ? (
          <div className="text-center text-gray-400">{t('noMessages')}</div>
        ) : (
          messages.map(msg => (
            <div
              key={msg.id}
              className={`flex ${msg.user_id === user?.id ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`flex items-end gap-2 max-w-[70%] ${msg.user_id === user?.id ? 'flex-row-reverse' : ''}`}>
                {msg.user_id !== user?.id && (
                  <button onClick={() => handleAvatarClick(msg.user_id)}>
                    {msg.author_avatar ? (
                      <img src={msg.author_avatar} alt={msg.author_name} className="w-8 h-8 rounded-full cursor-pointer hover:ring-2 hover:ring-primary-300 transition" />
                    ) : (
                      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary-300 to-gold-300 flex items-center justify-center cursor-pointer hover:ring-2 hover:ring-primary-300 transition">
                        <User className="w-4 h-4 text-white" />
                      </div>
                    )}
                  </button>
                )}
                <div
                  className={`p-3 rounded-2xl ${
                    msg.user_id === user?.id
                      ? 'bg-gradient-to-r from-primary-600 to-primary-500 text-white rounded-br-md shadow-md'
                      : 'bg-white shadow-sm rounded-bl-md'
                  }`}
                >
                  {msg.user_id !== user?.id && chat.is_group && (
                    <p className="text-xs font-medium text-primary-600 mb-1">{msg.author_name}</p>
                  )}
                  <p className={`text-sm ${msg.user_id === user?.id ? 'text-white' : 'text-gray-900'}`}>
                    {msg.content}
                  </p>
                  <p className={`text-xs mt-1 ${msg.user_id === user?.id ? 'text-primary-200' : 'text-gray-400'}`}>
                    {new Date(msg.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
              </div>
            </div>
          ))
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="p-4 border-t border-primary-100 bg-white">
        <div className="flex items-center gap-2">
          <input
            type="text"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
            placeholder={t('typeMessage')}
            className="flex-1 px-4 py-2 border border-primary-200 rounded-full focus:ring-2 focus:ring-primary-500 focus:border-transparent"
          />
          <button
            onClick={handleSend}
            disabled={!newMessage.trim() || sending}
            className="p-3 bg-gradient-to-r from-primary-600 to-primary-500 text-white rounded-full hover:from-primary-700 hover:to-primary-600 disabled:opacity-50 shadow-md transition"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* User Profile Modal */}
      {showUserProfile && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-sm p-6">
            <div className="flex justify-end">
              <button onClick={() => setShowUserProfile(null)} className="text-gray-400 hover:text-gray-600">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="text-center">
              {showUserProfile.avatar_url ? (
                <img src={showUserProfile.avatar_url} alt={showUserProfile.full_name || ''} className="w-24 h-24 rounded-full mx-auto mb-4 ring-4 ring-primary-100" />
              ) : (
                <div className="w-24 h-24 rounded-full bg-gradient-to-br from-primary-400 to-gold-400 flex items-center justify-center mx-auto mb-4">
                  <User className="w-12 h-12 text-white" />
                </div>
              )}
              <h3 className="text-xl font-bold text-gray-900">{showUserProfile.full_name || showUserProfile.username}</h3>
              <p className="text-gray-500">@{showUserProfile.username}</p>
              {showUserProfile.bio && (
                <p className="mt-3 text-gray-700">{showUserProfile.bio}</p>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
