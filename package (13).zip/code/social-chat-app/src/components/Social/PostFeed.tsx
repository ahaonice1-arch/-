import React, { useState, useEffect, useRef } from 'react'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../contexts/AuthContext'
import { useLanguage } from '../../contexts/LanguageContext'
import type { PostWithDetails } from '../../types/database'
import { Heart, MessageCircle, Send, User, Image, X } from 'lucide-react'

export function PostFeed() {
  const { user } = useAuth()
  const { t } = useLanguage()
  const [posts, setPosts] = useState<PostWithDetails[]>([])
  const [loading, setLoading] = useState(true)
  const [newPost, setNewPost] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [selectedImage, setSelectedImage] = useState<File | null>(null)
  const [imagePreview, setImagePreview] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    loadPosts()
  }, [user])

  async function loadPosts() {
    setLoading(true)
    try {
      const { data: postsData, error } = await supabase
        .from('posts')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(50)

      if (error) {
        console.error('Error loading posts:', error)
        setLoading(false)
        return
      }

      if (!postsData || postsData.length === 0) {
        setPosts([])
        setLoading(false)
        return
      }

      // Fetch user profiles
      const userIds = [...new Set(postsData.map(p => p.user_id))]
      const { data: profiles } = await supabase
        .from('profiles')
        .select('id, username, full_name, avatar_url')
        .in('id', userIds)

      // Fetch likes counts
      const postIds = postsData.map(p => p.id)
      const { data: likes } = await supabase
        .from('likes')
        .select('post_id, user_id')
        .in('post_id', postIds)

      // Fetch comments counts
      const { data: comments } = await supabase
        .from('comments')
        .select('post_id')
        .in('post_id', postIds)

      // Combine data
      const enrichedPosts: PostWithDetails[] = postsData.map(post => {
        const author = profiles?.find(p => p.id === post.user_id)
        const postLikes = likes?.filter(l => l.post_id === post.id) || []
        const postComments = comments?.filter(c => c.post_id === post.id) || []
        
        return {
          ...post,
          author_name: author?.full_name || author?.username || 'Unknown',
          author_avatar: author?.avatar_url || null,
          likes_count: postLikes.length,
          comments_count: postComments.length,
          is_liked: user ? postLikes.some(l => l.user_id === user.id) : false
        }
      })

      setPosts(enrichedPosts)
    } catch (err) {
      console.error('Error loading posts:', err)
    }
    setLoading(false)
  }

  function handleImageSelect(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (file) {
      setSelectedImage(file)
      const reader = new FileReader()
      reader.onloadend = () => {
        setImagePreview(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  function clearImage() {
    setSelectedImage(null)
    setImagePreview(null)
    if (fileInputRef.current) {
      fileInputRef.current.value = ''
    }
  }

  async function handleCreatePost() {
    if (!user || (!newPost.trim() && !selectedImage)) return
    
    setSubmitting(true)
    try {
      let imageUrl = null

      // Upload image if selected
      if (selectedImage) {
        const fileExt = selectedImage.name.split('.').pop()
        const fileName = `${user.id}-${Date.now()}.${fileExt}`
        const { data: uploadData, error: uploadError } = await supabase.storage
          .from('posts')
          .upload(fileName, selectedImage)

        if (uploadError) {
          console.error('Error uploading image:', uploadError)
        } else {
          const { data: { publicUrl } } = supabase.storage
            .from('posts')
            .getPublicUrl(fileName)
          imageUrl = publicUrl
        }
      }

      // Create post
      const { error } = await supabase.from('posts').insert({
        user_id: user.id,
        content: newPost.trim(),
        image_url: imageUrl
      })
      
      if (error) {
        console.error('Error creating post:', error)
      } else {
        setNewPost('')
        clearImage()
        await loadPosts()
      }
    } catch (err) {
      console.error('Error creating post:', err)
    }
    setSubmitting(false)
  }

  async function handleLike(postId: string, isLiked: boolean) {
    if (!user) return
    
    // Optimistic update
    setPosts(prev => prev.map(post => {
      if (post.id === postId) {
        return {
          ...post,
          is_liked: !isLiked,
          likes_count: isLiked ? post.likes_count - 1 : post.likes_count + 1
        }
      }
      return post
    }))
    
    try {
      if (isLiked) {
        await supabase
          .from('likes')
          .delete()
          .eq('post_id', postId)
          .eq('user_id', user.id)
      } else {
        await supabase.from('likes').insert({
          post_id: postId,
          user_id: user.id
        })
      }
    } catch (err) {
      // Revert on error
      setPosts(prev => prev.map(post => {
        if (post.id === postId) {
          return {
            ...post,
            is_liked: isLiked,
            likes_count: isLiked ? post.likes_count + 1 : post.likes_count - 1
          }
        }
        return post
      }))
    }
  }

  if (loading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3].map(i => (
          <div key={i} className="bg-white rounded-xl p-4 animate-pulse shadow-sm">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-primary-100 rounded-full" />
              <div className="h-4 bg-primary-100 rounded w-32" />
            </div>
            <div className="h-4 bg-primary-100 rounded w-full mb-2" />
            <div className="h-4 bg-primary-100 rounded w-2/3" />
          </div>
        ))}
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {user && (
        <div className="bg-white rounded-xl shadow-sm p-4 border border-primary-100">
          <textarea
            value={newPost}
            onChange={(e) => setNewPost(e.target.value)}
            placeholder={t('whatsOnYourMind')}
            className="w-full p-3 border border-primary-200 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent resize-none"
            rows={3}
          />
          
          {/* Image Preview */}
          {imagePreview && (
            <div className="relative mt-3">
              <img
                src={imagePreview}
                alt="Preview"
                className="w-full max-h-64 object-cover rounded-lg"
              />
              <button
                onClick={clearImage}
                className="absolute top-2 right-2 p-1 bg-black/50 rounded-full text-white hover:bg-black/70"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}
          
          <div className="flex items-center justify-between mt-3">
            <div className="flex items-center gap-2">
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleImageSelect}
                className="hidden"
              />
              <button
                onClick={() => fileInputRef.current?.click()}
                className="text-gray-500 hover:text-primary-600 p-2 rounded-lg hover:bg-primary-50 transition"
                title={t('addImage')}
              >
                <Image className="w-5 h-5" />
              </button>
            </div>
            <button
              onClick={handleCreatePost}
              disabled={submitting || (!newPost.trim() && !selectedImage)}
              className="px-4 py-2 bg-gradient-to-r from-primary-600 to-primary-500 text-white rounded-lg hover:from-primary-700 hover:to-primary-600 disabled:opacity-50 flex items-center gap-2 shadow-md transition"
            >
              <Send className="w-4 h-4" />
              {t('post')}
            </button>
          </div>
        </div>
      )}

      {posts.length === 0 ? (
        <div className="text-center py-12 text-gray-500 bg-white rounded-xl shadow-sm">
          {t('noPosts')}
        </div>
      ) : (
        posts.map(post => (
          <PostCard
            key={post.id}
            post={post}
            onLike={() => handleLike(post.id, post.is_liked)}
          />
        ))
      )}
    </div>
  )
}

interface PostCardProps {
  post: PostWithDetails
  onLike: () => void
}

function PostCard({ post, onLike }: PostCardProps) {
  const [showComments, setShowComments] = useState(false)

  return (
    <div className="bg-white rounded-xl shadow-sm p-4 border border-primary-100">
      <div className="flex items-center gap-3 mb-3">
        {post.author_avatar ? (
          <img
            src={post.author_avatar}
            alt={post.author_name}
            className="w-10 h-10 rounded-full object-cover ring-2 ring-primary-100"
          />
        ) : (
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary-400 to-gold-400 flex items-center justify-center">
            <User className="w-5 h-5 text-white" />
          </div>
        )}
        <div>
          <p className="font-semibold text-gray-900">{post.author_name}</p>
          <p className="text-xs text-gray-500">
            {new Date(post.created_at).toLocaleDateString()}
          </p>
        </div>
      </div>
      
      <p className="text-gray-800 mb-3 whitespace-pre-wrap">{post.content}</p>
      
      {post.image_url && (
        <img
          src={post.image_url}
          alt="Post"
          className="w-full rounded-lg mb-3"
        />
      )}
      
      <div className="flex items-center gap-4 pt-3 border-t border-primary-50">
        <button
          onClick={onLike}
          className={`flex items-center gap-1 transition ${
            post.is_liked ? 'text-red-500' : 'text-gray-500 hover:text-red-500'
          }`}
        >
          <Heart className={`w-5 h-5 ${post.is_liked ? 'fill-current' : ''}`} />
          <span className="text-sm">{post.likes_count}</span>
        </button>
        <button
          onClick={() => setShowComments(!showComments)}
          className="flex items-center gap-1 text-gray-500 hover:text-primary-500 transition"
        >
          <MessageCircle className="w-5 h-5" />
          <span className="text-sm">{post.comments_count}</span>
        </button>
      </div>
      
      {showComments && <Comments postId={post.id} />}
    </div>
  )
}

function Comments({ postId }: { postId: string }) {
  const { user } = useAuth()
  const { t } = useLanguage()
  const [comments, setComments] = useState<any[]>([])
  const [newComment, setNewComment] = useState('')
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    loadComments()
  }, [postId])

  async function loadComments() {
    setLoading(true)
    try {
      const { data: commentsData, error } = await supabase
        .from('comments')
        .select('*')
        .eq('post_id', postId)
        .order('created_at', { ascending: true })

      if (error) {
        console.error('Error loading comments:', error)
        setLoading(false)
        return
      }

      if (commentsData && commentsData.length > 0) {
        const userIds = [...new Set(commentsData.map(c => c.user_id))]
        const { data: profiles } = await supabase
          .from('profiles')
          .select('id, username, full_name, avatar_url')
          .in('id', userIds)

        const enriched = commentsData.map(comment => {
          const author = profiles?.find(p => p.id === comment.user_id)
          return {
            ...comment,
            author_name: author?.full_name || author?.username || 'Unknown',
            author_avatar: author?.avatar_url
          }
        })
        setComments(enriched)
      } else {
        setComments([])
      }
    } catch (err) {
      console.error('Error loading comments:', err)
    }
    setLoading(false)
  }

  async function handleSubmit() {
    if (!user || !newComment.trim() || submitting) return
    
    setSubmitting(true)
    try {
      const { error } = await supabase.from('comments').insert({
        post_id: postId,
        user_id: user.id,
        content: newComment.trim()
      })
      
      if (error) {
        console.error('Error creating comment:', error)
      } else {
        setNewComment('')
        await loadComments()
      }
    } catch (err) {
      console.error('Error creating comment:', err)
    }
    setSubmitting(false)
  }

  return (
    <div className="mt-4 pt-4 border-t border-primary-50 space-y-3">
      {loading ? (
        <div className="text-gray-400 text-sm">{t('loadingComments')}</div>
      ) : (
        comments.map(comment => (
          <div key={comment.id} className="flex items-start gap-2">
            {comment.author_avatar ? (
              <img
                src={comment.author_avatar}
                alt={comment.author_name}
                className="w-8 h-8 rounded-full"
              />
            ) : (
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary-300 to-gold-300 flex items-center justify-center">
                <User className="w-4 h-4 text-white" />
              </div>
            )}
            <div className="flex-1 bg-primary-50 rounded-lg p-2">
              <p className="text-sm font-semibold text-gray-900">{comment.author_name}</p>
              <p className="text-sm text-gray-700">{comment.content}</p>
            </div>
          </div>
        ))
      )}
      
      {user && (
        <div className="flex items-center gap-2">
          <input
            type="text"
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
            placeholder={t('writeComment')}
            className="flex-1 px-3 py-2 border border-primary-200 rounded-lg text-sm focus:ring-2 focus:ring-primary-500"
            onKeyPress={(e) => e.key === 'Enter' && handleSubmit()}
            disabled={submitting}
          />
          <button
            onClick={handleSubmit}
            disabled={!newComment.trim() || submitting}
            className="p-2 bg-gradient-to-r from-primary-600 to-primary-500 text-white rounded-lg hover:from-primary-700 hover:to-primary-600 disabled:opacity-50 transition"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>
  )
}
