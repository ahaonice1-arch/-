import React, { useState, useRef } from 'react'
import { useAuth } from '../../contexts/AuthContext'
import { useLanguage } from '../../contexts/LanguageContext'
import { supabase } from '../../lib/supabase'
import { User, Camera, Save, Globe } from 'lucide-react'

export function UserProfile() {
  const { profile, updateProfile, refreshProfile } = useAuth()
  const { language, setLanguage, t } = useLanguage()
  const [editing, setEditing] = useState(false)
  const [fullName, setFullName] = useState(profile?.full_name || '')
  const [username, setUsername] = useState(profile?.username || '')
  const [bio, setBio] = useState(profile?.bio || '')
  const [loading, setLoading] = useState(false)
  const [uploadingAvatar, setUploadingAvatar] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const languages = [
    { code: 'zh', label: '中文' },
    { code: 'en', label: 'English' },
    { code: 'my', label: 'Myanmar' }
  ]

  async function handleSave() {
    setLoading(true)
    await updateProfile({
      full_name: fullName,
      username,
      bio
    })
    setLoading(false)
    setEditing(false)
  }

  async function handleAvatarUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file || !profile) return

    setUploadingAvatar(true)
    try {
      const fileExt = file.name.split('.').pop()
      const fileName = `${profile.id}-${Date.now()}.${fileExt}`
      
      // Upload to storage
      const { error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(fileName, file)

      if (uploadError) {
        console.error('Error uploading avatar:', uploadError)
        setUploadingAvatar(false)
        return
      }

      // Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from('avatars')
        .getPublicUrl(fileName)

      // Update profile
      await updateProfile({ avatar_url: publicUrl })
      await refreshProfile()
    } catch (err) {
      console.error('Error uploading avatar:', err)
    }
    setUploadingAvatar(false)
  }

  if (!profile) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-pulse text-gray-400">{t('loadingProfile')}</div>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-xl shadow-sm p-6 border border-primary-100">
        <div className="flex flex-col sm:flex-row items-start gap-6">
          {/* Avatar Section */}
          <div className="relative mx-auto sm:mx-0">
            {profile.avatar_url ? (
              <img
                src={profile.avatar_url}
                alt={profile.full_name || 'User'}
                className="w-24 h-24 rounded-full object-cover ring-4 ring-primary-100"
              />
            ) : (
              <div className="w-24 h-24 rounded-full bg-gradient-to-br from-primary-400 to-gold-400 flex items-center justify-center">
                <User className="w-12 h-12 text-white" />
              </div>
            )}
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleAvatarUpload}
              className="hidden"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={uploadingAvatar}
              className="absolute bottom-0 right-0 p-1.5 bg-gradient-to-r from-primary-600 to-primary-500 rounded-full text-white hover:from-primary-700 hover:to-primary-600 shadow-md transition disabled:opacity-50"
              title={t('changeAvatar')}
            >
              <Camera className="w-4 h-4" />
            </button>
            {uploadingAvatar && (
              <div className="absolute inset-0 flex items-center justify-center bg-black/50 rounded-full">
                <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin" />
              </div>
            )}
          </div>
          
          {/* Profile Info Section */}
          <div className="flex-1 w-full">
            {editing ? (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">{t('fullName')}</label>
                  <input
                    type="text"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full px-3 py-2 border border-primary-200 rounded-lg focus:ring-2 focus:ring-primary-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">{t('username')}</label>
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="w-full px-3 py-2 border border-primary-200 rounded-lg focus:ring-2 focus:ring-primary-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">{t('bio')}</label>
                  <textarea
                    value={bio}
                    onChange={(e) => setBio(e.target.value)}
                    className="w-full px-3 py-2 border border-primary-200 rounded-lg focus:ring-2 focus:ring-primary-500"
                    rows={3}
                  />
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={handleSave}
                    disabled={loading}
                    className="px-4 py-2 bg-gradient-to-r from-primary-600 to-primary-500 text-white rounded-lg hover:from-primary-700 hover:to-primary-600 disabled:opacity-50 flex items-center gap-2 shadow-md transition"
                  >
                    <Save className="w-4 h-4" />
                    {loading ? t('saving') : t('save')}
                  </button>
                  <button
                    onClick={() => setEditing(false)}
                    className="px-4 py-2 border border-primary-200 rounded-lg hover:bg-primary-50 transition"
                  >
                    {t('cancel')}
                  </button>
                </div>
              </div>
            ) : (
              <div>
                <h2 className="text-2xl font-bold text-gray-900">{profile.full_name || t('noNameSet')}</h2>
                <p className="text-gray-500">@{profile.username || 'unknown'}</p>
                <p className="mt-2 text-gray-700">{profile.bio || t('noBioYet')}</p>
                <button
                  onClick={() => {
                    setFullName(profile.full_name || '')
                    setUsername(profile.username || '')
                    setBio(profile.bio || '')
                    setEditing(true)
                  }}
                  className="mt-4 px-4 py-2 border border-primary-200 rounded-lg hover:bg-primary-50 transition"
                >
                  {t('editProfile')}
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Language Settings */}
      <div className="bg-white rounded-xl shadow-sm p-6 border border-primary-100">
        <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
          <Globe className="w-5 h-5 text-primary-600" />
          {t('language')}
        </h3>
        <div className="flex flex-wrap gap-2">
          {languages.map(lang => (
            <button
              key={lang.code}
              onClick={() => setLanguage(lang.code as 'zh' | 'en' | 'my')}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition ${
                language === lang.code
                  ? 'bg-gradient-to-r from-primary-600 to-primary-500 text-white shadow-md'
                  : 'border border-primary-200 text-gray-700 hover:bg-primary-50'
              }`}
            >
              {lang.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}
