import React, { useState, useEffect } from 'react'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../contexts/AuthContext'
import { useLanguage } from '../../contexts/LanguageContext'
import type { Notification } from '../../types/database'
import { Bell, Heart, MessageCircle, UserPlus, Check, Trash2 } from 'lucide-react'

export function NotificationList() {
  const { user } = useAuth()
  const { t } = useLanguage()
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (user) {
      loadNotifications()
      const unsubscribe = subscribeToNotifications()
      return () => unsubscribe?.()
    }
  }, [user])

  async function loadNotifications() {
    if (!user) return
    setLoading(true)

    try {
      const { data } = await supabase
        .from('notifications')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(50)

      setNotifications(data || [])
    } catch (err) {
      console.error('Error loading notifications:', err)
    }
    setLoading(false)
  }

  function subscribeToNotifications() {
    if (!user) return

    const channel = supabase
      .channel('notifications')
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'notifications',
        filter: `user_id=eq.${user.id}`
      }, () => {
        loadNotifications()
      })
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }

  async function markAsRead(id: string) {
    await supabase
      .from('notifications')
      .update({ read: true })
      .eq('id', id)

    setNotifications(prev => 
      prev.map(n => n.id === id ? { ...n, read: true } : n)
    )
  }

  async function markAllAsRead() {
    if (!user) return

    await supabase
      .from('notifications')
      .update({ read: true })
      .eq('user_id', user.id)
      .eq('read', false)

    setNotifications(prev => prev.map(n => ({ ...n, read: true })))
  }

  async function deleteNotification(id: string) {
    await supabase.from('notifications').delete().eq('id', id)
    setNotifications(prev => prev.filter(n => n.id !== id))
  }

  function getIcon(type: string) {
    switch (type) {
      case 'like': return <Heart className="w-5 h-5 text-red-500" />
      case 'comment': return <MessageCircle className="w-5 h-5 text-primary-500" />
      case 'friend_request': return <UserPlus className="w-5 h-5 text-green-500" />
      case 'friend_accepted': return <UserPlus className="w-5 h-5 text-gold-500" />
      default: return <Bell className="w-5 h-5 text-gray-500" />
    }
  }

  const unreadCount = notifications.filter(n => !n.read).length

  if (loading) {
    return (
      <div className="bg-white rounded-xl shadow-sm p-8 text-center border border-primary-100">
        <div className="animate-pulse text-gray-400">{t('loading')}</div>
      </div>
    )
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-primary-100">
      <div className="p-4 border-b border-primary-100 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Bell className="w-5 h-5 text-primary-600" />
          <h2 className="font-semibold text-gray-900">{t('notifications')}</h2>
          {unreadCount > 0 && (
            <span className="px-2 py-0.5 bg-gradient-to-r from-primary-600 to-primary-500 text-white text-xs rounded-full">
              {unreadCount}
            </span>
          )}
        </div>
        {unreadCount > 0 && (
          <button
            onClick={markAllAsRead}
            className="text-sm text-primary-600 hover:text-primary-700"
          >
            {t('markAllRead')}
          </button>
        )}
      </div>

      {notifications.length === 0 ? (
        <div className="p-8 text-center text-gray-500">
          <Bell className="w-12 h-12 mx-auto mb-2 text-primary-200" />
          <p>{t('noNotifications')}</p>
        </div>
      ) : (
        <div className="divide-y divide-primary-50">
          {notifications.map(notification => (
            <div
              key={notification.id}
              className={`p-4 flex items-start gap-3 hover:bg-primary-50 transition ${
                !notification.read ? 'bg-primary-50/50' : ''
              }`}
            >
              <div className="mt-1">
                {getIcon(notification.type)}
              </div>
              <div className="flex-1 min-w-0">
                <p className={`text-sm ${!notification.read ? 'font-medium' : ''}`}>
                  {notification.content}
                </p>
                <p className="text-xs text-gray-400 mt-1">
                  {new Date(notification.created_at).toLocaleDateString(undefined, {
                    month: 'short',
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit'
                  })}
                </p>
              </div>
              <div className="flex gap-1">
                {!notification.read && (
                  <button
                    onClick={() => markAsRead(notification.id)}
                    className="p-1 text-gray-400 hover:text-primary-600 transition"
                    title="Mark as read"
                  >
                    <Check className="w-4 h-4" />
                  </button>
                )}
                <button
                  onClick={() => deleteNotification(notification.id)}
                  className="p-1 text-gray-400 hover:text-red-600 transition"
                  title="Delete"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

export function NotificationBadge() {
  const { user } = useAuth()
  const [count, setCount] = useState(0)

  useEffect(() => {
    if (user) {
      loadCount()
      const unsubscribe = subscribeToNotifications()
      return () => unsubscribe?.()
    }
  }, [user])

  async function loadCount() {
    if (!user) return

    try {
      const { count } = await supabase
        .from('notifications')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', user.id)
        .eq('read', false)

      setCount(count || 0)
    } catch (err) {
      console.error('Error loading notification count:', err)
    }
  }

  function subscribeToNotifications() {
    if (!user) return

    const channel = supabase
      .channel('notification_count')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'notifications',
        filter: `user_id=eq.${user.id}`
      }, () => {
        loadCount()
      })
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }

  if (count === 0) return null

  return (
    <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
      {count > 9 ? '9+' : count}
    </span>
  )
}
