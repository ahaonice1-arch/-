import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://saiozczbjnxqeynnrlkp.supabase.co'
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNhaW96Y3piam54cWV5bm5ybGtwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjM2MjA2MjMsImV4cCI6MjA3OTE5NjYyM30.M1d-1YhqOASqm8z9F46_bItyi5BANH8Q2kMbrXfH9As'

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

export default supabase
