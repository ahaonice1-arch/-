import { useState } from 'react'
import { AuthProvider, useAuth } from './contexts/AuthContext'
import { LanguageProvider } from './contexts/LanguageContext'
import { AuthPage } from './components/AuthPage'
import { MainLayout } from './components/Layout'
import { PostFeed } from './components/Social/PostFeed'
import { ChatList, ChatWindow } from './components/Chat/ChatComponents'
import { FriendsList } from './components/Friends/FriendsList'
import { NotificationList } from './components/Notifications/NotificationList'
import { UserProfile } from './components/Auth/UserProfile'
import type { ChatWithDetails } from './types/database'
import './App.css'

type Tab = 'feed' | 'chat' | 'friends' | 'notifications' | 'profile'

function AppContent() {
  const { user, loading } = useAuth()
  const [activeTab, setActiveTab] = useState<Tab>('feed')
  const [selectedChat, setSelectedChat] = useState<ChatWithDetails | null>(null)

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary-50 to-gold-50">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-primary-600 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-gray-500">Loading...</p>
        </div>
      </div>
    )
  }

  if (!user) {
    return <AuthPage />
  }

  function renderContent() {
    switch (activeTab) {
      case 'feed':
        return <PostFeed />
      case 'chat':
        if (selectedChat) {
          return (
            <div className="h-[calc(100vh-8rem)] md:h-[calc(100vh-6rem)] -mx-4 md:mx-0 md:rounded-xl overflow-hidden bg-white md:shadow-sm">
              <ChatWindow
                chat={selectedChat}
                onBack={() => setSelectedChat(null)}
              />
            </div>
          )
        }
        return (
          <div className="h-[calc(100vh-8rem)] md:h-[calc(100vh-6rem)] -mx-4 md:mx-0 md:rounded-xl overflow-hidden bg-white md:shadow-sm">
            <ChatList
              onSelectChat={setSelectedChat}
              selectedChatId={selectedChat?.id}
            />
          </div>
        )
      case 'friends':
        return <FriendsList />
      case 'notifications':
        return <NotificationList />
      case 'profile':
        return <UserProfile />
      default:
        return <PostFeed />
    }
  }

  return (
    <MainLayout activeTab={activeTab} onTabChange={setActiveTab}>
      {renderContent()}
    </MainLayout>
  )
}

function App() {
  return (
    <AuthProvider>
      <LanguageProvider>
        <AppContent />
      </LanguageProvider>
    </AuthProvider>
  )
}

export default App
