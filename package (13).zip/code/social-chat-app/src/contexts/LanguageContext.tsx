import React, { createContext, useContext, useState, useEffect } from 'react'
import { useAuth } from './AuthContext'
import { supabase } from '../lib/supabase'

type Language = 'zh' | 'en' | 'my'

interface Translations {
  [key: string]: {
    zh: string
    en: string
    my: string
  }
}

const translations: Translations = {
  // App branding
  appName: {
    zh: '光信IM',
    en: 'GuangXin IM',
    my: 'GuangXin IM'
  },
  tagline: {
    zh: '光引话题，信续闲谈',
    en: 'Light sparks topics, trust continues chats',
    my: 'Light sparks topics, trust continues chats'
  },
  
  // Navigation
  feed: {
    zh: '动态',
    en: 'Feed',
    my: 'Feed'
  },
  chat: {
    zh: '聊天',
    en: 'Chat',
    my: 'Chat'
  },
  friends: {
    zh: '好友',
    en: 'Friends',
    my: 'Friends'
  },
  notifications: {
    zh: '通知',
    en: 'Notifications',
    my: 'Notifications'
  },
  profile: {
    zh: '我的',
    en: 'Profile',
    my: 'Profile'
  },
  
  // Auth
  signIn: {
    zh: '登录',
    en: 'Sign In',
    my: 'Sign In'
  },
  signUp: {
    zh: '注册',
    en: 'Sign Up',
    my: 'Sign Up'
  },
  signOut: {
    zh: '退出登录',
    en: 'Sign Out',
    my: 'Sign Out'
  },
  email: {
    zh: '邮箱',
    en: 'Email',
    my: 'Email'
  },
  password: {
    zh: '密码',
    en: 'Password',
    my: 'Password'
  },
  username: {
    zh: '用户名',
    en: 'Username',
    my: 'Username'
  },
  
  // Feed
  whatsOnYourMind: {
    zh: '分享你的想法...',
    en: "What's on your mind?",
    my: "What's on your mind?"
  },
  post: {
    zh: '发布',
    en: 'Post',
    my: 'Post'
  },
  noPosts: {
    zh: '暂无动态，快来分享吧！',
    en: 'No posts yet. Be the first to share!',
    my: 'No posts yet. Be the first to share!'
  },
  writeComment: {
    zh: '写评论...',
    en: 'Write a comment...',
    my: 'Write a comment...'
  },
  loadingComments: {
    zh: '加载评论中...',
    en: 'Loading comments...',
    my: 'Loading comments...'
  },
  addImage: {
    zh: '添加图片',
    en: 'Add Image',
    my: 'Add Image'
  },
  
  // Chat
  chats: {
    zh: '聊天列表',
    en: 'Chats',
    my: 'Chats'
  },
  searchConversations: {
    zh: '搜索对话...',
    en: 'Search conversations...',
    my: 'Search conversations...'
  },
  noConversations: {
    zh: '暂无对话',
    en: 'No conversations yet',
    my: 'No conversations yet'
  },
  newConversation: {
    zh: '新建对话',
    en: 'New Conversation',
    my: 'New Conversation'
  },
  searchUsers: {
    zh: '搜索用户...',
    en: 'Search users...',
    my: 'Search users...'
  },
  typeMessage: {
    zh: '输入消息...',
    en: 'Type a message...',
    my: 'Type a message...'
  },
  noMessages: {
    zh: '暂无消息，开始对话吧！',
    en: 'No messages yet. Start the conversation!',
    my: 'No messages yet. Start the conversation!'
  },
  loadingMessages: {
    zh: '加载消息中...',
    en: 'Loading messages...',
    my: 'Loading messages...'
  },
  loadingChats: {
    zh: '加载聊天中...',
    en: 'Loading chats...',
    my: 'Loading chats...'
  },
  members: {
    zh: '成员',
    en: 'members',
    my: 'members'
  },
  groupSettings: {
    zh: '群组设置',
    en: 'Group Settings',
    my: 'Group Settings'
  },
  addMembers: {
    zh: '添加成员',
    en: 'Add Members',
    my: 'Add Members'
  },
  leaveGroup: {
    zh: '离开群组',
    en: 'Leave Group',
    my: 'Leave Group'
  },
  viewProfile: {
    zh: '查看资料',
    en: 'View Profile',
    my: 'View Profile'
  },
  
  // Friends
  friendsList: {
    zh: '好友列表',
    en: 'Friends',
    my: 'Friends'
  },
  requests: {
    zh: '请求',
    en: 'Requests',
    my: 'Requests'
  },
  findFriends: {
    zh: '查找好友',
    en: 'Find Friends',
    my: 'Find Friends'
  },
  noFriends: {
    zh: '暂无好友',
    en: 'No friends yet',
    my: 'No friends yet'
  },
  noPendingRequests: {
    zh: '暂无待处理请求',
    en: 'No pending requests',
    my: 'No pending requests'
  },
  searchByName: {
    zh: '按名字或用户名搜索...',
    en: 'Search by name or username...',
    my: 'Search by name or username...'
  },
  noUsersFound: {
    zh: '未找到用户',
    en: 'No users found',
    my: 'No users found'
  },
  searchUsersToAdd: {
    zh: '搜索用户添加好友',
    en: 'Search for users to add',
    my: 'Search for users to add'
  },
  wantsToBeFriend: {
    zh: '想要成为你的好友',
    en: 'wants to be your friend',
    my: 'wants to be your friend'
  },
  add: {
    zh: '添加',
    en: 'Add',
    my: 'Add'
  },
  pending: {
    zh: '等待中',
    en: 'Pending',
    my: 'Pending'
  },
  alreadyFriends: {
    zh: '已是好友',
    en: 'Friends',
    my: 'Friends'
  },
  searching: {
    zh: '搜索中...',
    en: 'Searching...',
    my: 'Searching...'
  },
  
  // Profile
  editProfile: {
    zh: '编辑资料',
    en: 'Edit Profile',
    my: 'Edit Profile'
  },
  save: {
    zh: '保存',
    en: 'Save',
    my: 'Save'
  },
  cancel: {
    zh: '取消',
    en: 'Cancel',
    my: 'Cancel'
  },
  fullName: {
    zh: '全名',
    en: 'Full Name',
    my: 'Full Name'
  },
  bio: {
    zh: '简介',
    en: 'Bio',
    my: 'Bio'
  },
  noNameSet: {
    zh: '未设置名字',
    en: 'No name set',
    my: 'No name set'
  },
  noBioYet: {
    zh: '暂无简介',
    en: 'No bio yet',
    my: 'No bio yet'
  },
  loadingProfile: {
    zh: '加载资料中...',
    en: 'Loading profile...',
    my: 'Loading profile...'
  },
  changeAvatar: {
    zh: '更换头像',
    en: 'Change Avatar',
    my: 'Change Avatar'
  },
  uploadingAvatar: {
    zh: '上传头像中...',
    en: 'Uploading avatar...',
    my: 'Uploading avatar...'
  },
  language: {
    zh: '语言',
    en: 'Language',
    my: 'Language'
  },
  
  // Notifications
  noNotifications: {
    zh: '暂无通知',
    en: 'No notifications',
    my: 'No notifications'
  },
  markAllRead: {
    zh: '全部已读',
    en: 'Mark all read',
    my: 'Mark all read'
  },
  friendRequest: {
    zh: '好友请求',
    en: 'Friend Request',
    my: 'Friend Request'
  },
  newMessage: {
    zh: '新消息',
    en: 'New Message',
    my: 'New Message'
  },
  newLike: {
    zh: '有人点赞了你的动态',
    en: 'Someone liked your post',
    my: 'Someone liked your post'
  },
  newComment: {
    zh: '有人评论了你的动态',
    en: 'Someone commented on your post',
    my: 'Someone commented on your post'
  },
  
  // Common
  loading: {
    zh: '加载中...',
    en: 'Loading...',
    my: 'Loading...'
  },
  error: {
    zh: '出错了',
    en: 'Error',
    my: 'Error'
  },
  success: {
    zh: '成功',
    en: 'Success',
    my: 'Success'
  },
  close: {
    zh: '关闭',
    en: 'Close',
    my: 'Close'
  },
  unknown: {
    zh: '未知',
    en: 'Unknown',
    my: 'Unknown'
  },
  noMessagesYet: {
    zh: '暂无消息',
    en: 'No messages yet',
    my: 'No messages yet'
  },
  saving: {
    zh: '保存中...',
    en: 'Saving...',
    my: 'Saving...'
  },
}

interface LanguageContextType {
  language: Language
  setLanguage: (lang: Language) => void
  t: (key: string) => string
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const { user, profile } = useAuth()
  const [language, setLanguageState] = useState<Language>('zh')

  useEffect(() => {
    // Load language from profile or localStorage
    if (profile?.language) {
      setLanguageState(profile.language as Language)
    } else {
      const savedLang = localStorage.getItem('language') as Language
      if (savedLang && ['zh', 'en', 'my'].includes(savedLang)) {
        setLanguageState(savedLang)
      }
    }
  }, [profile])

  async function setLanguage(lang: Language) {
    setLanguageState(lang)
    localStorage.setItem('language', lang)
    
    // Update in database if user is logged in
    if (user) {
      await supabase
        .from('profiles')
        .update({ language: lang })
        .eq('id', user.id)
    }
  }

  function t(key: string): string {
    const translation = translations[key]
    if (!translation) {
      console.warn(`Missing translation for key: ${key}`)
      return key
    }
    return translation[language] || translation.en || key
  }

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  )
}

export function useLanguage() {
  const context = useContext(LanguageContext)
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider')
  }
  return context
}
