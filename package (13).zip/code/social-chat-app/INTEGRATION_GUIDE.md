# Integration Guide: Adding Social Features to Existing Chat App

This guide explains how to integrate the social features (posts, friends, notifications) into your existing chat application at https://ixs8uboct1is.space.minimaxi.com/

## Overview

Your existing chat app already has:
- Chat functionality
- User authentication
- Message handling
- WebRTC capabilities

This integration adds:
- Social feed with posts, likes, and comments
- Friend system with requests
- Notifications for social interactions
- User profiles

## Step-by-Step Integration

### 1. Install Dependencies (if needed)

If your existing app doesn't have Supabase installed:

```bash
pnpm add @supabase/supabase-js
```

### 2. Configure Supabase

Update or create `src/lib/supabase.ts`:

```typescript
import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'https://saiozczbjnxqeynnrlkp.supabase.co'
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNhaW96Y3piam54cWV5bm5ybGtwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjM2MjA2MjMsImV4cCI6MjA3OTE5NjYyM30.M1d-1YhqOASqm8z9F46_bItyi5BANH8Q2kMbrXfH9As'

export const supabase = createClient(supabaseUrl, supabaseAnonKey)
```

### 3. Copy Type Definitions

Copy the database types from `src/types/database.ts` to your project. This provides TypeScript support for all Supabase tables.

### 4. Add Social Components

Copy these component directories to your existing project:

```
src/components/
├── Social/          # PostFeed.tsx
├── Friends/         # FriendsList.tsx
└── Notifications/   # NotificationList.tsx
```

### 5. Integrate into Navigation

Add new navigation tabs to your existing app. Here's an example of adding tabs:

```typescript
const navItems = [
  { id: 'chat', label: 'Chat', icon: <MessageSquare /> },
  { id: 'feed', label: 'Feed', icon: <Home /> },
  { id: 'friends', label: 'Friends', icon: <Users /> },
  { id: 'notifications', label: 'Notifications', icon: <Bell /> },
]
```

### 6. Add Route Handling

If using React Router, add routes for the new features:

```typescript
<Route path="/feed" element={<PostFeed />} />
<Route path="/friends" element={<FriendsList />} />
<Route path="/notifications" element={<NotificationList />} />
```

### 7. Update Authentication Context

If your existing app uses a different auth system, you may need to:

1. **Keep both systems**: Use the provided `AuthContext.tsx` for Supabase auth
2. **Merge contexts**: Integrate Supabase auth into your existing auth system
3. **Use existing auth**: Modify components to use your existing authentication

Example of using existing auth:

```typescript
// In PostFeed.tsx, replace:
const { user } = useAuth()

// With your existing auth hook:
const { user } = useYourExistingAuthHook()
```

### 8. Environment Variables

Add to your `.env` file:

```env
VITE_SUPABASE_URL=https://saiozczbjnxqeynnrlkp.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNhaW96Y3piam54cWV5bm5ybGtwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjM2MjA2MjMsImV4cCI6MjA3OTE5NjYyM30.M1d-1YhqOASqm8z9F46_bItyi5BANH8Q2kMbrXfH9As
```

## Minimal Integration Example

If you want to add just the social feed to your existing app:

1. Copy `src/components/Social/PostFeed.tsx`
2. Copy `src/types/database.ts`
3. Configure Supabase client
4. Add to your main app:

```typescript
import { PostFeed } from './components/Social/PostFeed'

function App() {
  return (
    <div>
      {/* Your existing chat UI */}
      <PostFeed />
    </div>
  )
}
```

## Component Dependencies

### PostFeed Component
- Dependencies: `supabase`, `lucide-react`
- Contexts: `AuthContext`
- Tables: `posts`, `comments`, `likes`, `profiles`

### FriendsList Component
- Dependencies: `supabase`, `lucide-react`
- Contexts: `AuthContext`
- Tables: `friendships`, `friend_requests`, `profiles`

### NotificationList Component
- Dependencies: `supabase`, `lucide-react`
- Contexts: `AuthContext`
- Tables: `notifications`

## Database Requirements

Ensure your Supabase project has these tables created:

```sql
-- Essential tables for social features
- profiles (user information)
- posts (social feed posts)
- comments (post comments)
- likes (post likes)
- friendships (accepted friend relationships)
- friend_requests (pending friend requests)
- notifications (user notifications)
```

## Styling

The components use Tailwind CSS classes. Ensure your project has:

```bash
pnpm add tailwindcss
```

And configure `tailwind.config.js` to scan the component directories.

## Real-time Features

The components use Supabase Realtime subscriptions for:
- New posts appearing in the feed
- New messages in chat
- New friend requests
- New notifications

Make sure Realtime is enabled in your Supabase project dashboard.

## Troubleshooting

### Authentication Issues
- Ensure users are logged in before accessing social features
- Check that Supabase auth is configured correctly
- Verify the user ID matches between your auth system and Supabase

### Data Not Loading
- Check browser console for API errors
- Verify table names match the code
- Ensure Row Level Security (RLS) policies allow reading data

### Real-time Not Working
- Enable Realtime in Supabase dashboard
- Check that tables are published for Realtime
- Verify subscriptions are set up correctly

## Next Steps

After integration:

1. **Test all features** with multiple user accounts
2. **Customize styling** to match your existing app's design
3. **Add error handling** for better user experience
4. **Implement loading states** for async operations
5. **Optimize performance** with pagination and caching

## Support

For questions or issues:
1. Check the main README.md for general documentation
2. Review Supabase documentation: https://supabase.com/docs
3. Inspect browser console for error messages
4. Test with the provided test account credentials
