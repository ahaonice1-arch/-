/** @type {import('tailwindcss').Config} */
module.exports = {
	darkMode: ['class'],
	content: [
		'./pages/**/*.{ts,tsx}',
		'./components/**/*.{ts,tsx}',
		'./app/**/*.{ts,tsx}',
		'./src/**/*.{ts,tsx}',
	],
	theme: {
		container: {
			center: true,
			padding: '2rem',
			screens: {
				'2xl': '1400px',
			},
		},
		extend: {
			colors: {
				border: 'hsl(var(--border))',
				input: 'hsl(var(--input))',
				ring: 'hsl(var(--ring))',
				background: 'hsl(var(--background))',
				foreground: 'hsl(var(--foreground))',
				// Purple-Gold Theme Colors
				primary: {
					DEFAULT: '#7C3AED',
					50: '#F5F3FF',
					100: '#EDE9FE',
					200: '#DDD6FE',
					300: '#C4B5FD',
					400: '#A78BFA',
					500: '#8B5CF6',
					600: '#7C3AED',
					700: '#6D28D9',
					800: '#5B21B6',
					900: '#4C1D95',
					foreground: '#FFFFFF',
				},
				gold: {
					DEFAULT: '#F59E0B',
					50: '#FFFBEB',
					100: '#FEF3C7',
					200: '#FDE68A',
					300: '#FCD34D',
					400: '#FBBF24',
					500: '#F59E0B',
					600: '#D97706',
					700: '#B45309',
					800: '#92400E',
					900: '#78350F',
				},
				secondary: {
					DEFAULT: '#F59E0B',
					foreground: '#1F2937',
				},
				accent: {
					DEFAULT: '#A78BFA',
					foreground: '#1F2937',
				},
				destructive: {
					DEFAULT: '#EF4444',
					foreground: '#FFFFFF',
				},
				muted: {
					DEFAULT: '#F3F4F6',
					foreground: '#6B7280',
				},
				popover: {
					DEFAULT: '#FFFFFF',
					foreground: '#1F2937',
				},
				card: {
					DEFAULT: '#FFFFFF',
					foreground: '#1F2937',
				},
			},
			borderRadius: {
				lg: 'var(--radius)',
				md: 'calc(var(--radius) - 2px)',
				sm: 'calc(var(--radius) - 4px)',
			},
			keyframes: {
				'accordion-down': {
					from: { height: 0 },
					to: { height: 'var(--radix-accordion-content-height)' },
				},
				'accordion-up': {
					from: { height: 'var(--radix-accordion-content-height)' },
					to: { height: 0 },
				},
				'pulse-gold': {
					'0%, 100%': { boxShadow: '0 0 0 0 rgba(245, 158, 11, 0.4)' },
					'50%': { boxShadow: '0 0 0 8px rgba(245, 158, 11, 0)' },
				},
			},
			animation: {
				'accordion-down': 'accordion-down 0.2s ease-out',
				'accordion-up': 'accordion-up 0.2s ease-out',
				'pulse-gold': 'pulse-gold 2s infinite',
			},
			backgroundImage: {
				'gradient-primary': 'linear-gradient(135deg, #7C3AED 0%, #A78BFA 100%)',
				'gradient-gold': 'linear-gradient(135deg, #F59E0B 0%, #FCD34D 100%)',
				'gradient-purple-gold': 'linear-gradient(135deg, #7C3AED 0%, #F59E0B 100%)',
			},
		},
	},
	plugins: [require('tailwindcss-animate')],
}
