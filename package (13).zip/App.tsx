import React, { useEffect } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { View, ActivityIndicator, Text, StyleSheet } from 'react-native';

// 新增组件导入
import SocialFeed from './src/components/SocialFeed';
import FriendsScreen from './src/components/FriendsScreen';

// 服务导入
import { socialService } from './src/services/supabaseSocial';
import { advancedChatService } from './src/services/advancedChatService';
import { socialDiscovery } from './src/services/socialDiscovery';
import { performanceOptimizer } from './src/utils/performanceOptimizer';

// 类型定义
export type RootStackParamList = {
  Main: undefined;
  Chat: { chatId: string };
  UserProfile: { userId: string };
  Settings: undefined;
};

export type TabParamList = {
  Chats: undefined;
  Social: undefined;
  Friends: undefined;
  Profile: undefined;
};

const Tab = createBottomTabNavigator<TabParamList>();
const Stack = createNativeStackNavigator<RootStackParamList>();

// 聊天屏幕组件（简化版本，基于原有功能）
const ChatsScreen = () => {
  return (
    <View style={styles.centerContainer}>
      <Text style={styles.placeholderText}>聊天功能 - 待集成原有聊天组件</Text>
    </View>
  );
};

// 个人资料屏幕
const ProfileScreen = () => {
  return (
    <View style={styles.centerContainer}>
      <Text style={styles.placeholderText}>个人资料 - 待集成原有组件</Text>
    </View>
  );
};

// 设置屏幕
const SettingsScreen = () => {
  return (
    <View style={styles.centerContainer}>
      <Text style={styles.placeholderText}>设置</Text>
    </View>
  );
};

// 底部标签导航
const MainTabNavigator = () => {
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarStyle: {
          backgroundColor: '#ffffff',
          borderTopWidth: 1,
          borderTopColor: '#e5e5e5',
          height: 60,
          paddingBottom: 8,
          paddingTop: 8,
        },
        tabBarActiveTintColor: '#007AFF',
        tabBarInactiveTintColor: '#8e8e93',
        tabBarLabelStyle: {
          fontSize: 12,
          fontWeight: '500',
        },
      }}
    >
      <Tab.Screen 
        name="Chats" 
        component={ChatsScreen}
        options={{
          title: '聊天',
          tabBarIcon: ({ color, size }) => (
            <Text style={{ fontSize: size, color }}>💬</Text>
          ),
        }}
      />
      <Tab.Screen 
        name="Social" 
        component={SocialFeed}
        options={{
          title: '朋友圈',
          tabBarIcon: ({ color, size }) => (
            <Text style={{ fontSize: size, color }}>📱</Text>
          ),
        }}
      />
      <Tab.Screen 
        name="Friends" 
        component={FriendsScreen}
        options={{
          title: '好友',
          tabBarIcon: ({ color, size }) => (
            <Text style={{ fontSize: size, color }}>👥</Text>
          ),
        }}
      />
      <Tab.Screen 
        name="Profile" 
        component={ProfileScreen}
        options={{
          title: '我的',
          tabBarIcon: ({ color, size }) => (
            <Text style={{ fontSize: size, color }}>👤</Text>
          ),
        }}
      />
    </Tab.Navigator>
  );
};

// 主导航容器
const AppNavigator = () => {
  const [isLoading, setIsLoading] = React.useState(true);
  const [user, setUser] = React.useState(null);

  useEffect(() => {
    initializeApp();
  }, []);

  const initializeApp = async () => {
    try {
      // 初始化性能优化器
      performanceOptimizer.initialize();
      
      // 检查用户登录状态
      const currentUser = await socialService.getCurrentUser();
      setUser(currentUser);

      // 预加载关键数据
      await preloadCriticalData();

    } catch (error) {
      console.error('应用初始化失败:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const preloadCriticalData = async () => {
    try {
      // 预加载好友推荐
      await socialDiscovery.getUserRecommendations();
      
      // 预加载热门内容
      await socialDiscovery.getTrendingContent();
      
      // 检查网络状态
      await advancedChatService.checkNetworkStatus();
      
    } catch (error) {
      console.error('预加载数据失败:', error);
    }
  };

  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#007AFF" />
        <Text style={styles.loadingText}>加载中...</Text>
      </View>
    );
  }

  return (
    <SafeAreaProvider>
      <NavigationContainer>
        <Stack.Navigator screenOptions={{ headerShown: false }}>
          <Stack.Screen name="Main" component={MainTabNavigator} />
        </Stack.Navigator>
      </NavigationContainer>
      <StatusBar style="auto" />
    </SafeAreaProvider>
  );
};

// 主应用组件
const App = () => {
  return <AppNavigator />;
};

// 样式定义
const styles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
  },
  loadingText: {
    marginTop: 16,
    color: '#666',
    fontSize: 16,
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  placeholderText: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
  },
});

export default App;