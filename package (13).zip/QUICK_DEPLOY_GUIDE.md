# 🚀 一键部署指南

## 立即开始部署

### 🔧 方式一：自动化部署脚本 (推荐)

#### Linux/macOS 用户：
```bash
# 完整部署 Web 版本
./deploy.sh --full web

# 仅构建不部署
./deploy.sh --build-only

# 交互式部署
./deploy.sh
```

#### Windows 用户：
```cmd
# 双击运行 deploy.bat
# 或在命令行中运行
deploy.bat
```

### 📝 方式二：手动部署步骤

如果您更喜欢手动控制每个步骤，请按以下顺序执行：

#### 步骤 1: 准备环境
```bash
# 检查 Node.js 版本 (需要 18+)
node --version

# 安装依赖
npm install

# 类型检查
npm run type-check
```

#### 步骤 2: 数据库迁移 (必须)
1. 访问 https://supabase.com/dashboard
2. 选择项目：`saiozczbjnxqeynnrlkp`
3. 进入 "SQL Editor"
4. 复制 `social_features_migration.sql` 的全部内容
5. 粘贴并执行
6. 验证所有新表创建成功

#### 步骤 3: 配置环境变量
```bash
# 复制环境变量模板
cp .env.example .env

# 编辑 .env 文件，填入您的 Supabase 配置
# 重要: 必须填入正确的 EXPO_PUBLIC_SUPABASE_ANON_KEY
```

获取 Supabase Anon Key:
- 在 Supabase 控制台 → Settings → API
- 复制 "anon" public key

#### 步骤 4: 构建应用
```bash
# 构建 Web 版本
npx expo export --platform web

# 如果需要移动端版本
npx expo export --platform android
npx expo export --platform ios
```

#### 步骤 5: 启动应用
```bash
# 启动开发服务器
npm start

# 或启动生产版本
npm run web
```

## 🗂 部署文件说明

### 核心文件
- `deploy.sh` - Linux/macOS 自动化部署脚本
- `deploy.bat` - Windows 自动化部署脚本
- `App.tsx` - 主应用入口文件
- `package.json` - 项目依赖配置
- `.env.example` - 环境变量模板

### 功能文件
- `social_features_migration.sql` - 数据库迁移脚本
- `src/components/` - React 组件 (朋友圈、好友管理)
- `src/services/` - 业务逻辑服务
- `src/utils/` - 性能优化工具

### 文档文件
- `DEPLOYMENT_GUIDE.md` - 详细部署指南
- `TESTING_GUIDE.md` - 功能测试指南

## 🔍 快速验证

部署完成后，请验证以下功能：

### 基础功能
- ✅ 应用可以正常访问
- ✅ 用户可以注册和登录
- ✅ 底部显示 4 个导航标签

### 社交功能
- ✅ 朋友圈：可以发布动态
- ✅ 朋友圈：可以查看好友动态
- ✅ 好友管理：可以搜索和添加好友
- ✅ 好友管理：可以接受好友请求

### 高级功能
- ✅ 聊天：可以发送消息
- ✅ 聊天：可以分享文件
- ✅ 推荐：显示好友推荐
- ✅ 性能：滚动流畅，加载快速

## 🆘 常见问题解决

### 问题 1: Node.js 版本过低
```bash
# 检查版本
node --version

# 如果版本低于 18，需要升级 Node.js
# 访问 https://nodejs.org 下载最新版本
```

### 问题 2: 依赖安装失败
```bash
# 清理缓存重新安装
rm -rf node_modules package-lock.json
npm install
```

### 问题 3: 数据库连接失败
- 检查 `.env` 文件中的 Supabase URL 和 Key
- 验证数据库迁移是否已执行
- 检查网络连接

### 问题 4: 构建失败
```bash
# 清理构建缓存
rm -rf web-build
npx expo export --platform web --no-pwa
```

### 问题 5: 部署后功能不工作
- 检查浏览器控制台错误信息
- 验证环境变量配置
- 确认数据库表已正确创建

## 📞 技术支持

如果遇到问题：

1. **查看错误日志**：检查控制台错误信息
2. **参考文档**：查看 `DEPLOYMENT_GUIDE.md` 和 `TESTING_GUIDE.md`
3. **验证配置**：确认所有环境变量正确设置
4. **重新部署**：运行 `./deploy.sh --full web` 重新部署

## 🎯 部署成功标志

当您看到以下信息时，说明部署成功：

```bash
[SUCCESS] 依赖安装完成
[SUCCESS] 类型检查通过  
[SUCCESS] 应用构建完成
[SUCCESS] 部署流程完成！
```

并且在浏览器中可以：
- 访问应用主界面
- 注册新用户账号
- 查看底部 4 个导航标签
- 访问朋友圈和好友管理功能

---

**🎉 恭喜！您的社交聊天应用已成功部署！**

现在可以开始使用所有功能：朋友圈动态、好友管理、高级聊天、智能推荐等。