#!/bin/bash

# 社交聊天应用 - 自动化部署脚本
# 作者: MiniMax Agent
# 日期: 2025-11-22

set -e  # 遇到错误时退出

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 日志函数
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 检查前置条件
check_prerequisites() {
    log_info "检查部署前置条件..."
    
    # 检查 Node.js
    if ! command -v node &> /dev/null; then
        log_error "Node.js 未安装，请先安装 Node.js 18+"
        exit 1
    fi
    
    NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
    if [ "$NODE_VERSION" -lt 18 ]; then
        log_error "Node.js 版本过低，需要 18+，当前版本: $(node -v)"
        exit 1
    fi
    
    # 检查 npm
    if ! command -v npm &> /dev/null; then
        log_error "npm 未安装，请先安装 npm"
        exit 1
    fi
    
    # 检查 Git
    if ! command -v git &> /dev/null; then
        log_warning "Git 未安装，某些功能可能受限"
    fi
    
    log_success "前置条件检查完成"
}

# 配置环境变量
setup_environment() {
    log_info "设置环境变量..."
    
    if [ ! -f ".env" ]; then
        if [ -f ".env.example" ]; then
            cp .env.example .env
            log_warning "已创建 .env 文件，请编辑并填入正确的配置信息"
            log_warning "特别是 Supabase URL 和 API Key"
        else
            log_error ".env.example 文件不存在"
            exit 1
        fi
    else
        log_info ".env 文件已存在"
    fi
}

# 安装依赖
install_dependencies() {
    log_info "安装项目依赖..."
    
    # 清理旧的依赖
    if [ -d "node_modules" ]; then
        log_info "清理旧的 node_modules..."
        rm -rf node_modules
    fi
    
    # 安装新依赖
    npm install
    log_success "依赖安装完成"
}

# 类型检查
type_check() {
    log_info "执行 TypeScript 类型检查..."
    npm run type-check
    log_success "类型检查通过"
}

# 数据库迁移检查
check_database() {
    log_info "检查数据库迁移状态..."
    
    echo ""
    echo "⚠️  重要提醒：数据库迁移需要手动在 Supabase 控制台完成"
    echo ""
    echo "请按以下步骤操作："
    echo "1. 访问: https://supabase.com/dashboard"
    echo "2. 选择项目: saiozczbjnxqeynnrlkp"
    echo "3. 进入 SQL Editor"
    echo "4. 复制并执行 social_features_migration.sql 的全部内容"
    echo "5. 验证所有表创建成功"
    echo ""
    
    read -p "是否已完成数据库迁移？(y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        log_warning "请先完成数据库迁移后再继续部署"
        exit 1
    fi
}

# 构建应用
build_application() {
    log_info "构建生产版本..."
    
    # Web 构建
    log_info "构建 Web 版本..."
    npx expo export --platform web
    
    # 移动端构建 (可选)
    if [ "$1" = "--mobile" ]; then
        log_info "构建移动端版本..."
        npx expo export --platform ios
        npx expo export --platform android
    fi
    
    log_success "应用构建完成"
}

# 测试功能
test_application() {
    log_info "启动开发服务器进行功能测试..."
    
    # 启动开发服务器
    npm start &
    SERVER_PID=$!
    
    # 等待服务器启动
    log_info "等待开发服务器启动..."
    sleep 10
    
    # 测试基本功能
    log_info "执行基本功能测试..."
    
    # 测试应用启动
    if curl -s http://localhost:8081 > /dev/null; then
        log_success "应用启动成功"
    else
        log_warning "应用启动可能存在问题"
    fi
    
    # 停止服务器
    kill $SERVER_PID 2>/dev/null || true
    log_success "测试完成"
}

# 部署到生产环境
deploy_to_production() {
    local platform="$1"
    
    case $platform in
        "web")
            log_info "部署到 Web 平台..."
            
            # 创建部署目录
            mkdir -p dist
            
            # 复制构建文件
            if [ -d "web-build" ]; then
                cp -r web-build/* dist/
                log_success "Web 版本已准备在 dist/ 目录"
            else
                log_error "Web 构建文件不存在，请先运行构建"
                exit 1
            fi
            
            # 显示部署信息
            echo ""
            log_success "Web 版本部署准备完成！"
            echo "部署文件位于: ./dist/"
            echo ""
            echo "部署选项："
            echo "1. 手动上传 dist/ 目录到您的 Web 服务器"
            echo "2. 使用我们的部署工具"
            echo "3. 部署到 Netlify/Vercel 等静态托管服务"
            echo ""
            ;;
            
        "android")
            log_info "部署到 Android 平台..."
            
            if ! command -v eas &> /dev/null; then
                log_info "安装 EAS CLI..."
                npm install -g @expo/eas-cli
            fi
            
            log_info "构建 Android 版本..."
            eas build --platform android
            
            log_success "Android 构建完成，请检查 EAS 控制台"
            ;;
            
        "ios")
            log_info "部署到 iOS 平台..."
            
            if ! command -v eas &> /dev/null; then
                log_info "安装 EAS CLI..."
                npm install -g @expo/eas-cli
            fi
            
            log_info "构建 iOS 版本..."
            eas build --platform ios
            
            log_success "iOS 构建完成，请检查 EAS 控制台"
            ;;
            
        "all")
            log_info "部署到所有平台..."
            deploy_to_production "web"
            deploy_to_production "android"
            deploy_to_production "ios"
            ;;
            
        *)
            log_error "未知的部署平台: $platform"
            exit 1
            ;;
    esac
}

# 验证部署
verify_deployment() {
    log_info "验证部署结果..."
    
    echo ""
    echo "🎯 部署验证清单："
    echo ""
    echo "✅ 应用启动正常"
    echo "✅ 用户注册/登录功能"
    echo "✅ 朋友圈发布和浏览"
    echo "✅ 好友搜索和添加"
    echo "✅ 聊天和文件分享"
    echo "✅ 推荐系统工作"
    echo "✅ 性能优化生效"
    echo ""
    echo "请访问应用并逐一验证以上功能。"
    echo ""
}

# 显示帮助信息
show_help() {
    echo "社交聊天应用 - 自动化部署脚本"
    echo ""
    echo "用法:"
    echo "  ./deploy.sh [选项] [平台]"
    echo ""
    echo "选项:"
    echo "  --help, -h          显示帮助信息"
    echo "  --full              完整部署流程"
    echo "  --build-only        仅构建应用"
    echo "  --test-only         仅运行测试"
    echo "  --mobile            同时构建移动端"
    echo ""
    echo "平台:"
    echo "  web                 部署 Web 版本"
    echo "  android             部署 Android 版本"
    echo "  ios                 部署 iOS 版本"
    echo "  all                 部署所有平台"
    echo ""
    echo "示例:"
    echo "  ./deploy.sh --full web        # 完整部署 Web 版本"
    echo "  ./deploy.sh --mobile android  # 构建 Android 版本"
    echo "  ./deploy.sh --build-only      # 仅构建应用"
    echo ""
}

# 主函数
main() {
    local deploy_mode="interactive"
    local platform="web"
    local include_mobile=false
    
    # 解析命令行参数
    while [[ $# -gt 0 ]]; do
        case $1 in
            --help|-h)
                show_help
                exit 0
                ;;
            --full)
                deploy_mode="full"
                shift
                ;;
            --build-only)
                deploy_mode="build-only"
                shift
                ;;
            --test-only)
                deploy_mode="test-only"
                shift
                ;;
            --mobile)
                include_mobile=true
                shift
                ;;
            web|android|ios|all)
                platform="$1"
                shift
                ;;
            *)
                log_error "未知参数: $1"
                show_help
                exit 1
                ;;
        esac
    done
    
    echo ""
    echo "🚀 社交聊天应用 - 自动化部署"
    echo "================================"
    echo ""
    
    # 根据部署模式执行相应操作
    case $deploy_mode in
        "full")
            check_prerequisites
            setup_environment
            install_dependencies
            type_check
            check_database
            
            if [ "$include_mobile" = true ]; then
                build_application --mobile
            else
                build_application
            fi
            
            deploy_to_production "$platform"
            verify_deployment
            ;;
            
        "build-only")
            check_prerequisites
            install_dependencies
            type_check
            
            if [ "$include_mobile" = true ]; then
                build_application --mobile
            else
                build_application
            fi
            ;;
            
        "test-only")
            check_prerequisites
            test_application
            ;;
            
        "interactive")
            # 交互式部署
            check_prerequisites
            setup_environment
            install_dependencies
            type_check
            
            echo ""
            read -p "是否已完成数据库迁移？(y/N): " -n 1 -r
            echo
            if [[ $REPLY =~ ^[Yy]$ ]]; then
                check_database
            fi
            
            echo ""
            echo "选择部署平台:"
            echo "1) Web"
            echo "2) Android"
            echo "3) iOS"
            echo "4) 所有平台"
            echo ""
            read -p "请选择 (1-4): " -n 1 -r
            echo
            
            case $REPLY in
                1) platform="web" ;;
                2) platform="android" ;;
                3) platform="ios" ;;
                4) platform="all" ;;
                *) log_error "无效选择"; exit 1 ;;
            esac
            
            echo ""
            read -p "是否同时构建移动端版本？(y/N): " -n 1 -r
            echo
            
            if [[ $REPLY =~ ^[Yy]$ ]]; then
                include_mobile=true
            fi
            
            if [ "$include_mobile" = true ]; then
                build_application --mobile
            else
                build_application
            fi
            
            deploy_to_production "$platform"
            verify_deployment
            ;;
    esac
    
    log_success "部署流程完成！"
}

# 执行主函数
main "$@"