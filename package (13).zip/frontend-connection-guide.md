# Frontend Connection Guide

## Database Configuration
Your Supabase backend is fully configured with the following details:

- **Database URL**: https://saiozczbjnxqeynnrlkp.supabase.co
- **Anon Key**: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
- **Project ID**: saiozczbjnxqeynnrlkp

## Database Tables Available
Your database contains 22 tables including:
- **Social Features**: posts, comments, likes, friendships, notifications
- **Chat System**: chats, messages, chat_members, message_status
- **User Management**: profiles, user_activities, user_status
- **Additional Features**: friend_requests, webrtc_signals, user_devices

## Connection Steps

### 1. Install Supabase Client
```bash
npm install @supabase/supabase-js
```

### 2. Configure Environment Variables
Create or update your `.env` file:
```env
VITE_SUPABASE_URL=https://saiozczbjnxqeynnrlkp.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNhaW96Y3piam54cWV5bm5ybGtwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjM2MjA2MjMsImV4cCI6MjA3OTE5NjYyM30.M1d-1YhqOASqm8z9F46_bItyi5BANH8Q2kMbrXfH9As
```

### 3. Create Supabase Client
```javascript
// lib/supabase.js
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
```

### 4. Test Connection
```javascript
// Test your connection
async function testConnection() {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .limit(1);
  
  if (error) {
    console.error('Connection failed:', error);
  } else {
    console.log('Connection successful!', data);
  }
}
```

## Row Level Security (RLS)
All tables have RLS enabled. Users can only access their own data. Make sure to implement proper authentication in your frontend.

## Next Steps
1. Configure authentication (login/signup)
2. Set up user profiles
3. Implement real-time subscriptions for chat
4. Add social features (posts, comments, likes)
5. Test all functionality

## Support
If you encounter any connection issues, check:
- Environment variables are correctly set
- CORS settings in Supabase dashboard
- RLS policies are working properly
- Network connectivity