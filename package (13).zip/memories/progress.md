# 光信IM - Major Update Task

## Current Task: Fix 12 bugs + Rebrand + Multi-language

## Test Accounts
- Account 1: ohuhwzen@minimax.com / yKi2EDodAK  
- Account 2: ypwkkunz@minimax.com / R1fqQnD0kI

## 12 Fixes Needed:
1. [ ] Post publishing
2. [ ] Image upload for posts
3. [ ] Comment system
4. [ ] Like button flicker
5. [ ] Chat back button
6. [ ] 3-dots menu functionality
7. [ ] Message real-time display
8. [ ] User profile on avatar click
9. [ ] Friends list display
10. [ ] Friend search
11. [ ] Friend request notifications
12. [ ] Avatar upload

## Rebranding:
- App Name: 光信IM
- Tagline: 光引话题，信续闲谈
- Colors: Purple-Gold theme
- Languages: CN/EN/MY

## Status: IN PROGRESS
