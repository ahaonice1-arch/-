import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { createClient } from '@supabase/supabase-js';
import './App.css';

// Types
export interface User {
  id: string;
  username?: string;
  avatar_url?: string;
  bio?: string;
}

export interface Post {
  id: string;
  author_id: string;
  content: string;
  image_urls?: string[];
  visibility: 'public' | 'friends' | 'private';
  like_count: number;
  comment_count: number;
  created_at: string;
  updated_at: string;
}

export interface Friendship {
  id: string;
  requester_id: string;
  addressee_id: string;
  status: 'pending' | 'accepted' | 'blocked';
  created_at: string;
}

// Supabase configuration
const supabaseUrl = 'https://saiozczbjnxqeynnrlkp.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNhaW9jemNiem5xeWVubnJsa3AiLCJyb2xlIjoiYW5vbiIsImlhdCI6MTczMzQ4NzM0NCwiZXhwIjoyMDQ5MDYzMzQ0fQ.QKxL9j2xJ6l5dYl2b9mV4r8kE0zI8jL3pA6gR7sT2U';
const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Components
const SocialFeed: React.FC = () => {
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchPosts();
  }, []);

  const fetchPosts = async () => {
    try {
      const { data, error } = await supabase
        .from('posts')
        .select('*')
        .eq('visibility', 'public')
        .order('created_at', { ascending: false })
        .limit(20);

      if (error) throw error;
      setPosts(data || []);
    } catch (error) {
      console.error('Error fetching posts:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div className="loading">Loading posts...</div>;

  return (
    <div className="social-feed">
      <h2>Social Feed</h2>
      <div className="posts-list">
        {posts.map(post => (
          <div key={post.id} className="post-card">
            <div className="post-content">{post.content}</div>
            <div className="post-meta">
              <span>👍 {post.like_count} likes</span>
              <span>💬 {post.comment_count} comments</span>
              <span>{new Date(post.created_at).toLocaleDateString()}</span>
            </div>
          </div>
        ))}
        {posts.length === 0 && <p>No posts found. Create the first post!</p>}
      </div>
    </div>
  );
};

const FriendsScreen: React.FC = () => {
  const [friends, setFriends] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchFriends();
  }, []);

  const fetchFriends = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('friendships')
        .select(`
          *,
          requester:profiles!friendships_requester_id_fkey(id, username, avatar_url),
          addressee:profiles!friendships_addressee_id_fkey(id, username, avatar_url)
        `)
        .or(`requester_id.eq.${user.id},addressee_id.eq.${user.id}`)
        .eq('status', 'accepted');

      if (error) throw error;
      setFriends(data || []);
    } catch (error) {
      console.error('Error fetching friends:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div className="loading">Loading friends...</div>;

  return (
    <div className="friends-screen">
      <h2>Friends</h2>
      <div className="friends-list">
        {friends.map(friendship => (
          <div key={friendship.id} className="friend-card">
            <div className="friend-info">
              <div className="friend-avatar">
                {friendship.requester_id !== friendship.addressee_id 
                  ? friendship.requester?.username || friendship.addressee?.username 
                  : 'User'}
              </div>
              <div className="friend-details">
                <div className="friend-name">
                  {friendship.requester_id !== friendship.addressee_id 
                    ? friendship.requester?.username || friendship.addressee?.username 
                    : 'Unknown User'}
                </div>
                <div className="friend-status">Status: {friendship.status}</div>
              </div>
            </div>
          </div>
        ))}
        {friends.length === 0 && <p>No friends yet. Start making friends!</p>}
      </div>
    </div>
  );
};

const ChatsScreen: React.FC = () => {
  return (
    <div className="chats-screen">
      <h2>Chats</h2>
      <p>Chat functionality coming soon...</p>
      <div className="chat-placeholder">
        <p>This feature will be integrated from the existing React Native app</p>
      </div>
    </div>
  );
};

const ProfileScreen: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchUser();
  }, []);

  const fetchUser = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single();

      if (error) throw error;
      setUser(data);
    } catch (error) {
      console.error('Error fetching user:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div className="loading">Loading profile...</div>;

  return (
    <div className="profile-screen">
      <h2>Profile</h2>
      {user ? (
        <div className="profile-card">
          <div className="profile-avatar">
            {user.avatar_url ? (
              <img src={user.avatar_url} alt="Avatar" />
            ) : (
              <div className="avatar-placeholder">{user.username?.[0] || 'U'}</div>
            )}
          </div>
          <div className="profile-info">
            <h3>{user.username || 'Anonymous User'}</h3>
            <p>{user.bio || 'No bio available'}</p>
          </div>
        </div>
      ) : (
        <div className="profile-placeholder">
          <p>Please log in to see your profile</p>
        </div>
      )}
    </div>
  );
};

// Main App Component
function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  useEffect(() => {
    // Get initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session?.user) {
        fetchUserProfile(session.user.id);
      }
    });

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session?.user) {
        fetchUserProfile(session.user.id);
      } else {
        setCurrentUser(null);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const fetchUserProfile = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single();

      if (error) throw error;
      setCurrentUser(data);
    } catch (error) {
      console.error('Error fetching user profile:', error);
    }
  };

  const handleSignOut = async () => {
    await supabase.auth.signOut();
  };

  const handleSignIn = async () => {
    const { data, error } = await supabase.auth.signInWithPassword({
      email: 'demo@example.com',
      password: 'demo123456'
    });
    if (error) console.error('Error signing in:', error);
  };

  return (
    <Router>
      <div className="App">
        <header className="app-header">
          <h1>Social Chat App</h1>
          <div className="user-actions">
            {currentUser ? (
              <div className="user-info">
                <span>Welcome, {currentUser.username || 'User'}!</span>
                <button onClick={handleSignOut}>Sign Out</button>
              </div>
            ) : (
              <button onClick={handleSignIn}>Sign In (Demo)</button>
            )}
          </div>
        </header>

        <nav className="app-nav">
          <Link to="/">Social</Link>
          <Link to="/friends">Friends</Link>
          <Link to="/chats">Chats</Link>
          <Link to="/profile">Profile</Link>
        </nav>

        <main className="app-main">
          <Routes>
            <Route path="/" element={<SocialFeed />} />
            <Route path="/friends" element={<FriendsScreen />} />
            <Route path="/chats" element={<ChatsScreen />} />
            <Route path="/profile" element={<ProfileScreen />} />
          </Routes>
        </main>

        <footer className="app-footer">
          <p>&copy; 2025 Social Chat App. Database migration completed successfully.</p>
        </footer>
      </div>
    </Router>
  );
}

export default App;